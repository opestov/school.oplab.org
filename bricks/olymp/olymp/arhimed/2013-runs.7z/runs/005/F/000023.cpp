#include <stdio.h>
int main()
{
  int a, b, c, d, e, f, x;
  scanf("%d%d%d%d%d%d", &a, &b, &c, &d, &e, &f);

  if ((a + b + c) > (d + e + f)) {
    x = (a + b + c) / (d + e + f);
    x = (d + e + f) * x;
  }
  if ((a + b + c) < (d + e + f)) {
    x = (d + e + f) / (a + b + c);
    x = (a + b + c) * x;
  }
  printf("%d ", x);
  return 0;
}