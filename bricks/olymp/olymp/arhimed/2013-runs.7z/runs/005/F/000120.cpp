#include <stdio.h>
int main()
{
  int a, b, c, d, e, f, x, k, y;
  scanf("%d%d%d%d%d%d", &a, &b, &c, &d, &e, &f);

  if ((a + b + c) > (d + e + f)) {
    x = (a + b + c);
    y = (d + e + f);

  } else if ((a + b + c) < (d + e + f)) {
    x = (d + e + f);
    y = (a + b + c);
  }

  for (int i = 1; 1001; i++)
    for (int z = i + 1; y * z < 501; z++) {
      if (x * i == y * z) {
        printf("%d", y * z);
        return 0;
      }
    }

  /*k = y;
  while (x != y) {
    if (x > y) {
      x = x - y;
    } else
      y = y - x;
  }

  x = k * x;
  */
  /* x = x / y;
   x = y * x;
   printf("%d ", x);
  */ return 0;
}