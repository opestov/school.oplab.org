#include <stdio.h>
int main()
{
  int a, b, c, d, e, f;
  scanf("%d%d%d%d%d%d", &a, &b, &c, &d, &e, &f);
  if ((a + b + c) > (d + e + f))
    printf("%d", (a + b + c));
  else
    printf("%d", (d + e + f));



  return 0;
}