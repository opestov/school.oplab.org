#include <stdio.h>
int main()
{
  int a, b = 0, f = 0;
  int c[9] = {0};
  int s[9] = {0};
  scanf("%d", &a);
  for (int i = 0; i < 9; i++) {
    b = a % 10;
    c[b] = b;
    a = a / 10;
  }
  int m = 0;
  for (int i = 0; i < 9; i++) {
    if (c[i] != 0)
      m = m * 10 + c[i];
  }
  m *= 9;
  //printf("%d", m);
  for (int i = 0; i < 9 ; i++) {
    f = (m % 10);
    //printf("%d", b);
    s[f]++;
    m = m / 10;
    //printf("%d", b);
  }

  m = 0;
  for (int i = 0; i < 9; i++) {
    if (s[i] != 0)
      for (int y = 0; y < i; y++)
        m = m + s[i];
  }
  printf("%d", m);

  return 0;
}