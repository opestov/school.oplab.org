#include <stdio.h>
int c[4] = {0};
void s(int a)
{
  int b;
  for (int i = 3; i >= 0; i--) {
    b = a % 10;
    c[i] = b;
    a = a / 10;
  }
}

int main()
{
  int a, b, f;
  scanf("%d", &a);
  f = a;
  int r = 1;
  a++;
  s(a);
  int m=0;

  for (int i = 0; i < 4 ; i++) {
    if ((c[i] == 3) || (c[i] == 4)) {
      a++;
      s(a);
      i = 0;
      m = 0;
    }
    m = m * 10 + c[i];

  }
  printf("%d", m);

  return 0;
}