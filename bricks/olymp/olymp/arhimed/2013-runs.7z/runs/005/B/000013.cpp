#include <stdio.h>
int main()
{
  int n;
  scanf("%d", &n);
  int c;
  scanf("%d", &c);
  int b = c;
  printf("%d ", c);
  for (int i = 0; i < n - 1; i++) {
    scanf("%d", &c);
    if (b > c)
      printf("%d ", c);
    else
      printf("%d ", b);
  }

  return 0;
}