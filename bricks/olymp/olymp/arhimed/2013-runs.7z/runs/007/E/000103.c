#include <stdio.h>

int main (){

int a,b,c,f;
scanf("%d", &a);
f=1;
while (f>0) {
	f=0;
	a++;
	b=a;
	while (b/10 > 0) {
		c=b%10;
		b/=10;
		if (c == 3 || c== 4) f ++;
	}
}
printf("%d", a);

	return 0;
}