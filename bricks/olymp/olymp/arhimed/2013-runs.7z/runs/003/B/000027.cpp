#include <iostream>

using namespace std;

int main()
{
    int n(0);
    cin >> n;
    int cars[200];
    for(int i = 0; i < n; i++)
    {
        cin >> cars[i];
    }
    int temp;
    temp = cars[0];
    for (int i = 1; i < n; i++)
    {
        if(cars[i] > temp)
            cars[i] = temp;
        else
            temp = cars[i];
    }

    for (int i = 0; i < n; i++)
    {
        cout << cars[i] << " ";
    }
    return 0;
}
