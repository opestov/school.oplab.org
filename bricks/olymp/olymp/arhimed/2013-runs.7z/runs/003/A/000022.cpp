#include <stdio.h>
int main()
{
	int a;
	scanf("%d", &a);
	int arr[10];

	int i=0;
	while(a%10 > 0)
	{
		arr[i] = a%10;
		a = a/10;
		i++;
	}

	int temp;
	for(int k=0; k<i; k++)
	{
		for(int j=k; j<i; j++)
		{
			if(arr[k] > arr[j])
			{
				temp = arr[k];
				arr[k] = arr[j];
				arr[j] = temp;
			}
		}
	}

	int y = 0;
	for(int k =0; k<i; k++)
	{
		if (y != 0) y *= 10;
		y += arr[k];
	}
	y = y * 9;
	i=0;
	int m;
	m = y;
	
	int x = 0;
	while(m > 0)
	{
		x += m%10;
		m = m/10;
	}
	if (y > a) 
	{
		printf("%d", x);
	}
	else
		printf("%d", y);

	return 0;
}