n,h = input().split(' ')
n = int(n)
h = int(h)
nums = [int(x) for x in input().split(' ')]
res = 0
for i in range(len(nums)-1):
    if nums[i] < nums[i+1]:
        print(-1)
        break
    else:
        while nums[i+1] != nums[i]+1:
            nums[i+1] += 1
        res += 1
        if nums[i+1] == h:
            print(res+1)
            
