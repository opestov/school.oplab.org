t = int(input())
codes = []
for x in range(t):
    codes.append(input())
for code in codes:
    if ((int(code[:2])**2) + (int(code[2:])**2)) % 7 == 1:
        print('YES')
    else:
        print('NO')
