n,m = input().split(' ')
n = int(n)
m = int(m)
wind = []
sq = []
res = []
for i in range(n):
    wind.append([int(x) for x in input().split(' ')])
for i in range(m):
    sq.append(int(input()))
for i in range(sq[-1]):
    res.append(None)
for x in sq:
    res[x-1] = 0
    for i in range(n):
        if x in range(wind[i][0],wind[i][1]+1):
            if (x-wind[i][0])%2 == 0:
                res[x-1] += wind[i][2]
            else:
                res[x-1] -= wind[i][2]
for x in res:
    if x == None: continue
    else: print(x)
