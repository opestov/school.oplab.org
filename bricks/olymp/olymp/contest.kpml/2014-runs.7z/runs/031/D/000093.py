n,m = input().split(' ')
n = int(n)
m = int(m)
wind = []
sq = []
res = []
h=0
for i in range(n):
    wind.append([int(x) for x in input().split(' ')])
for i in range(m):
    sq.append(int(input())) 
for x in sq:
    g =0
    h+=1
    for i in range(n):
        if x in range(wind[i][0],wind[i][1]+1):
            g+=1
            if g == 1:
                if (x-wind[i][0])%2 == 0:
                    res.append(wind[i][2])
                else:
                    res.append(-wind[i][2])
            elif g > 1:
                if (x-wind[i][0])%2 == 0:
                    res[h-1] += wind[i][2]
                else:
                    res[h-1] -= wind[i][2]
        elif i==n-1 and g==0:
             res.append(0)
for x in res:
    print(x)
