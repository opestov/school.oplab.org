#031, F
from fractions import gcd
from math import sqrt

a, b = input().split(' ')
a = int(a)
b = int(b)
if a > b:
    a,b = b,a
GCD = gcd(a,b)
n1 = int(a/GCD)
n2 = int(b/GCD)
g = int(sqrt(n1*n2))+1
isAns = False
for i in reversed(range(n1+2, int(sqrt(n1*n2))+1)):
    if ((((n1*n2) % i) == 0) and
        (gcd(i, n1*n2 / i) == 1) and
        (g*GCD != (a*b)/GCD/g)):
        g-=1
        isAns = True
        break
if isAns:
    x = g*GCD
    y = (a*b)/GCD/g
    print(x,int(y))
else:
    print(a,b)

