#031, F
from fractions import gcd
from math import sqrt

a, b = input().split(' ')
a = int(a)
b = int(b)
GCD = gcd(a,b)
n1 = int(a/GCD)
n2 = int(b/GCD)
g = int(sqrt(n1*n2))+1
for i in reversed(range(n1, int(sqrt(n1*n2))+1)):
    if ((((n1*n2) % i) == 0) and
        (gcd(i, n1*n2 / i) == 1)):
        g-=1
        break
x = g*GCD
y = (a*b)/GCD/g
if x == y:
    print(a,b)
else:
    print(x,int(y))
