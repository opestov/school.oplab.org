n = int(input())
cells = [int(x) for x in input().split(' ')]
res = 0
for i in range(1,n+1):
    for h in cells:
        if i <= h:
            res += 1
            del cells[0]
            break
        else:
            del cells[0]
            break
print(res)
for x in range(1,res+1):
    print(x,x)
