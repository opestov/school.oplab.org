#031, H
def ListToStr(l):
    s = ''
    for x in l:
        s += x + ' '
    s = s[:-1]
    return s

n = int(input())
names = []
for x in range(n):
    names.append([s for s in input().split(' ')])
for i in range(len(names)):
    for h in range(len(names)):
        if names[i][1] == names[h][0]:
            names[h].insert(0,names[h][2])
            del names[h][3]
            #break
names.sort()
for x in names:
    print(ListToStr(x))
##Ivanov Ivan Ivanovich
##Ivan Borisovich Petrov
##Sergey Ivanovich Sidorov
##Pavlov Sergey Borisovich
    
##a b c
##b c a
##f e d
##d f e
##a b c
##f e d
##b c a
##d f e
##a b c
##f e d
