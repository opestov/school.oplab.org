import java.util.Scanner;

public class game{
    public static void main(String[] ags) {
        Scanner scanner = new Scanner(System.in);
        int stol = scanner.nextInt(), kol = scanner.nextInt();
        int maxP = scanner.nextInt(), minP = scanner.nextInt();
        int maxV = scanner.nextInt(), minV = scanner.nextInt();
        int[] len = new int[stol];
        int ob = 0, broskiV = 0, broskiP = 0;
        for (int i = 0; i < stol; i++) {
            len[i] = scanner.nextInt();
            if ((len[i] <= minP) && (len[i] <= minV )&& (len[i] >= maxP )&& (len[i] >= maxV)) {
                ob++;
            } else {
                if (len[i] <= maxP && len[i] >= minP) {
                    broskiP++;
                } else {
                    broskiV++;
                }
            }
        }
        if (kol % 2 == 0) {
            if (ob % 2 == 0) {
                if (broskiP > broskiV) {
                    System.out.println("Petya");
                } else {
                    if (broskiP == broskiV) {
                        System.out.println("Draw");
                    } else {
                        System.out.println("Vasya");
                    }
                }
            }
        } else {
            if (ob % 2 == 0) {
                if (broskiP > (kol + 1) / 2 - ob / 2 && broskiV < (kol - 1) / 2 - ob / 2) {
                    System.out.println("Vasya");
                } else {
                    if (broskiP == (kol+1) / 2 - (ob) / 2 && broskiV == (kol - 1) / 2 - (ob )/ 2) {
                        System.out.println("Draw");
                    } else {
                        System.out.println("Petya");
                    }
                }
            }else {
                if (broskiP > (kol + 1) / 2 - (ob+1) / 2 && broskiV < (kol - 1) / 2 - (ob+1) / 2) {
                    System.out.println("Vasya");
                } else {
                    if (broskiP == (kol+1) / 2 - (ob+1) / 2 && broskiV == (kol - 1) / 2 - (ob+1 )/ 2) {
                        System.out.println("Draw");
                    } else {
                        System.out.println("Petya");
                    }
                }
            }
        }
    }
}

