import java.util.Scanner;

public class sol {
    public static void main(String[] ags){
        Scanner scanner=new Scanner(System.in);
        int kol=scanner.nextInt();
        int[]mas=new int[kol];
        for (int i=0;i<mas.length;i++){
            mas[i]=scanner.nextInt();
        }
        for (int i=0;i<mas.length;i++){
            if ((((mas[i]/100)*(mas[i]/100)+(mas[i]%100)*(mas[i]%100))-1)%7==0){
                System.out.println("YES");
            }else {
                System.out.println("NO");
            }
        }

    }
}
