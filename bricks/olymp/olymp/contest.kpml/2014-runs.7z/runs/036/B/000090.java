import java.util.Scanner;

public class cax {
    public static void main(String[] ags) {
        Scanner scanner = new Scanner(System.in);
        int stol = scanner.nextInt();
        int[] mas = new int[stol];
        for (int i = 0; i < stol; i++) {
            mas[i] = scanner.nextInt();
        }
        if (mas[0] == 1) {
            System.out.println("1");
            System.out.println("1 1");
        } else {
            if (mas[stol - 1] == 1) {
                System.out.println(stol - 1);
            } else {
                System.out.println(stol);
            }
            for (int i = 0,b=1; mas[i] != 1; i++,b++) {
                if (mas[i] == mas[i + 1]){
                    System.out.println(b+" "+mas[i]);
                    System.out.println((b+1)+" "+mas[i+2]);
                    b++;i++;
                }else {
                    System.out.println(b+" "+mas[i+1]);
                }
            }
        }
    }
}