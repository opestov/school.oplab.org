import java.util.Scanner;

public class sol {
    public static void main(String[] ags) {
        Scanner scanner = new Scanner(System.in);
        int col = scanner.nextInt();
        int[] mas = new int[col];
        for (int i = 0; i < col; i++) {
            mas[i] = scanner.nextInt();
        }
        if (mas[col - 1] == 1) {
            System.out.println(col - 1);
            for (int i = 0, b = 1; i < col - 1; i++, b++) {
                if (b == col - 1) {
                    System.out.println(b + " " + 1);
                    break;
                } else {
                    System.out.println(b + " " + mas[i]);
                }
            }
        } else {
            for (int i = 0, b = 1; i < col - 1; i++, b++) {
                System.out.println(b + " " + mas[i]);
            }
        }
    }
}


