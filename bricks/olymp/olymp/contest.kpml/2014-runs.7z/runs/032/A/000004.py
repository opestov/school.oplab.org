t=int(input())
for i in range(t):
    x=int(input())
    x1=x // 100
    x2=x%100
    if (x1*x1+x2*x2)%7==1:
        print('YES')
    else:
        print('NO')