def lol():
    n=int(input())
    a=list(map(int,input().split()))
    a.sort()
    if a[0]==a[n-1]:
        return 0
    i=n-1
    sum1=0
    summ=sum(a)
    while True:
        sum1+=a[i]
        summ-=a[i]
        if i*a[i-1]-summ<=sum1:
            return n-i
        i-=1
print(lol())