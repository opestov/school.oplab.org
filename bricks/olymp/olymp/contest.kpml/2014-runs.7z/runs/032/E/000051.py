n, m = map(int, input().split())
l1,r1 = map(int, input().split())
l2,r2 = map(int, input().split())
s1=0
s2=0
ss=0
a = list(map(int, input().split()))
for i in range(n):
    if l1 <= a[i] <= r1 and l2 <= a[i] <= r2:
        ss+=1
    elif l1 <= a[i] <= r1:
        s1+=1
    elif l2 <= a[i] <= r2:
        s2+=1
s1+=ss//2+ss%2
s2+=ss//2
s1=min(s1,m//2+m%2)
s2=min(s2,m//2)
if m >= s1+s2:
    if s1 > s2:
        print('Petya')
    elif s2 > s1:
        print('Vasya')
    else:
        print('Draw')