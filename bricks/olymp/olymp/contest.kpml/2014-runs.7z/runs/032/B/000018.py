n = int(input())
a = list(map(int, input().split()))
s = 0
for i in range(n):
    if i <= a[i] - 1:
        s+=1
    else:
        break
    
print(s)
for i in range(s):
    print(i+1, i+1)