//32

#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>


using namespace std;

long long gcd(long long a, long long b){
    while (a!=0){
        b = b % a;
        swap(a,b);
    }
    return b;


}
int main()
{
    long long a,b,x,y;
    cin >> a >> b;
    if (a > b)
        swap(a,b);
    long long m = a*b;
    long long nod = gcd(a,b);
    x = int(sqrt(m));
    x = x - x % nod;

    while ((m % x != 0) || (gcd(x, m/x) != nod))
        x-=nod;

    y = m/x;
    cout << x << ' ' << y;
    return 0;
}
