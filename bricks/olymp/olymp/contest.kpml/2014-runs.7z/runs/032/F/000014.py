from fractions import gcd
def ans():
    a, b = map(int, input().split())
    m = a*b
    nok = (m) // gcd(a,b)
    x = int((m)**0.5)
    
    while m % x != 0 or (m) // gcd(x, (m)//x) != nok:
        x-=1
        
    y = (m)//x
    #x,y=min(x,y)
    print(x,y)
ans()