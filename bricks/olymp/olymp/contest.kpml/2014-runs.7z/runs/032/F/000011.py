a, b = map(int, input().split())
x = int((a*b)**0.5)
while a*b % x != 0:
    x-=1
y = (a*b)//x
print(x,y)