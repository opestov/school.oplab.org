from fractions import gcd
a, b = map(int, input().split())
nok = (a*b) // gcd(a,b)
x = int((a*b)**0.5)
while a*b % x != 0 or (a*b) // gcd(x, (a*b)//x) != nok:
    x-=1
    
y = (a*b)//x
#x,y=min(x,y)
print(x,y)