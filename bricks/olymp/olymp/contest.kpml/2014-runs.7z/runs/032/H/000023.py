def turbo():
    n = int(input())
    d = dict()
    a = []
    name = []
    p = []
    ans=[]
    for i in range(n):
        s1,s2,s3 = input().split()
        p.append([s1,s2,s3])
        a.append(s2)
        a.append(s1)
        d[s1] = 0
        d[s2] = 0
    for i in a:
        d[i]+=1
    for i in p:
        if d[i[0]]==1:
            ans.append(i)
        else:
            ans.append([i[2],i[0],i[1]])
    ans.sort()
    for i in ans:
        print(*i)
turbo()