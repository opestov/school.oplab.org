#include <iostream>

using namespace std;
long long a[1000][3];

int main()
{
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < n; ++i)
    {
        cin >> a[i][0] >> a[i][1] >> a[i][2];
    }
    long long q, v;
    for (int i = 0; i < m; i++)
    {
        v = 0;
        cin >> q;
        for (int j = 0; j < n; j++)
            if (a[j][0] <= q && a[j][1] >= q)
                if ((q - a[j][0])%2 == 0)
                    v += a[j][2];
                else
                    v-=a[j][2];
        cout << v << endl;

    }
    return 0;
}
