#32
n = int(input())
a = [0]*n
b = [0]*n
s = 0
sr = 0
z = 0
arm = 0
for i in range(n):
    a[i], b[i] = map(int, input().split())
    s += a[i]
for i in range(n-1,-1,-1):
    p = ((s-sr)-1) // 2
    if a[i] > p:
        arm += a[i] -p
        z += b[i]*(a[i] - p)
    sr += min(p,a[i])
print(z)