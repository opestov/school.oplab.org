#32
n = int(input())
a = [[0] * 2 for i in range(n)]
s = 0
sr = 0
z = 0
arm = 0
for i in range(n):
    a[i][0], a[i][1] = map(int, input().split())
    s += a[i][0]
a.sort()
for i in range(n-1,-1,-1):
    p = ((s-sr)-1) // 2
    if a[i][0]> p:
        arm += a[i][0]-p
        z += a[i][1]*(a[i][0]- p)
    sr += min(p,a[i][0])
print(z)