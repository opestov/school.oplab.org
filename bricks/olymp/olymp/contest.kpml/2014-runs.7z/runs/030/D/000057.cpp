#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>


int main()
{
    std::vector<long long> v(1000 * 1000 * 1000, 0);
    //v.resize(1000 * 1000 * 1000, 0);
    //long long h[1000000000];
    int n, m;
    std::cin >> n >> m;
    int a, b, c;
    for (int i = 0; i < n; ++i) {
        std::cin >> a >> b >> c;
        for (int j = 0; j + a <= b; ++j) {
            if (j % 2 == 0) {
                v[j + a] += c;
            } else
                v[j + a] -= c;
        }
        //std::cout << "ok\n";
    }

    /*for (int i = 0; i < 10; ++i) {
        std::cout << v[i] << std::endl;
    }*/

    int t;
    for (int i = 0; i < m; ++i) {
        std::cin >> t;
        std::cout << v[t];
    }

    return 0;
}