#include <iostream>
#include <cstdio>
#include <cmath>

int main()
{
    int n;
    std::cin >> n;
    int h[n];
    for (int i = 0; i < n; ++i) {
        std::cin >> h[i];
    }

    int ans = 0;
    for (int i = 0; i < n; i++) {
        if (h[i] >= i + 1) {
            ans++;
        }
    }
    std::cout << ans << std::endl;
    for (int i = 0; i < ans; ++i) {
        std::cout << i + 1 << " " << i + 1 << std::endl;
    }

    return 0;
}