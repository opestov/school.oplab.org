#include <iostream>
#include <cstdio>
#include <cmath>

int main()
{
    long long n, h;
    std::cin >> n >> h;
    long long m[n];

    for (long long i = 0; i < n; ++i) {
        std::cin >> m[i];
    }

    long long  ans = 999999999999999999;

    for (long long i = 0; i < (n - h) + 1; ++i) {
        long long t = 0, ts = 0;
        bool f = true;
        for (long long j = 0; j < h; ++j) {
            ts = j - m[i + j] + 1;
            if (ts < 0) {
                //std::cout << i + j << " " << j << std::endl;
                f = false;
                break;
            }
            t += ts;
        }
        if (f) {
            ans = std::min(ans, t);
        }
    }
    if (ans != 999999999999999999)
        std::cout << ans << std::endl;
    else
        std::cout << -1 << std::endl;
    return 0;
}