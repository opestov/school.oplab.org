//package H;

//import javafx.collections.transformation.SortedList;

import java.util.*;

/**
 * Created by user on 09.11.14.
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        ArrayList<String> A = new ArrayList<String>();
        ArrayList<String> B = new ArrayList<String>();
        ArrayList<String> C = new ArrayList<String>();
        for (int i = 0; i < n; i++) {
            String[] strs = sc.nextLine().split(" ");
            A.add(strs[0]);
            B.add(strs[1]);
            C.add(strs[2]);
        }
        ArrayList<String> D = new ArrayList<String>();

        D.addAll(A);
        D.addAll(B);
        HashMap<Object, Integer> used = new HashMap<Object, Integer>();
        for (int i = 0; i < 2*n; i++) {
            if (used.containsKey(D.get(i))) {
                used.put(D.get(i), used.get(D.get(i)) + 1);
            } else {
                used.put(D.get(i), 1);
            }
        }
        ArrayList<String> names = new ArrayList<String>();
        for (int i = 0; i < n; i++) {
            StringBuilder builder = new StringBuilder();
            if (used.get(A.get(i)) > 1) {
                builder.append(C.get(i));
                builder.append(" ");
                builder.append(A.get(i));
                builder.append(" ");
                builder.append(B.get(i));
            } else {
                builder.append(A.get(i));
                builder.append(" ");
                builder.append(B.get(i));
                builder.append(" ");
                builder.append(C.get(i));
            }
            names.add(builder.toString());
        }
        Object[] NMS = names.toArray();
        java.util.Arrays.sort(NMS);
        for (int i = 0; i < n; i++) {
            System.out.println(NMS[i]);
        }
        sc.close();
    }
}
