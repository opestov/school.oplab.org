//package H;

import java.util.*;

/**
 * Created by user on 09.11.14.
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        ArrayList<String> A = new ArrayList<String>();
        ArrayList<String> B = new ArrayList<String>();
        ArrayList<String> C = new ArrayList<String>();
        for (int i = 0; i < n; i++) {
            String[] strs = sc.nextLine().split(" ");
            A.add(strs[0]);
            B.add(strs[1]);
            C.add(strs[2]);
        }
        ArrayList<String> D = new ArrayList<String>();
        D.addAll(A);
        D.addAll(B);
        D.sort(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });
        HashMap<String, Integer> used = new HashMap<String, Integer>();
        for (int i = 0; i < 2*n; i++) {
            if (!used.containsKey(D.get(i))) {
                int a = D.lastIndexOf(D.get(i)) - D.indexOf(D.get(i));
                used.put(D.get(i), a);
            }
        }
        ArrayList<String> names = new ArrayList<String>();
        for (int i = 0; i < n; i++) {
            StringBuilder builder = new StringBuilder();
            if (used.get(A.get(i)) > 0) {
                builder.append(C.get(i));
                builder.append(" ");
                builder.append(A.get(i));
                builder.append(" ");
                builder.append(B.get(i));
            } else {
                builder.append(A.get(i));
                builder.append(" ");
                builder.append(B.get(i));
                builder.append(" ");
                builder.append(C.get(i));
            }
            names.add(builder.toString());
        }
        names.sort(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });
        for (int i = 0; i < n; i++) {
            System.out.println(names.get(i));
        }
        sc.close();
    }
}
