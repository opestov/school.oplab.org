#include <iostream>
#include <cstdio>
#include <cmath>

int main()
{
    long long n, a, b;
    std::cin >> n;
    for (long long i = 0; i < n; ++i) {
        std::cin >> a;
        b = a % 100;
        a /= 100;
        if ((a * a + b * b) % 7 == 1) {
            std::cout << "YES\n";
        } else {
            std::cout << "NO\n";
        }
    }

    //std::cout << a << " " << b << std::endl;

    return 0;
}