// Task F
// 030 team
//package F;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int d = NOD(a, b);
        int k = b / d;
        k *= a;
        int C = k/d;
        int muls[] = new int[1000];
        int S = 0;
        int until = (int)Math.sqrt(C)+1;
        int min = 1000000001, x = 0, y = 0;
        for (int i = 1; i < until; i++) {
            if (C % i == 0) {
                int _x = C/i;
                int M = Math.abs(_x-i);
                if (M < min) {
                    min = M;
                    x = _x;
                    y = i;
                }
            }
        }
        x *= d;
        y *= d;
        if (x > y) {
            k = x;
            x = y;
            y = k;
        }
        System.out.printf("%d %d\n", x, y);
        sc.close();
    }

    public static int NOD(int a, int b) {
        int d = b;
        while (d - a != 0) {
            if (d > a) {
                d = d- a;
            } else {
                a = a-d;
            }
        }
        return d;
    }

}
