// Task F
// 030 team
//package F;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long a = sc.nextInt();
        long b = sc.nextInt();
        long d = NOD(a, b);
        long k = b / d;
        k *= a;
        long C = k/d;
        long muls[] = new long[1000];
        long S = 0;
        long until = (long)Math.sqrt(C)+1;
        long min = 1000000001, x = 0, y = 0;
        for (long i = 1; i < until; i++) {
            if (C % i == 0) {
                long _x = C/i;
                long M = Math.abs(_x-i);
                if (M < min) {
                    min = M;
                    x = _x;
                    y = i;
                }
            }
        }
        x *= d;
        y *= d;
        if (x > y) {
            k = x;
            x = y;
            y = k;
        }
        System.out.printf("%d %d\n", x, y);
        sc.close();
    }

    public static long NOD(long a, long b) {
        long d = b;
        while (d - a != 0) {
            if (d > a) {
                d = d- a;
            } else {
                a = a-d;
            }
        }
        return d;
    }

}
