#include <iostream>
/*���������*/
using namespace std;

int d2(int b)
{
    if (b % 2 == 1) return (b / 2) + 1;
    else return b / 2;
}

int pr (int x)
{
    if (x == 1) return 0;
    else return 1;
}

/*
4 4
1 2
1 4
1 2 3 4
*/

int main()
{
    int n = 0;
    int m = 0;
    cin >> n >> m;
    int d[2][2];
    cin >> d[0][0] >> d[0][1] >> d[1][0] >> d[1][1];
    int s[100000];
    int a = 0;
    int b = 0;
    int c = 0;
    for (int i = 0; i < n; i++) {
        cin >> s[i];
    }
    for (int i = 0; i < n; i++) {
        if (s[i] >= d[0][0] && s[i] >= d[1][0] && s[i] <= d[0][1] && s[i] <= d[1][1]) {
            b++;
        }
        else if (s[i] >= d[0][0] && s[i] <= d[0][1]) a++;
        else if (s[i] >= d[1][0] && s[i] <= d[1][1]) c++;
    }
    //cout << a << ' '<< b << ' ' <<c << endl;
    if(b>=m){
        if(m%2==0){
            cout << "Draw" << endl;
            return 0;
        }else
        {
            cout << "Petya" << endl;
            return 0;
        }
    }
    int x=0,y=0;
    int qwe;
    if(b%2==0){
        if(m%2==0){
            qwe=(m-b)/2;
            if(a>=qwe){
                x+=qwe;
                y+=min(c,qwe);
            }
            if(a<qwe){
                y+=qwe;
                x+=a;
            }
        }else
        {
            x++;
            int qwe=(m-b)/2;
            if(c>=qwe){
                y+=qwe;
                x+=a;
            }
            if(a<qwe){
                x+=qwe;
                y+=min(c,qwe);
            }
        }
    }else
    {
        x++;
        if(m%2==0){
            qwe=(m-b-1)/2;
            if(a>=qwe){
                x+=qwe;
                y+=c+1;
            }
            if(a<qwe){
                x+=a;
                y+=qwe+1;
            }
        }else{
            qwe=(m-b)/2;
            if(a>=qwe){
                x+=qwe;
                y+=min(c,qwe);
            }
            if(a<qwe){
                x+=a;
                y+=qwe;
            }
        }
    }

    if (x > y) {
        cout << "Petya" << endl;
        return 0;
    }
    if (x < y) {
        cout << "Vasya" << endl;
        return 0;
    }
    if (x == y) {
        cout << "Draw";
        return 0;
    }
}
