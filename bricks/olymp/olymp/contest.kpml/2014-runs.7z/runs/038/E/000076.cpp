#include <iostream>
#include <string>
/*���������*/
using namespace std;

int d2(int b)
{
    if (b % 2 == 1) return b / 2 + 1;
    else return b / 2;
}

int pr (int x)
{
    if (x == 1) return 0;
    else return 1;
}

/*
4 4
1 2
1 4
1 2 3 4
*/

int main()
{
    int n = 0;
    int m = 0;
    cin >> n >> m;
    int d[2][2];
    cin >> d[0][0] >> d[0][1] >> d[1][0] >> d[1][1];
    int s[10000];
    int k = 0;
    int z[2];
    for (int i = 0; i < n; i++) {
        cin >> s[i];
    }
    for (int i = 0; i < n; i++) {
        if (s[i] >= d[0][0] && s[i] >= d[1][0] && s[i] <= d[0][1] && s[i] <= d[1][1]) {
            k++;
        }
    }
    if (k < m) {
        z[0] = d2(k);
        z[1] = k - z[0];
        m -= k;
        bool kol[10000];
        for (int i = 0; i < n; i++) {
            if (s[i] >= d[0][0] && s[i] >= d[1][0] && s[i] <= d[0][1] && s[i] <= d[1][1]) {
                kol[i] = true;
            }
            else kol[i] = false;
        }
        int st = 0;
        while (m != 0) {
            for (int i = 0; i < n; i++) {
                if (kol[i] == false && s[i] >= d[st][0] && s[i] <= d[st][1]) {
                    z[st]++;
                    kol[i] = true;
                    break;
                }
            }
            m--;
            st = pr(st);
        }
    }
    else {
        z[0] = d2(m);
        z[1] = m - z[0];
    }
    if (z[0] > z[1]) {
        cout << "Petya" << endl;
        return 0;
    }
    if (z[0] < z[1]) {
        cout << "Vasya" << endl;
        return 0;
    }
    if (z[0] == z[1]) {
        cout << "Draw";
        return 0;
    }
}
