﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace drjiggjkjdbr
{
    class Program
    {
        public void run4()
        {
            int n;
            int h;
        }

        public void run3()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string s = Console.ReadLine();
                int a = int.Parse(s.Remove(0, 2)), b = int.Parse(s.Remove(s.Length - 2, 2));
                //Console.WriteLine(a + " " + b + " " + (a * a + b * b % 7));
                if ((a * a + b * b) % 7 == 1)
                    Console.WriteLine("YES");
                else Console.WriteLine("NO");
            }
            
        }
        
        public void run2()
        {
            int n = int.Parse(Console.ReadLine());
            var a = Console.ReadLine().Split().Select(x1 => int.Parse(x1)).ToList();
            a.Add(0);
            for (int i = 0; i < n+1; i++)
            {
                if (a[i] <= i)
                {
                    Console.WriteLine(i);
                    for (int j = 1; j < i+1; j++)
                    {
                        Console.WriteLine((j)+" "+(i+1-j));
                    }
                    return;
                }
            }
        }
        public long NOD(long a,long b)
        {
            if (a < b)
            {
                a += b;
                b = a - b;
                a = a - b;
            }
            while (a*b!=0)
            {
                a = a % b;
                a += b;
                b = a - b;
                a = a - b;
            }
            return b+a;
        }
        public void run1()
        {
            int[] sa = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            int a = sa[0],b=sa[1];
            long ma=1;
            for (long i = 1; i*i <= a*b; i++)
            {
                if (a * b % i == 0)
                {
                    if (NOD(i, a * b / i) == NOD(a, b) && i > ma)
                        ma = i;
                }

            }
            long x1=ma, y1=a*b/ma;
            if (x1>y1)
            {
                Console.WriteLine(y1+" "+x1); 
            }else
            {
                Console.WriteLine(x1+" "+y1);
            }
        }
        public static void Main()
        {
            var r1=new Program();
            r1.run2();
        }
        
    }
}
