﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace drjiggjkjdbr
{
    class Program
    {
        public void run4()
        {
            var sr = Console.ReadLine().Split().Select(x1 => int.Parse(x1)).ToArray();
            int n = sr[0];
            int m = sr[1];
            int[] lv=new int[n];
            int[] rv=new int[n];
            int[] mv=new int[n];
            for (int i = 0; i < n; i++)
			{
                var sr1 = Console.ReadLine().Split().Select(x1 => int.Parse(x1)).ToArray();
                lv[i] = sr1[0];
                rv[i] = sr1[1];
                mv[i] = sr1[2];
			}
            Dictionary<int, int> dic = new Dictionary<int, int>();
            int[] b = new int[m];
            for (int i = 0; i < m; i++)
            {
                var r = int.Parse(Console.ReadLine());
                dic.Add(r, 0);
                b[i] = r;
            }
            
            for (int i = 0; i < n; i++)
            {
                for (var j = 0; j < m; ++j)
                {
                    int k = b[j];
                    if (k >= lv[i] && k <= rv[i])
                    {
                        if ((k - lv[i] )% 2 == 0) dic[k] += mv[i]; else dic[k] -= mv[i];
                    }
                }
            }
            foreach (var item in dic)
            {
                Console.WriteLine(item.Value);
            }
        }

        public void run3()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string s = Console.ReadLine();
                int a = int.Parse(s.Remove(0, 2)), b = int.Parse(s.Remove(s.Length - 2, 2));
                //Console.WriteLine(a + " " + b + " " + (a * a + b * b % 7));
                if ((a * a + b * b) % 7 == 1)
                    Console.WriteLine("YES");
                else Console.WriteLine("NO");
            }
            
        }
        
        public void run2()
        {
            int n = int.Parse(Console.ReadLine());
            var a = Console.ReadLine().Split().Select(x1 => int.Parse(x1)).ToList();
            a.Add(0);
            for (int i = 0; i < n+1; i++)
            {
                if (a[i] <= i)
                {
                    Console.WriteLine(i);
                    for (int j = 1; j < i+1; j++)
                    {
                        Console.WriteLine((j)+" "+(i+1-j));
                    }
                    return;
                }
            }
        }
        public long NOD(long a,long b)
        {
            if (a < b)
            {
                a += b;
                b = a - b;
                a = a - b;
            }
            while (a*b!=0)
            {
                a = a % b;
                a += b;
                b = a - b;
                a = a - b;
            }
            return b+a;
        }
        public void run1()
        {
            int[] sa = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            int a = sa[0],b=sa[1];
            long ma=1;
            for (long i = 1; i*i <= a*b; i++)
            {
                if (a * b % i == 0)
                {
                    if (NOD(i, a * b / i) == NOD(a, b) && i > ma)
                        ma = i;
                }

            }
            long x1=ma, y1=a*b/ma;
            if (x1>y1)
            {
                Console.WriteLine(y1+" "+x1); 
            }else
            {
                Console.WriteLine(x1+" "+y1);
            }
        }
        public static void Main()
        {
            var r1=new Program();
            r1.run4();
        }
        
    }
}


/*
2 6
1 6 7
3 7 2
1
2
3
6
7
8
 
 
 
 
*/