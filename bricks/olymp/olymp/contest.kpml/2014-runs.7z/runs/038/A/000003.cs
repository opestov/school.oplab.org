﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace drjiggjkjdbr
{
    class Program
    {
        public void run1()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string s = Console.ReadLine();
                int a = int.Parse(s.Remove(0, 2)), b = int.Parse(s.Remove(s.Length - 2, 2));
                //Console.WriteLine(a + " " + b + " " + (a * a + b * b % 7));
                if ((a * a + b * b) % 7 == 1)
                    Console.WriteLine("YES");
                else Console.WriteLine("NO");
            }
            
        }
        public static void Main()
        {
            var r1=new Program();
            r1.run1();
        }
        
    }
}
