﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace drjiggjkjdbr
{
    class Program
    {
        public void run5()
        {
            int[] sr = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            int n = sr[0];
            int h = sr[1];
            long[] din = new long[n];
            int[] a = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            for (int i = 0; i < h; i++)
            {
                din[0]+=i+1-a[i];
            }
            for (int i = 1; i <= n-h; i++)
            {
                din[i] = din[i - 1] + a[i - 1] - a[i + h - 1];
            }
            bool[] bo = new bool[n];
            int old = 0;
            for (int i = 0; i < n; i++)
            {
                if (a[i] > 1)
                {
                    for (int j = Math.Max(old,i-a[i]+2); j < i+1; j++)
                    {
                        bo[j] = true;
                    }
                    old = i + 1;
                }
            }
            bool an = false;
            long mi = -1;
            for (int i = 0; i < n-h+1; i++)
            {
                if (!bo[i] && (!an || mi > din[i]))
                {
                    an = true;
                    mi = din[i];
                }
            }
            if (!an) Console.WriteLine("-1"); else Console.WriteLine(mi);
        }
        public void run4()
        {
            int n = int.Parse(Console.ReadLine());
            var a = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            long sum = 0;
            for (int i = 0; i < n; i++)
            {
                sum += a[i];
            }
            System.Array.Sort(a, (x, y) => y - x);
            for (int i = 0; i < n; i++)
            {
                if (sum >= a[i] * (n - i)) { Console.WriteLine(i); return; }
            }
        }

        public void run3()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string s = Console.ReadLine();
                int a = int.Parse(s.Remove(0, 2)), b = int.Parse(s.Remove(s.Length - 2, 2));
                //Console.WriteLine(a + " " + b + " " + (a * a + b * b % 7));
                if ((a * a + b * b) % 7 == 1)
                    Console.WriteLine("YES");
                else Console.WriteLine("NO");
            }
            
        }
        
        public void run2()
        {
            int n = int.Parse(Console.ReadLine());
            var a = Console.ReadLine().Split().Select(x1 => int.Parse(x1)).ToList();
            a.Add(0);
            for (int i = 0; i < n+1; i++)
            {
                if (a[i] <= i)
                {
                    Console.WriteLine(i);
                    for (int j = 1; j < i+1; j++)
                    {
                        Console.WriteLine((j)+" "+(i+1-j));
                    }
                    return;
                }
            }
        }
        public long NOD(long a,long b)
        {
            if (a < b)
            {
                a += b;
                b = a - b;
                a = a - b;
            }
            while (a*b!=0)
            {
                a = a % b;
                a += b;
                b = a - b;
                a = a - b;
            }
            return b+a;
        }
        public void run1()
        {
            int[] sa = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            long a = sa[0],b=sa[1];
            if (a < b)
            {
                a += b;
                b = a - b;
                a = a - b;
            }
            long ma=1;
            long mi = 2000000000;
            for (long i = 1; a-b*i*i>=0 ; i++)
            {
                if (a%i==0)
                {
                    if (NOD(NOD(a,b),i)==1 && i>ma && Math.Abs(a/i-b*i)<mi){
                        ma = i;
                        mi=Math.Abs(a/i-b*i);//<mi
                    }
                }

            }
            //Console.WriteLine(ma);
            long x1=a/ma, y1=b*ma;
            if (x1>y1)
            {
                Console.WriteLine(y1+" "+x1); 
            }else
            {
                Console.WriteLine(x1+" "+y1);
            }
        }
        public static void Main()
        {
            var r1=new Program();
            r1.run5();
        }
        
    }
}


/*
2 6
1 6 7
3 7 2
1
2
3
6
7
8
 
 
 
 
*/