﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace drjiggjkjdbr
{
    class Program
    {
        public void run3()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string s = Console.ReadLine();
                int a = int.Parse(s.Remove(0, 2)), b = int.Parse(s.Remove(s.Length - 2, 2));
                //Console.WriteLine(a + " " + b + " " + (a * a + b * b % 7));
                if ((a * a + b * b) % 7 == 1)
                    Console.WriteLine("YES");
                else Console.WriteLine("NO");
            }
            
        }

        /*
4
Ivanov Ivan Ivanovich
Ivan Borisovich Petrov
Sergey Ivanovich Sidorov
Pavlov Sergey Borisovich
         */

        public void run2()
        {
            int m = int.Parse(Console.ReadLine());
            string[][] user = new string[m][];
            for (int i = 0; i < m; i++)
            {
                var s = Console.ReadLine();
                user[i] = new string[3];
                user[i] = s.Split(' ');
                //user[i] = new string[3];
                //user[i][0] = sr[0];
                //user[i][1] = sr[1];
                //user[i][2] = sr[2];
            }
            for (int i = 0; i < m; i++)
            {
                for (int a = 0; a < m; a++)
                {
                    if (user[i][0] == user[a][1] && a != i)
                    {
                        string t;
                        t = user[i][2];
                        //Console.WriteLine("X", t);
                        user[i][2] = user[i][1];
                        user[i][1] = t;
                        t = user[i][1];
                        user[i][1] = user[i][0];
                        user[i][0] = t;
                    }
                }
            }
            //Console.WriteLine("Z", user[1][1]);
            System.Array.Sort(user,(x1,y1)=>string.Compare(x1[0],y1[0]));
            //Console.WriteLine("Z", user[1][1]);
            for (int i = 0; i < m; i++)
            {
                Console.WriteLine(user[i][0]+ " "+ user[i][1]+ " "+ user[i][2]);
            }
        }
        public void run1()
        {
            bool bo=true;
            int[] sa = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            int a = sa[0],b=sa[1];
            if(a<b){
                a+=b;
                b=a-b;
                a=a-b;
                bo = false;
            }
            long ma=1;
            for (long i = 0; i*i < a/b; i++)
            {
                if ((i > ma)&&a%i==0)
                    ma = i;
            }
            //Console.WriteLine(a+" "+b+" "+ma);
            if (bo)
            {
                Console.WriteLine((a/ma)+" "+(b*ma));
            }
            if (!bo)
            {
                Console.WriteLine((b*ma)+" "+(a/ma));
            }
        }
        public static void Main()
        {
            var r1=new Program();
            r1.run1();
        }
        
    }
}
