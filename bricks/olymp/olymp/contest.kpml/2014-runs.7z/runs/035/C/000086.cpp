#include <iostream>
using namespace std;
unsigned long long rez(unsigned long long a){
	unsigned long long ans = 1;
	while(a/10>0){
		a=a/10;
		ans++;
	}
return ans;
}
bool check(unsigned long long x){

	while(x/10>1){
		if(x%10 != x/(rez(x)*10)){
			cout << rez(x) << " ";
			return false;
		}
	}
	return true;
}

int main (){
	unsigned long long n;
	cin >> n;
	unsigned long long ans=0;
	for(unsigned long long i=0; i<n; i++){
		unsigned long long a, b;
		cin >> a >> b;
		if(a-b==0){
			if(a>1)
				a--;
			b++;
		}
		unsigned long long all[b-a];
		for(unsigned long long i=0; i<b-a-2; i++){
			if(check(all[i]+a))
				if(check(all[i+2]+a))
				ans++;	
		}
		cout << ans << endl;
	}

	return 0;
}
