﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] s = Console.ReadLine().Split();
            int m = int.Parse(s[1]);
            int n = int.Parse(s[0]);
            
            s = Console.ReadLine().Split();
            int l1 = int.Parse(s[0]);
            int r1 = int.Parse(s[1]);
            
            s = Console.ReadLine().Split();
            int l2 = int.Parse(s[0]);
            int r2 = int.Parse(s[1]);
            
            s = Console.ReadLine().Split();
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
                a[i] = int.Parse(s[i]);
            
            int mp = 0;
            int mv = 0;
            int mo = 0;
            int p = 0;
            int v = 0;

            for (int i = 0; i < n; i++)
            {
                if ((a[i] <= r1) && (a[i] >= l1)) mp++;
                if ((a[i] <= r2) && (a[i] >= l2)) mv++;
                if ((a[i] <= r1) && (a[i] >= l1) && (a[i] <= r2) && (a[i] >= l2)) mo++;
            }
            mp = mp - mo;
            mv = mv - mo;
            bool b = false;

            while ((m > 0)&&(mo>0))
            {
                if (mo > 0) 
                { 
                    mo--;
                    p++;
                    m--;
                    if (mo == 0) b = true;
                }

                if ((mo > 0) && (m > 0))
                {
                    mo--;
                    v++;
                    m--;
                }
            }

            if ((mo == 0) && (m > 0))
            {
                if ((b == true)&&(mv>0)) 
                {
                    v++;
                    mv--;
                    m--;
                }

                while ((m>0)&&((mv>0)||(mp>0)))
                {
                    if (mp > 0)
                    {
                        mp--;
                        p++;
                        m--;
                    }
                    if ((mv > 0) && (m > 0))
                    {
                        mv--;
                        v++;
                        m--;
                    }
                }
            }

            if (p > v) Console.WriteLine("Petya");
            if (p == v) Console.WriteLine("Draw");
            if (p < v) Console.WriteLine("Vasya");
        }
    }
}
