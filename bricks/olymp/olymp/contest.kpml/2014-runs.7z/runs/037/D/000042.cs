﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {

        static void Main(string[] args)
        {
            string[] s = Console.ReadLine().Split();
            int n = int.Parse(s[0]);
            int m = int.Parse(s[1]);
            
            int[] l=new int[n];
            int[] r=new int[n];
            int[] x=new int[n];
            for (int i = 0; i < n; i++)
            {
                s = Console.ReadLine().Split();
                l[i] = int.Parse(s[0]);
                r[i] = int.Parse(s[1]);
                x[i] = int.Parse(s[2]);
            }

            int[] q=new int[m];
            for (int i = 0; i < m; i++)
                q[i] = int.Parse(Console.ReadLine());
            int[]o=new int[m];

            for (int i = 0; i < m; i++)
            {
                for (int i1 = 0; i1 < n; i1++)
                    if ((l[i1] <= q[i]) && (q[i] <= r[i1]))
                        if ((q[i] - l[i1] + 1) % 2 == 1) o[i] = o[i] + x[i1];
                        else o[i] = o[i] - x[i1];
                Console.WriteLine(o[i]);
            }


        }
    }
}
