﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] s;
            string[] s1 = new string[n];
            string[] s2 = new string[n];
            string[] s3 = new string[n];
            for (int i = 0; i < n; i++)
            {
                s = Console.ReadLine().Split();
                s1[i] = s[0];
                s2[i] = s[1];
                s3[i] = s[2];
            }
            bool f;
            var m=new SortedSet<string>();

            for (int i = 0; i < n; i++)
            {
                int i1 = 0;
                f = false;
                while ((f==false)&&(i1<n))
                {
                    if (s1[i] == s2[i1])
                    {
                        string ds = s1[i];
                        s1[i] = s3[i];
                        s3[i] = s2[i];
                        s2[i] = ds;
                        f = true;
                        m.Add(s1[i]+" "+s2[i]+" "+s3[i]);
                        m.Add(s1[i1] + " " + s2[i1] + " " + s3[i1]);
                    }
                    if (s1[i1] == s2[i])
                    {
                        string ds = s1[i1];
                        s1[i1] = s3[i1];
                        s3[i1] = s2[i1];
                        s2[i1] = ds;
                        f = true;
                        m.Add(s1[i1] + " " + s2[i1] + " " + s3[i1]);
                        m.Add(s1[i] + " " + s2[i] + " " + s3[i]);
                    }
                    if (f==false)i1++;   
                }
            }
            s = new string[n];
            m.CopyTo(s,0);
            for (int i = 0; i < m.Count; i++)
                Console.WriteLine(s[i]);
        }
    }
}
