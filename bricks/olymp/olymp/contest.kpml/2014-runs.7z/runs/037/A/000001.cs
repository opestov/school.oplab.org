﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] a=new int[n];
            for (int i = 0; i < n; i++)
                a[i] = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int r = (a[i] / 100) * (a[i] / 100) + (a[i] % 100) * (a[i] % 100);
                if (r % 7 == 1) Console.WriteLine("YES");
                else Console.WriteLine("NO");
            }
        }
    }
}
