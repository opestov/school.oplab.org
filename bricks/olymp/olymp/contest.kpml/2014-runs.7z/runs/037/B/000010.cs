﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int c = 0;
            int d = 0;
            bool b = false;
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            int[] k = new int[n+1];
            string[] s = Console.ReadLine().Split(' ');
            for (int i = 0; i < n; i++)
                a[i] = int.Parse(s[i]);
            
            while (b == false) 
            {
                a[c] = 1;
                c++;
                for (int i = 0; i < n; i++) if (a[i]>0) a[i]--;
                
                b = true;
                d = 0;
                while ((d < n) && (b == true))
                {
                    if (a[d] != 0) b = false;
                    d++;
                }
            }
            Console.WriteLine(c);
            for (int i = 1; i < c+1; i++)
                Console.WriteLine(i+" "+i);
        }
    }
}
