/*
#include <iostream>
#include <vector>
#include <math.h>
#include <string>
int main(){

    unsigned int t; // amount keys
    std::cin >> t;
    std::vector<unsigned int> keys;
    for(unsigned int i=0;i<t;i++){
        unsigned int key;
        std::cin >> key;
        keys.push_back(key);
    }
    std::vector<std::string> results;
    for(unsigned int i=0;i<keys.size(); i++){
        unsigned int one = floor(keys[i]/100);
        keys[i] -= one*100;
        unsigned int result = one*one + keys[i]*keys[i];
        if(result%7==1)
            results.push_back("YES");
        else
            results.push_back("NO");
    }
    for(unsigned int i=0;i<results.size();i++)
        std::cout << results[i] << std::endl;
    return 0;
}
*/

#include <iostream>
#include <vector>

struct kletka{
    unsigned int short x, y;
    kletka(unsigned short _x, unsigned short _y){
        x = _x;
        y = _y;
    }
};

int main(){
    unsigned int short count_stolb;
    std::cin >> count_stolb;
    std::vector<kletka> kletks;
    for(unsigned short i=0; i<count_stolb; i++){
        unsigned short amountfields;
        std::cin>> amountfields;
        for(unsigned int i2=0; i2<amountfields; i2++)
            kletks.push_back(kletka(i+1, i2+1));
    }
    std::vector<unsigned int> NomersKillKletks;
    std::vector<kletka> SoldierKletks;
    unsigned int sizek = kletks.size();
    while(NomersKillKletks.size()!=sizek){
    for(unsigned int i=0; i<kletks.size() && NomersKillKletks.size()!=kletks.size();i++){
            //unsigned int beginNomersKillKletks = NomersKillKletks.size();
            unsigned short x = kletks[i].x;
            unsigned short y = kletks[i].y;
            //std::cout << x << y << std::endl;
            SoldierKletks.push_back(kletka(x, y));
            //unsigned short amountkillfields=0;
            for(short i2=0; i2<kletks.size();i2++){
                if(kletks[i2].x == x){
                    kletks.erase(kletks.begin()+i2);
                    NomersKillKletks.push_back(i2);

                    i2 = -1;

                }
                else{
                    if(kletks[i2].y == y){
                        kletks.erase(kletks.begin()+i2);
                        NomersKillKletks.push_back(i2);

                        i2 = -1;
                    }
                }

            }
        }
    }
    std::cout << SoldierKletks.size() << std::endl;
    for(unsigned int i=0; i < SoldierKletks.size(); i++){
        std::cout << SoldierKletks[i].x << " " << SoldierKletks[i].x << std:: endl;
    }
    return 0;
}

