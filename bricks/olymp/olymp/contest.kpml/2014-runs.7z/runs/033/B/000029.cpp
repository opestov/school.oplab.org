

#include <iostream>
#include <vector>

struct kletka{
    unsigned int short x, y;
    kletka(unsigned short _x, unsigned short _y){
        x = _x;
        y = _y;
    }
};

int main(){
    unsigned int short count_stolb;
    std::cin >> count_stolb;
    std::vector<unsigned int> razmer;
    for(unsigned short i=0; i<count_stolb; i++){
        unsigned int razmers;
        std::cin >> razmers;
        razmer.push_back(razmers);
    }
    kletka Soldier(1, 1);
    std::vector<kletka> SoldierKletks;
    for(unsigned short i=0; i<count_stolb; i++)
    {
        if(Soldier.y<=razmer[i]){
            SoldierKletks.push_back(Soldier);
            Soldier.y+=1;
            Soldier.x+=1;
        }
    }
    std::cout << SoldierKletks.size() << std::endl;
    for(unsigned int i=0; i < SoldierKletks.size(); i++){
        std::cout << SoldierKletks[i].x << " " << SoldierKletks[i].x << std:: endl;
    }
    return 0;
}

