#include <iostream>
#include <vector>
#include <math.h>
#include <string>
int main(){

    unsigned int t; // amount keys
    std::cin >> t;
    std::vector<unsigned int> keys;
    for(unsigned int i=0;i<t;i++){
        unsigned int key;
        std::cin >> key;
        keys.push_back(key);
    }
    std::vector<std::string> results;
    for(unsigned int i=0;i<keys.size(); i++){
        unsigned int one = floor(keys[i]/100);
        keys[i] -= one*100;
        unsigned int result = one*one + keys[i]*keys[i];
        if(result%7==1)
            results.push_back("YES");
        else
            results.push_back("NO");
    }
    for(unsigned int i=0;i<results.size();i++)
        std::cout << results[i] << std::endl;
    return 0;
}
