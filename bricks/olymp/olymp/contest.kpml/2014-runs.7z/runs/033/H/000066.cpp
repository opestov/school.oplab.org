#include <iostream>
#include <vector>
#include <cstring>
#include <string>

struct FIO
{
    std::string FirstWord, SecondWord, TherdWord;
    FIO(std::string _FirstWord, std::string _SecondWord, std::string _TherdWord){
        FirstWord = _FirstWord;
        SecondWord = _SecondWord;
        TherdWord = _TherdWord;
    }
};

struct TrueFIO{
    std::string Name, SecondName, Father;
    TrueFIO(std::string _Name, std::string _SecondName, std::string _TherdWord){
        Name = _Name;
        SecondName = _SecondName;
        Father = _TherdWord;
    }
};

int main(){
    unsigned short int count = 4;
    std::cin >> count;
    std::vector<FIO> Words;
    for(unsigned short i=0; i<count;i++){
        std::string FirstWord, SecondWord, TherdWord;
        std::cin >> FirstWord >> SecondWord >> TherdWord;
        Words.push_back(FIO(FirstWord, SecondWord, TherdWord));
    }
    // 1 Sravnivaem
    std::vector<TrueFIO> Result;
    for(unsigned short i=0; i<Words.size();i++){
        std::string FirstWord = Words[i].FirstWord;
        bool Find = false;
        for(unsigned short i2=0; i2<Words.size();i2++){
            if(i2!=i){
            if(FirstWord==Words[i2].FirstWord || FirstWord==Words[i2].SecondWord){
                Result.push_back(TrueFIO(FirstWord, Words[i].TherdWord, Words[i].SecondWord));
                Find = true;
                break;
            }
            }
        }
        if(!Find)
            Result.push_back(TrueFIO(Words[i].SecondWord, FirstWord, Words[i].TherdWord));
    }
    for(unsigned short i=0; i<Result.size();i++){
        const char *SecondName = Result[i].SecondName.c_str();
        for(unsigned short i2=0; i2<Result.size();i2++){
            if(i2!=i){
                const char *SecondNameTwo = Result[i2].SecondName.c_str();
                if(std::strcmp(SecondName, SecondNameTwo) < 0){
                    TrueFIO FIO = Result[i];
                    Result[i] = Result[i2];
                    Result[i2] = FIO;
                }
            }
        }
    }
    for(unsigned short i=0; i<Result.size();i++){
        std::cout<<Result[i].SecondName<<" "<<Result[i].Name<<" "<<Result[i].Father<<std::endl;
    }
}
