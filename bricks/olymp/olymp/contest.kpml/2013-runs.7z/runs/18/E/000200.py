def yra(a):
    return -(a[0])
def yras(a):
    return -(a[1])
fin = open("division.in", "r")
fout = open("division.out", "w")
n = int(fin.readline())
a = []
for i in range(n):
    x, y = [int(i) for i in fin.readline().split()]
    a.append([x, y])
a = sorted(a, key = yra)
old = a[0][0]
for i in range(1, n):
    if a[i][0] != old:
        fout.write("x " + str(a[i][0] + 1) + "\n")
    old = a[i][0]
a = sorted(a, key = yras)
old = a[0][1]
for i in range(1, n):
    if a[i][1] != old:
        fout.write("y " + str(a[i][1] + 1) + "\n")
    old = a[i][1]    
fin.close()
fout.close()
