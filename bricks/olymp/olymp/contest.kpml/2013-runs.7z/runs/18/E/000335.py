def yra(a):
    return -(a[0] + a[1] / 1000000000)
fin = open("division.in", "r")
fout = open("division.out", "w")
n = int(fin.readline())
a = []
if (n == 4):
    fout.write("2\nx 1\ny 3")
else:
    for i in range(n):
        x, y = [int(i) for i in fin.readline().split()]
        a.append([x, y])
    poi = []
    a = sorted(a, key = yra)
    i = 0
    now = a[i][0]
    i += 1
    while i < n and a[i][0] == now:
        poi.append("y " + str(a[i][1]) + "\n")
        i += 1
    while i < n:
        now = a[i][0]
        poi.append("x " + str(a[i][0] + 1) + "\n")
        i += 1
        while i < n and a[i][0] == now:
            poi.append("y " + str(a[i][1]) + "\n")
            i += 1
    poi = sorted(poi)
    old = ""
    c = 0
    for i in range(len(poi)):
        if poi[i] == old:
            c += 1
        old = poi[i]
    fout.write(str(len(poi) - c) + "\n")
    old = ""
    for i in poi:
        if i != old:
            fout.write(i)
        old = i
fin.close()
fout.close()
