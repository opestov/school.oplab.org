fin = open("bet.in", "r")
fout = open("bet.out", "w")
n = int(fin.readline())
for i in range(n):
    a, c = [int(i) for i in fin.readline().split()]
    r, g, b = [int(i) for i in fin.readline().split()]
    maxa = -10000000
    if maxa < a * ((r + 1) * (r + 1) + g * g + b * b) + c * min(r + 1, g, b):
        maxa = a * ((r + 1) * (r + 1) + g * g + b * b) + c * min(r + 1, g, b)
    if maxa < a * (r * r + (g + 1) * (g + 1) + b * b) + c * min(r, g + 1, b):
        maxa = a * (r * r + (g + 1) * (g + 1) + b * b) + c * min(r, g + 1, b)  
    if maxa < a * (r * r + g * g + (b + 1) * (b + 1)) + c * min(r, g, b + 1):
        maxa = a * (r * r + g * g + (b + 1) * (b + 1)) + c * min(r, g, b + 1)
    if maxa == a * (r * r + g * g + (b + 1) * (b + 1)) + c * min(r, g, b + 1):
        fout.write("BLUE\n")
    elif maxa == a * (r * r + (g + 1) * (g + 1) + b * b) + c * min(r, g + 1, b):
        fout.write("GREEN\n")
    else:
        fout.write("RED\n")
fin.close()
fout.close()