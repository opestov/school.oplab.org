#include <fstream>
#define MAXN 100
#define MAXM 10000

using namespace std;

ifstream in;
ofstream out;

int n, m, a[MAXM][MAXN], b[MAXN];
bool f[MAXM];

int main()
{
    in.open("disease.in");
    out.open("disease.out");
    in >> n >> m;
    for (int i = 0; i < n; ++i)
        b[i] = 2;
    int t;
    for (int i = 0; i < m; ++i)
    {
        for (int j = 0; j < n; ++j)
            in >> a[i][j];
        in >> t;
        if (t)
           f[i] = true;
        else
        {
            f[i] = false;
            for (int j = 0; j < n; ++j)
                if (a[i][j])
                   b[j] = 0;
        }
    }
    int temp, add;
    bool sq;
    for (int i = 0; i < m; ++i)
        if (f[i])
        {
           temp = 0;
           sq = false;
           for (int j = 0; j < n; ++j)
           {
               if (a[i][j])
               {
                  if (b[j] == 2)
                  {
                     temp++;
                     add = j;
                  }
                  if (!b[j])
                      sq = true;
                  }
           }
           if ((!temp) && (sq))
           {
              out << "Incorrect";
              return 0;
           }
           if (temp == 1)
              b[add] = 1;
        }
    int cp = 0, cnp = 0;
    for (int i = 0; i < n; ++i)
        if (!b[i])
           cnp++;
        else
            if (b[i] == 1)
               cp++;
    out << cnp;
    for (int i = 0; i < n; ++i)
        if (b[i] == 0)
           out << ' ' << i + 1;
    out << "\n" << cp;
    for (int i = 0; i < n; ++i)
        if (b[i] == 1)
           out << ' ' << i + 1;
    out << "\n" << n - cp - cnp;
    for (int i = 0; i < n; ++i)
        if (b[i] == 2)
           out << ' ' << i + 1;
    out << "\n";
    in.close();
    out.close();
    return 0;
}
