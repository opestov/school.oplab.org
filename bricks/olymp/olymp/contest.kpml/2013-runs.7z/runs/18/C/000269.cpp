#include <fstream>
#include <vector>
#define MAXN 9

using namespace std;

ifstream in;
ofstream out;

int n, FT[MAXN] = {1, 2, 6, 24, 120, 720, 5040, 40320, 362880};
bool f[MAXN];
vector <int> ans;

int Gen();
int print();

int main()
{
    in.open("cipher.in");
    out.open("cipher.out");
    in >> n;
    ans.push_back(1);
    out << FT[n - 1] * 2 << "\n";
    for (int i = 0; i < n; ++i)
        f[i] = true;
    f[0] = false;
    Gen();
    in.close();
    out.close();
    return 0;
}

int Gen()
{
    if (ans.size() == n)
       print();
    for (int i = 1; i <= n; ++i)
    {
        if (f[i - 1])
        {
           f[i - 1] = false;
           ans.push_back(i);
           Gen();
           ans.pop_back();
           f[i - 1] = true;
        }
    }
    return 0;
}

int print()
{
    for (int i = 0; i < ans.size(); ++i)
        out << ans[i] << ' ';
    for (int i = 0; i < ans.size(); ++i)
        out << ans[i] << ' ';
    return 0;
}
