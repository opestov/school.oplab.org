#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>
#define pb push_back
#define pob pop_back

using namespace std;
double min(double a1, double a2, double a3){
	if(a1<=a2 && a1<=a3){
		return a1;
	}
	if(a2<=a1 && a2<=a3){
		return a2;
	}
	if(a3<=a1 && a3<=a2){
		return a3;
	}
}
void max(double a1, double a2, double a3){
	if(a1>=a2 && a1>=a3){
		cout<<"RED"<<endl;
	}else
	if(a2>=a1 && a2>=a3){
		cout<<"GREEN"<<endl;
	}else
	if(a3>=a1 && a3>=a2){
		cout<<"BLUE"<<endl;
	}
}
int main(){
	double t;
	double a,c,r,g,b;
	cin>>t;
	for(double i=0;i<t;i++){
		cin>>a>>c>>r>>g>>b;
		max(a * (pow(r+1, 2) + pow(g, 2) + pow(b, 2)) + c * min(r+1, g, b), a * (pow(r, 2) + pow(g+1, 2) + pow(b, 2)) + c * min(r, g+1, b), a * (pow(r, 2) + pow(g, 2) + pow(b+1, 2)) + c * min(r, g, b+1));
	}
	return 0;
}