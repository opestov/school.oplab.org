#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>


using namespace std;

int main(){
	int n,m;
	vector<vector<int> >a;
	vector<bool>b, bt;
	vector<int>c1,c2,c3;
	cin>>n>>m;
	a.resize(m);
	b.resize(n,false);
	bt.resize(n, false);
	for(int i=0;i<m;i++){
		for(int j=0;j<n+1;j++){
			int k;
			cin>>k;
			a[i].push_back(k);
		}
	}
	for(int i=0;i<m;i++){
		if(a[i][a[i].size()-1]==0){
			for(int j=0;j<n;j++){
				if(a[i][j]==1 && b[j]==false){
					b[j]=true;
					bt[j]=true;
					c1.push_back(j);
				}
			}
		}
	}  
	bool t=false;
	int l;
	for(int i=0;i<m;i++){
		l=0;
		if(a[i][a[i].size()-1]==1){
			for(int j=0;j<a[i].size()-1;j++){
				if(a[i][j]==1 && bt[j]==false){
					l++;
				}
			}
			if(l==1){
				for(int j=0;j<a[i].size()-1;j++){
					if(a[i][j]==1 && bt[j]==false){
						bt[j]=true;
						c2.push_back(j);
					}
				}
			}
		}
	} 
	sort(c1.begin(), c1.end());
	sort(c2.begin(), c2.end());
	sort(c3.begin(), c3.end());
	for(int i=0;i<bt.size();i++){
		if(bt[i]==false){
			c3.push_back(i);
		}
	}
	cout<<c1.size()<<" ";
	for(int i=0;i<c1.size();i++){
		cout<<c1[i]+1<<" ";
	}
	cout<<endl<<c2.size()<<" ";
	for(int i=0;i<c2.size();i++){
		cout<<c2[i]+1<<" ";
	}
	cout<<endl<<c3.size()<<" ";
	for(int i=0;i<c3.size();i++){
		cout<<c3[i]+1<<" ";
	}
}