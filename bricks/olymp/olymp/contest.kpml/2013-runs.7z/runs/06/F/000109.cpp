#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>


using namespace std;

int main(){
	int n,c=0;
	cin>>n;
	double m=n;
	for(int i=0;i<=sqrt(m);i++){
		for(int j=i;j<=m;j++){
			if(i+j+i*j==n){
				if(i==j){
					c++;
				}else{
					c+=2;
				}
			}
		}
	}
	cout<<c;
	return 0;
}