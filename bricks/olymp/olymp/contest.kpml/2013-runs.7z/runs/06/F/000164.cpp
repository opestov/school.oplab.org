#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>


using namespace std;

int main(){
	int n,c=2;
	cin>>n;
	if(n==0){
		cout<<1;
		return 0;
	}
	double m=n;
	for(int i=1;i<=m;i++){
		if((n+1)%(i+1)==0){
			if(i+i+i*i==n){
				c++;
			}else if(i+i+i*i<n){
				c+=2;
			}else if(i+i+i*i>n){
				break;
			}
		}
	}
	cout<<c;
	return 0;
}