#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>


using namespace std;
struct st{
	vector<double>x,y;
};

int main(){
	int n;
	st c;
	st b;
	cin>>n;
	for(int i=0;i<n;i++){
		double k1,k2;
		cin>>k1>>k2;
		b.x.push_back(k1);
		b.y.push_back(k2);
	}
	sort(b.x.begin(), b.x.end());
	sort(b.y.begin(), b.y.end());
	double l=b.x[0];
	bool t=false;
	for(int i=1;i<n;i++){
		if(b.x[i]!=l && !t){
			t=true;
		}
		if(t){
			t=false;
			int p=(l+0.5+b.x[i]+0.5)/2;
			c.x.push_back(p);
			l=b.x[i];
		}
	}
	t=false;
	l=b.y[0];
	for(int i=1;i<n;i++){
		if(b.y[i]!=l && !t){
			t=true;
		}
		if(t){
			t=false;
			int p=(l+0.5+b.y[i]+0.5)/2;
			c.y.push_back(p);
			l=b.y[i];
		}
	}
	cout<<c.x.size()+c.y.size()<<endl;

		cout<<"x ";
		for(int i=0;i<c.x.size();i++){
			cout<<c.x[i]<<" ";
		}
	
	
		cout<<endl<<"y ";
		for(int i=0;i<c.y.size();i++){
			cout<<c.y[i]<<" ";
		}

}



