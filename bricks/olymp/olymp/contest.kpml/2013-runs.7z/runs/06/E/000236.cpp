#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>


using namespace std;
struct st{
	vector<long double>x,y;
};

int main(){
	long long n;
	st c;
	st b;
	cin>>n;
	for(long long i=0;i<n;i++){
		long double k1,k2;
		cin>>k1>>k2;
		b.x.push_back(k1);
		b.y.push_back(k2);
	}
	sort(b.x.begin(), b.x.end());
	sort(b.y.begin(), b.y.end());
	long double l=b.x[0];
	bool t=false;
	for(long long i=1;i<n;i++){
		if(b.x[i]!=l && !t){
			t=true;
		}
		if(t){
			t=false;
			long long p=(l+0.5+b.x[i]+0.5)/2;
			c.x.push_back(p);
			l=b.x[i];
		}
	}
	t=false;
	l=b.y[0];
	for(long long i=1;i<n;i++){
		if(b.y[i]!=l && !t){
			t=true;
		}
		if(t){
			t=false;
			long long p=(l+0.5+b.y[i]+0.5)/2;
			c.y.push_back(p);
			l=b.y[i];
		}
	}
	cout<<c.x.size()+c.y.size()<<endl;
	for(long long i=0;i<c.x.size();i++){
		cout<<"x "<<c.x[i]<<endl;
	}
	for(long long i=0;i<c.y.size();i++){
		cout<<"y "<<c.y[i]<<endl;
	}
}



