#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;



#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin("cipher.in");ofstream cout("cipher.out");
#endif
;

int n;
vector <int> a, ans;

void print () {
	for (int i = 0; i < a.size(); i++) {
		ans.push_back(a[i]);
	}
}

int main () {
	cin >> n;
	for (int i = 2; i <= n; i++) {
		a.push_back(i);
	}
	int fac = 1;
	for (int i = 1; i < n; i++) {
		fac *= i;
	}
	for (int i = 1; i <= fac; i++) {
		print();
		ans.push_back(1);
		print();
		next_permutation(a.begin(), a.end());
	}
	cout << ans.size() << '\n';
	for (int i = 0; i < ans.size(); i++) {
		cout << ans[i] << ' ';
	}
	return 0;
}