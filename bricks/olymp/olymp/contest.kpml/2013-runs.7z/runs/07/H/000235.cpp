#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;



#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin("pnumbers.in");ofstream cout("pnumbers.out");
#endif
;

unsigned long long t, a, b;
set <unsigned long long> se;
set <unsigned long long>::iterator it;
int main () {
	se.insert(1);
	se.insert(2);
	se.insert(3);
	se.insert(4);
	se.insert(5);
	se.insert(6);
	se.insert(7);
	se.insert(8);
	se.insert(9);
	se.insert(10);
	se.insert(21);
	se.insert(89);
	se.insert(100);
	se.insert(201);
	se.insert(221);
	se.insert(879);
	se.insert(899);
	se.insert(1000);
	se.insert(2001);
	se.insert(2221);
	se.insert(8779);
	se.insert(8999);
	se.insert(10000);
	se.insert(20001);
	se.insert(20201);
	se.insert(22221);
	se.insert(87779);
	se.insert(89799);
	se.insert(89999);
	se.insert(100000);
	se.insert(200001);
	se.insert(222221);
	se.insert(877779);
	se.insert(899999);
	se.insert(1000000);
	se.insert(2000001);
	se.insert(2002001);
	se.insert(2020201);
	se.insert(2222221);
	se.insert(8777779);
	se.insert(8979799);
	se.insert(8997999);
	se.insert(8999999);
	se.insert(10000000);
	se.insert(20000001);
	se.insert(22222221);
	se.insert(87777779);
	se.insert(89999999);
	se.insert(100000000);
	se.insert(200000001);
	se.insert(200020001);
	se.insert(202020201);
	se.insert(222222221);
	se.insert(877777779);
	se.insert(897979799);
	se.insert(899979999);
	se.insert(899999999);
	se.insert(1000000000);
	se.insert(2000000001);
	se.insert(2002002001);
	se.insert(2222222221);
	se.insert(8777777779);
	se.insert(8997997999);
	se.insert(8999999999);
	se.insert(10000000000);
	se.insert(20000000001);
	se.insert(20000200001);
	se.insert(20202020201);
	se.insert(22222222221);
	se.insert(87777777779);
	se.insert(89797979799);
	se.insert(89999799999);
	se.insert(89999999999);
	se.insert(100000000000);
	se.insert(200000000001);
	se.insert(222222222221);
	se.insert(877777777779);
	se.insert(899999999999);
	se.insert(1000000000000);
	se.insert(2000000000001);
	se.insert(2000002000001);
	se.insert(2000200020001);
	se.insert(2002002002001);
	se.insert(2020202020201);
	se.insert(2222222222221);
	se.insert(8777777777779);
	se.insert(8979797979799);
	se.insert(8997997997999);
	se.insert(8999799979999);
	se.insert(8999997999999);
	se.insert(8999999999999);
	se.insert(10000000000000);
	se.insert(20000000000001);
	se.insert(22222222222221);
	se.insert(87777777777779);
	se.insert(89999999999999);
	se.insert(100000000000000);
	se.insert(200000000000001);
	se.insert(200000020000001);
	se.insert(202020202020201);
	se.insert(222222222222221);
	se.insert(877777777777779);
	se.insert(897979797979799);
	se.insert(899999979999999);
	se.insert(899999999999999);
	se.insert(1000000000000000);
	se.insert(2000000000000001);
	se.insert(2000020000200001);
	se.insert(2002002002002001);
	se.insert(2222222222222221);
	se.insert(8777777777777779);
	se.insert(8997997997997999);
	se.insert(8999979999799999);
	se.insert(8999999999999999);
	se.insert(10000000000000000);
	se.insert(20000000000000001);
	se.insert(20000000200000001);
	se.insert(20002000200020001);
	se.insert(20202020202020201);
	se.insert(22222222222222221);
	se.insert(87777777777777779);
	se.insert(89797979797979799);
	se.insert(89997999799979999);
	se.insert(89999999799999999);
	se.insert(89999999999999999);
	se.insert(100000000000000000);
	se.insert(200000000000000001);
	se.insert(222222222222222221);
	se.insert(877777777777777779);
	se.insert(899999999999999999);
	se.insert(1000000000000000000);
	se.insert(2000000000000000001);
	se.insert(2000000002000000001);
	se.insert(2000002000002000001);
	se.insert(2002002002002002001);
	se.insert(2020202020202020201);
	se.insert(2222222222222222221);
	cin >> t;
	for (int i = 1; i <= t; i++) {
		cin >> a >> b;
		int ans = 0;
		for (it = se.begin(); it != se.end(); it++) {
			if ((*it) >= a && (*it) <= b) {
				ans++;
			}
		}
		cout << ans << "\n";
	}
	return 0;
}