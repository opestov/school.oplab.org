#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;



#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin("supreme.in");ofstream cout("supreme.out");
#endif
;

int n, m, mostPopular, cntOfMostPopular;
bool painted;
vector <vector <int> > a, backup;
map <int, int> color;
map <int, int>::iterator it;
vector <pair <char, int> > ans;

int cntOnLine (int i, int colo) {
	map <int, int> col;
	for (int j = 1; j <= m; j++) {
		col[a[i][j]]++;
	}
	return col[colo];
}

int cntOnHorizontalLine (int i, int colo) {
	map <int, int> col;
	for (int j = 1; j <= n; j++) {
		col[a[j][i]]++;
	}
	return col[colo];
}

void paintLine (int i, int colo) {
	for (int j = 1; j <= m; j++) {
		a[i][j] = colo;
	}
}

void paintHorizontalLine (int i, int colo) {
	for (int j = 1; j <= n; j++) {
		a[j][i] = colo;
	}
}

void tryToPaint (int colo) {
	for (int i = 1; i <= n; i++) {
		int counted = cntOnLine(i, colo);
		if (counted > m / 2 && counted != m) {
			painted = true;
			paintLine(i, colo);
			ans.push_back(make_pair('R', i));
		}
	}
	for (int i = 1; i <= m; i++) {
		int counted = cntOnHorizontalLine(i, colo);
		if (counted > n / 2 && counted != n) {
			painted = true;
			paintHorizontalLine(i, colo);
			ans.push_back(make_pair('C', i));
		}
	}
}

bool check (int colo) {
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			if (a[i][j] != colo) {
				return false;
			}
		}
	}
	return true;
}

void print () {
	cout << ans.size() << "\n";
	for (int i = 0; i < ans.size(); i++) {
		cout << ans[i].first << ' ' << ans[i].second << "\n";
	}
	exit(0);
}

int main () {
	cin >> n >> m;
	a.resize(n + 1, vector <int> (m + 1));
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			cin >> a[i][j];
			color[a[i][j]]++;
		}
	}
	backup = a;
	for (int i = 1; i <= 4; i++) {
		cntOfMostPopular = -1;
		for (it = color.begin(); it != color.end(); it++) {
			if (it->second > cntOfMostPopular) {
				cntOfMostPopular = it->second;
				mostPopular = it->first;
			}
		}
		color.erase(mostPopular);
		while (ans.size() <= 1000) {
			painted = false;
			tryToPaint(mostPopular);
			if (!painted) {
				break;
			}
		}
		if (check(mostPopular) && ans.size() <= 1000) {
			print();
		}
		a = backup;
		ans.clear();
	}
	cout << "Poor Kazimir";
	return 0;
}