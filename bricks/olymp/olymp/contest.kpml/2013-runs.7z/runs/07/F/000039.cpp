#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;



#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin("equation.in");ofstream cout("equation.out");
#endif
;

int n, x, y, ans;
map <int, bool > used;
int main () {
	cin >> n;
	for (int i = 0; i <= sqrt(double(n)); i++) {
		if ((n - i) % (1 + i) == 0) {
			if ((n - i) / (1 + i) > 0) { 
				if (!used[min(i, (n - 1) / (1 + i))]) {
					ans+= 2;
					used[min(i, (n - 1) / (1 + i))] = true;
					if (i == (n - 1) / (1 + i)) {
						ans--;
					}
				}
			}
		}
	}
	cout << ans;
	return 0;
}