#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <random>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;


#define FNAME "bet"

#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin(FNAME".in");ofstream cout(FNAME".out");
#endif
;

long long count(int a, int c, int r, int g, int b) {
	long long ans = a *(r * r + g * g + b * b) + c * (min(r, min(g, b)));
	return ans;
}


int main () {
	int n;
	cin >> n;
	for(int i = 0; i < n; i++) {
		int a, c;
		cin >> a >> c;
		int r, g, b;
		cin >> r >> g >> b;
		long long ans1 = count(a, c, r + 1, g, b);
		long long ans2 = count(a, c, r, g + 1, b);
		long long ans3 = count(a, c, r, g, b + 1);
		if(ans1 >= ans2 && ans1 >= ans3) {
			cout << "RED" << '\n';
			continue;
		}
		if(ans2 >= ans1 && ans2 >= ans3) {
			cout << "GREEN" << '\n';
			continue;
		}
		if(ans3 >= ans1 && ans3 >= ans2) {
			cout << "BLUE" << '\n';
			continue;
		}
	}
	
	return 0;
}