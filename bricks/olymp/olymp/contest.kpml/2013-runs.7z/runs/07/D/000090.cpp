#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;



#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin("disease.in");ofstream cout("disease.out");
#endif
;

int n, k;
vector <vector<int> > oneask;
vector <int> bac, cur, nobac, yesbac, xzbac;

int main () {
	cin >> n >> k;
	bac.resize(n,0);
	cur.resize(n);
	oneask.reserve(k);
	for(int i = 0; i < k; i++){
		for(int j = 0; j < n; j++){
			cin >> cur[j];
		}
		int t;
		cin >> t;
		if(t == 0){
			for(int j = 0; j < n; j++){
				if(cur[j] == 1)
					bac[j] = 1;
			}
		} else {
			oneask.push_back(cur);
		}
	}
	int s = oneask.size();
	for(int i = 0; i < s; i++){
		int t = 0;
		int d;
		for(int j = 0; j < n; j++){
			if((bac[j] != 1) && (oneask[i][j] == 1)){
				t++;
				d = j;
			}
		}
		if(t < 2){
			if(t == 0){
				cout << "Incorrect";
				return 0;
			} else {
				bac[d] = 2;
			}
		}
	}
	nobac.reserve(n);
	yesbac.reserve(n);
	xzbac.reserve(n);
	for(int i = 0; i < n; i++){
		if(bac[i] == 0){
			xzbac.push_back(i+1);
		} else {
			if(bac[i] == 1){
				nobac.push_back(i+1);
			} else {
				yesbac.push_back(i+1);
			}
		}
	}
	cout << nobac.size();
	for(int i = 0; i < nobac.size(); i++){
		cout << " " << nobac[i];
	}
	cout << "\n";
	cout << yesbac.size();
	for(int i = 0; i < yesbac.size(); i++){
		cout << " " << yesbac[i];
	}
	cout << "\n";
	cout << xzbac.size();
	for(int i = 0; i < xzbac.size(); i++){
		cout << " " << xzbac[i];
	}
	return 0;
}