#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;



#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin("bank.in");ofstream cout("bank.out");
#endif
;

struct gn {
	long long t, a, b, ans;
};

struct even {
	long long time, id;
	even () {}
	even (long long t, long long i) {
		time = t;
		id = i;
	}
	bool operator< (const even &ev) const {
		if (time < ev.time) {
			return true;
		}
		if (time == ev.time && id < ev.id) {
			return true;
		}
		return false;
	}
};

long long n, m, mainMen;
vector <gn> gnom;
vector <long long>  men;
vector <even> events;
int main () {
	cin >> n >> m;
	gnom.resize(n + 1);
	men.resize(m + 1);
	men[0] = 1e9 + 1;
	for (int i = 1; i <= n; i++) {
		cin >> gnom[i].t >> gnom[i].a >> gnom[i].b;
		int v = 0;
		for (int j = 1; j <= m; j++) {
			if (men[j] < men[v]) {
				v = j;
			}
		}
		men[v] =  max(gnom[i].t + gnom[i].a, men[v] + gnom[i].a);
		events.push_back(even(men[v], i));
	}
	sort(events.begin(), events.end());
	for (int i = 0; i < n; i++) {
		if (events[i].time < mainMen) {
			gnom[events[i].id].ans = mainMen + gnom[events[i].id].b;
		} else {
			gnom[events[i].id].ans = events[i].time + gnom[events[i].id].b;
		}
		mainMen = gnom[events[i].id].ans;
	}
	for (int i = 1; i <= n; i++) {
		cout << gnom[i].ans << '\n';
	}
	return 0;
}