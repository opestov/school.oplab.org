#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <map>
#include <stack>
#include <queue>
#include <deque>
#include <sstream>
#include <set>

using namespace std;



#if _DEBUG
	ifstream cin("input.txt");ofstream cout("output.txt");
#else
	ifstream cin("division.in");ofstream cout("division.out");
#endif
;

struct point {
	int x, y;
	point() {};
	point(int x, int y) : x(x), y(y) {};
};

bool m1(point a, point b) {
	if(a.x < b.x) 
		return true;
	if(a.x == b.x && a.y < b.y)
		return true;
	return false;
}

point a[100002];

set<int> x, y;
set<int>::iterator it;

int main () {
	int n;
	cin >> n;
	for(int i = 0; i < n; i++) {
		cin >> a[i].x >> a[i].y;
	}
	sort(a, a + n, m1);
	for(int i = 0; i < n - 1; i++) {
		if(a[i].x < a[i + 1].x)
			x.insert(a[i].x + 1);
		else{
			y.insert(a[i].y + 1);
		}
	}
	cout << x.size() + y.size() << '\n';
	for(it = x.begin(); it !=x.end(); it++) {
		cout << 'x' << ' ' << (*it) << '\n';
	}
	for(it = y.begin(); it != y.end(); it++) {
		cout << 'y' << ' ' << (*it) << '\n';
	}
	return 0;
}