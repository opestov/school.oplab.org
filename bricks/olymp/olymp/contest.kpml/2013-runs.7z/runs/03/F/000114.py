n = int(input())
cnt, p = 0, -1
for i in range(0, n+1):
    for j in range(0, n+1):
        if ((i + j + i * j) == n):
            if p == i and not(p == 0):
                print((cnt + 1) * 2 - 2)
                exit
            elif i == j:
                print(cnt * 2 + 1)
                exit
            p = j
            cnt += 1