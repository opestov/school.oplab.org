#include<iostream>
#include<algorithm>
#include<map>
#include<set>
#include<queue>
#include<utility>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cassert>
#include<numeric>
#include<iomanip>
using namespace std;
#define PI 3.141592654		
typedef long long ll;
inline ll ch(ll r,ll g, ll b,ll A,ll C){
	return A*(r*r+g*g+b*b) + C * min(min(r,g),b);
}
int main(){
	freopen("bet.in","r",stdin);
	freopen("bet.out","w",stdout);
	ios_base::sync_with_stdio(0);
	int q;
	cin>>q;
	while(q--){
		int r,g,b,A,C;
		cin>>A>>C>>r>>g>>b;
		ll RED = ch(r+1,g,b,A,C);
		ll BLUE = ch(r,g,b+1,A,C);
		ll GRE = ch(r,g+1,b,A,C);
		if(RED >= BLUE && RED>=GRE) cout<<"RED";
		else if(BLUE>=RED && BLUE>=GRE) cout<<"BLUE";
		else cout<<"GREEN";
		cout<<"\n";
	}
	
}