n, m = map(int, input().split())
time = []
q = [0]*m
c = []
for i in range(n):
    t, a, b = map(int, input().split())
    minq = min(q)
    k = q.index(minq)
    if minq <= t:
        q[k] = t+a
    else:
        q[k] = minq + a
    time.append([q[k], i])
    c.append(b)
time.sort()
time1 = [0]*n
last = 0
for i in time:
    time1[i[1]] = min(last+c[i[1]], i[0]+c[i[1]])
    last = time1[i[1]]
    print(last)
print(*time1)