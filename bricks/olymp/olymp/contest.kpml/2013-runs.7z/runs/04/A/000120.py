import sys
sys.stdin = open("bank.in")
sys.stdout = open("bank.out","w")
n, m = map(int, input().split())
time = []
q = [0]*m
c = []
qminindex = 0
qminmin = 0
for i in range(n):
    t, a, b = map(int, input().split())
    minq = min(q)
    k = q.index(minq)
    if minq <= t:
        q[k] = t+a
    else:
        q[k] = minq + a
    time.append([q[k], i])
    c.append(b)
time.sort()
time1 = [0]*n
last = time[0][0]
for i in time:
    time1[i[1]] = max(last+c[i[1]], i[0]+c[i[1]])
    last = time1[i[1]]
for i in time1:
    print(i)