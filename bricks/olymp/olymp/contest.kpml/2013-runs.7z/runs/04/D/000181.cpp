from math import *
n = int(input())
ans = []
used = [False]*factorial(n)
count1 = 0
ans+=list(range(1,n+1))
used[0] = True
count1 += 1
while count1!= factorial(n):
    arr = ans[len(ans)-n+1:]