#include<iostream>
#include<algorithm>
#include<map>
#include<set>
#include<queue>
#include<utility>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cassert>
#include<numeric>
#include<iomanip>
using namespace std;
#define PI 3.141592654		
typedef long long ll;
vector<int> sle[10001];
vector<int> res;
bool bad[101],unk[101],good[101];
int main(){
	freopen("disease.in","r",stdin);
	freopen("disease.out","w",stdout);
	ios_base::sync_with_stdio(0);
	int n,m;
	cin>>n>>m;
	res.assign(n,0);
	for(int i = 0;i<m;++i){
		sle[i].assign(n,0);
		for(int j = 0;j<n;++j) cin>>sle[i][j];
		cin>>res[i];
		if(res[i]==0)
			for(int j =0;j<n;++j)
				if(sle[i][j]==1)
					good[j]=true;
	}

	for(int i = 0;i<m;++i){
		
		if(res[i]==1){
			int count = 0;
			for(int j = 0;j<n;++j)
				if(!good[j]&&sle[i][j]==1) count++;
			for(int j = 0;j<n;++j){
				if(count==0 && sle[i][j]==1) {
					cout<<"Incorrect";
					return 0;
				}
				if(count == 1 && sle[i][j]==1 && !good[j]) bad[j]=1;
			}
		}
	}
	for(int i = 0;i<n;++i)
		if(good[i]&&bad[i]){
			cout<<"Incorrect";
			return 0;
		}
	vector<int> g,b,u;
	for(int i = 0;i<n;++i)
		if(good[i]) g.push_back(i+1);
		else if(bad[i]) b.push_back(i+1);
		else u.push_back(i+1);
	cout<<g.size()<<' ';
	for(int i = 0;i<g.size();++i) cout<<g[i]<<' ';
	cout<<endl;
	cout<<b.size()<<' ';
	for(int i = 0;i<b.size();++i) cout<<b[i]<<' ';
	cout<<endl;
	cout<<u.size()<<' ';
	for(int i = 0;i<u.size();++i) cout<<u[i]<<' ';
	//system("pause");
}