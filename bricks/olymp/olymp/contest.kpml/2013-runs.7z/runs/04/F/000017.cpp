#include<iostream>
#include<algorithm>
#include<map>
#include<set>
#include<queue>
#include<utility>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cassert>
#include<numeric>
#include<iomanip>
using namespace std;
#define PI 3.141592654		
typedef long long ll;
inline ll ch(ll r,ll g, ll b,ll A,ll C){
	return A*(r*r+g*g+b*b) + C * min(min(r,g),b);
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	ios_base::sync_with_stdio(0);
	int n;
	int ans = 0;
	cin>>n;
	for(int j = 1;j<=sqrt(n+1.0);++j){
		if((n+1)%j == 0) ans+=2;
		if(j*j==n+1) ans--;
	}
	cout<<ans;
}