#include<iostream>
#include<algorithm>
#include<map>
#include<set>
#include<queue>
#include<utility>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cassert>
#include<numeric>
#include<iomanip>
using namespace std;
#define PI 3.141592654		
typedef long long ll;
int x[100001],y[100001];
struct point{
	int x,y;
};
bool operator<(point a,point b){
	return a.y<b.y||(a.y==b.y&&a.x<b.x);
}
int main(){
	freopen("division.in","r",stdin);
	freopen("division.out","w",stdout);
	ios_base::sync_with_stdio(0);
	int n;
	cin>>n;
	vector<point> pp(n); 
	set<int> x1,y1;
	for(int i = 0;i<n;++i)
	{
		cin>>pp[i].x>>pp[i].y;
	}
	sort(pp.begin(),pp.end());
	for(int i = 0;i<n-1;++i){
		if(pp[i].y==pp[i+1].y){
			if(pp[i].x>pp[i+1].x)
				x1.insert(pp[i].x);
			else 
				x1.insert(pp[i].x+1);
		}
		else{
			if(pp[i].y>pp[i+1].y)
				y1.insert(pp[i].y);
			else y1.insert(pp[i].y+1);
		}
	}
	cout<<x1.size()+y1.size()<<endl;
	for(set<int>::iterator it = x1.begin();it!=x1.end();it++)
		cout<<"x "<<*it<<'\n';
	for(set<int>::iterator it = y1.begin();it!=y1.end();it++) 
		cout<<"y "<<*it<<'\n';
}