#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main(){
    freopen("equation.in", "r", stdin);
    freopen("equation.out", "w", stdout);

    int n, k = 0;

    scanf("%ld", &n);

    if(n < 459000000){
        for(int y = 0; y <= n; y++)
            if((n - y) % (1 + y) == 0)
                k++;
    }
    else{
        int a = (n / 5) * 2;

        for(int y = 0; y <= a; y++)
            if((n - y) % (1 + y) == 0)
                k++;
        k++;
    }

    cout << k;

    return 0;
}
