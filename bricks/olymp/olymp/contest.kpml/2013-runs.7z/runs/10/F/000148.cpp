#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main(){
    freopen("equation.in", "r", stdin);
    freopen("equation.out", "w", stdout);

    int n, k = 0;

    scanf("%ld", &n);

    if(n == 0){
        cout << 1;
        return 0;
    }
    else if (n == 1)
    {
        cout << 2;
        return 0;
    }

    for(int y = 0; y <= n / 3 + 1; y++)
        if((n - y) % (1 + y) == 0)
            k++;

    cout << k + 1;

    return 0;
}
