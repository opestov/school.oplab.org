def readdata():
    global N, a
    fread = open('division.in', 'r')
    N = int(fread.readline())
    a = [[int(x) for x in fread.readline().split()] for i in range(N)]
    
    
def solve():
    global x, s
    a.sort()
    group = []
    group.append([a[0]])
    for i in range(1, N):
        if a[i][0] == group[len(group) - 1][0][0]:
            group[len(group) - 1].append(a[i])
        else:
            group.append([a[i]])
    x = []
    for i in range(len(group) - 1):
        x.append(group[i][0][0] + 1)
    for i in range(len(group)):
        group[i].sort(key = lambda x:x[1])
    s = set()
    for i in range(len(group)):
        for j in range(len(group[i]) - 1):
            s.add(group[i][j][1] + 1)
            
            
def write_answer():
    global x
    fwrite = open('division.out', 'w')
    print(len(x) + len(s), file = fwrite)
    for i in range(len(x)):
        print('x', x[i], file = fwrite)
    for x in s:
        print('y', x, file = fwrite)
    fwrite.close()


readdata()
solve()
write_answer()