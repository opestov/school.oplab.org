def readdata():
    global a, res, N, M
    fread = open('disease.in', 'r')
    N, M = [int(x) for x in fread.readline().split()]
    a = [[] for i in range(M)]
    res = [0] * M
    for i in range(M):
        a[i] = [int(x) for x in fread.readline().split()]
        res[i] = a[i].pop()
        
        
def solve():
    global nott, yess, vozm
    nott = [0] * N
    yess = [0] * N
    vozm = [[False for i in range(N)] for j in range(M)]
    for i in range(M):
        if res[i] == 0:
            for j in range(N):
                if a[i][j] == 1:
                    nott[j] = 1
    for i in range(M):
        if res[i] == 1:
            for j in range(N):
                if a[i][j] == 1:
                    if not nott[j]:
                        vozm[i][j] = True
    for i in range(M):
        if res[i] == 1:
            if sum(vozm[i]) == 1:
                yess[vozm[i].index(1)] = 1
                
                
def write_answer():
    fwrite = open('disease.out', 'w')
    for i in range(M):
        if res[i] == 1 and sum(vozm[i]) == 0:
            print('Incorrect', file = fwrite)
            return
    for i in range(N):
        if nott[i] == 1 and yess[i] == 1:
            print('Incorrect', file = fwrite)
            return
    print(sum(nott), end = ' ', file = fwrite)
    for i in range(N):
        if nott[i] == 1:
            print(i + 1, end = ' ', file = fwrite)
    print('', file = fwrite)
    print(sum(yess), end = ' ', file = fwrite)
    for i in range(N):
        if yess[i] == 1:
            print(i + 1, end = ' ', file = fwrite)
    print('', file = fwrite)
    print(N - sum(nott) - sum(yess), end = ' ', file = fwrite)
    for i in range(N):
        if nott[i] == 0 and yess[i] == 0:
            print(i + 1, end = ' ', file = fwrite)
    fwrite.close()


readdata()
solve()
write_answer()