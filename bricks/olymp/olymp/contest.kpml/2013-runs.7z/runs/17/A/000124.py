from collections import deque

def readdata():
    global tin, a, b, N, M
    fread = open('bank.in', 'r')
    N, M = [int(x) for x in fread.readline().split()]
    tin = [0] * N
    a = [0] * N
    b = [0] * N
    for i in range(N):
        tin[i], a[i], b[i] = [int(x) for x in fread.readline().split()]
        
        
def solve():
    global toutb
    q = deque()
    osvob = [0] * M
    touta = [0] * N
    for i in range(N):
        q.append(tin[i])
    for i in range(N):
        cur = q.popleft()
        touta[i] = max(min(osvob), cur) + a[i]
        osvob[osvob.index(min(osvob))] = touta[i]
    for i in range(N):
        touta[i] = [touta[i], i]
    touta.sort()
    q = deque()
    for i in range(N):
        q.append(touta[i])
    osv_main = 0
    toutb = [0] * N
    for i in range(N):
        cur = q.popleft()
        toutb[i] = [cur[1], max(osv_main, cur[0]) + b[cur[1]]]
        osv_main = toutb[i][1]
    toutb.sort()  
    
    
def write_answer():
    fwrite = open('bank.out', 'w')
    for i in range(N):
        print(toutb[i][1], file = fwrite)
    fwrite.close()


readdata()
solve()
write_answer()