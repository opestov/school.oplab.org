var
n,x,s:integer;
begin
read(n);
s:=1;

for x:=1 to n do
if ((n-x) mod (x+1) = 0) then
s:=s+1;
writeln(s);
end.