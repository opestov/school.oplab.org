#include <iostream>
#include <math.h>
#include <stdio.h>
using namespace std;

int n, m, a[100001][101], r[101], mx, c2, c1, c_1, count, count2;

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n >> m;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n+1; j++) {
			cin >> a[i][j];
		}
		if (a[i][n] == 0) {
			for (int k = 0; k < n; k++) {
				if (a[i][k] == 1) {
					r[k] = -1;
					c_1++;
				}
			}
		}
	}
	for (int i = 0; i < n; i++) {
		if (a[i][n] == 1) {
			for (int j = 0; j < n; j++) {
				if (a[i][j] == 1) {
					count++;
					if (r[j] == -1) {
						count2++;
					}
				}
			}
			for (int j = 0; j < n; j++) {
				if (count == count2) {
					cout << "Incorrect";
					return 0;
				} else if (count-count2 == 1) {
					if (a[i][j] == 1) {
						if (r[j] == 2) {
							c2--;
						}
						if (r[j] != -1) {
							r[j] = 1;
							c1++;
						}
					}
				} else if (count-count2 > 1) {
					if ((a[i][j] == 1) && (r[j] != -1)) {
						r[j] = 2;
						c2++;
					}
				}
			}
		}
		count = 0;
	}
	
	cout << c_1 << " ";
	for (int i = 0; i < n; i++) {
		if (r[i] == -1) cout << i+1 << " ";
	}
	cout << endl << c1 << " ";
	for (int i = 0; i < n; i++) {
		if (r[i] == 1) cout << i+1 << " ";
	}
	cout << endl << c2 << " ";
	for (int i = 0; i < n; i++) {
		if (r[i] == 2) cout << i+1 << " ";
	}
}