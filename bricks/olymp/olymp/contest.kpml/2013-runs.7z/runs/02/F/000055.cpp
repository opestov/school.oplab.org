#include <iostream>
#include <math.h>
#include <stdio.h>
using namespace std;

long n, x, y, count;

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	long i = 0;
	cin >> n;
	while (i < sqrt(double(n-1))) {
		x = i;
		y = (n-x)/(x+1);
		if (x+y+x*y == n) {
			count += 2;
			if (x == y) {
				count--;
				break;
			}
		}
		i++;
	}
	cout << count;

}