n = input()

# FRST GAMER
k = []
s = []
def mx(a,c,r,g,b):
    return (a*(r**2+g**2+b**2)+c*min(r,g,b))
for i in range(n):
    k = raw_input().split()
    s = raw_input().split()
    k[0] = int(k[0])
    k[1] = int(k[1])
    s[0] = int(s[0])
    s[1] = int(s[1])
    s[2] = int(s[2])
    if ((mx(k[0],k[1],s[0]+1,s[1],s[2])) >= (mx(k[0],k[1],s[0],s[1]+1,s[2])))
    and ((mx(k[0],k[1],s[0]+1,s[1],s[2])) >= (mx(k[0],k[1],s[0],s[1],s[2]+1))):
        print 'RED'
    elif ((mx(k[0],k[1],s[0],s[1]+1,s[2])) >= (mx(k[0],k[1],s[0]+1,s[1],s[2])))
    and ((mx(k[0],k[1],s[0],s[1]+1,s[2])) >= (mx(k[0],k[1],s[0],s[1],s[2]+1))):
        print 'GREEN'
    elif ((mx(k[0],k[1],s[0],s[1],s[2]+1)) >= (mx(k[0],k[1],s[0],s[1]+1,s[2])))
    and ((mx(k[0],k[1],s[0],s[1],s[2]+1)) >= (mx(k[0],k[1],s[0]+1,s[1],s[2]))):
        print 'BLUE'
