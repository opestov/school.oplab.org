#include <iostream>
#include <math.h>
#include <stdio.h>
using namespace std;

int n, m, a[101], r[101], mx, c0, c1, c2, count;

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n >> m;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n+1; j++) {
			cin >> a[j];
			if ((a[j] == 1) && (j != n)) {
				count++;
			}
		}
		if (a[n] == 0) {
			for (int j = 0; j < n; j++) {
				if (a[j] == 1) {
					if (r[j] == 2) {
						cout << "Incorrect";
						return 0;
					} else {
						if (r[j] == 2) {
							c2--;
						}
						r[j] = 1;
						c0++;
					}
				}
			}
		}
		if (a[n] == 1) {
			if (count == 1) {
				for (int j = 0; j < n; j++) {
					if (r[j] == 1) {
						cout << "Incorrect";
						return 0;
					} else {
						if (r[j] == 3) {
							c2--;
						}
						r[j] = 2;
						c1++;
					}
				}
			} else {
				for (int j = 0; j < n; j++) {
					if (r[j] == 0) {
						r[j] = 3;
						c2++;
					}
				}
			}
		}
		count = 0;
		for (int j = 0; j < n; j++) {
			cout << r[j] << " ";
		}
		cout << endl;
	}
	cout << c0 << " ";
	for (int i = 0; i < n; i++) {
		if (r[i] == 1) cout << i+1 << " ";
	}
	cout << endl << c1 << " ";
	for (int i = 0; i < n; i++) {
		if (r[i] == 2) cout << i+1 << " ";
	}
	cout << endl << c2 << " ";
	for (int i = 0; i < n; i++) {
		if (r[i] == 3) cout << i+1 << " ";
	}
}