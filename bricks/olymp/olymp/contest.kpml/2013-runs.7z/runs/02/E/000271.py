# ION Company
# CYBER COMAND [ZAGRUS.RU]
n = int(input())
x = []
y = []
a = ''
if n == 1:
    print 0
else:    
    for i in range(n):
        a = raw_input().split()
        x+=[int(a[0])]
        y+=[int(a[1])]
    x = list(set(x))
    y = list(set(y))
    sun = len(x) +len(y)-2
    sorted(x)
    sorted(y)
    print sun
    for i in range(len(x)-1):
        print 'x',x[i+1]
    for i in range(len(y)-1):
        print 'y',y[i+1]
