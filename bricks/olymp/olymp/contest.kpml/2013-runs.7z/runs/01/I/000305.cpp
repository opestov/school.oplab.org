#include<iostream>
#include<cstdio>
using namespace std;
int a[100000];
int main()
{
	freopen("scanner.in","r",stdin);
	freopen("scanner.out","w",stdout);
	int n, k, b=0, h,ci=0;
	cin>>n>>k;
	for(int i=0; i<n; i++)
		a[i]=i+1;
	int g=n-1;
	for(int i=0; i<=n-k; i++)
	{
		cin>>h; 
			for(int i=0; ci<h; i++)
		{
			swap(a[g-h-i],a[g-i]);
			ci+=g-h;
			}}
	for(int i=0; i<n; i++)
		cout<<a[i]<<" ";
}