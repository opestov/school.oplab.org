#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("bet.in","r",stdin);
	freopen("bet.out","w",stdout);
	int t;
	cin>>t;
	for(int i=0; i<t; i++)
	{
		int a,c;
		cin>>a>>c;
		int r,g,b;
		cin>>r>>g>>b;
		int cr,cg,cb;
		r++;
		cr=a*(r*r+g*g+b*b)+c*min(r,min(g,b));
		r--;
		g++;
		cg=a*(r*r+g*g+b*b)+c*min(r,min(g,b));
		g--;
		b++;
		cb=a*(r*r+g*g+b*b)+c*min(r,min(g,b));
		b--;
		if(cr>cb && cr>cg)
			cout<<"RED"<<endl;
		else if(cb>cg)
			cout<<"BLUE"<<endl;
		else cout<<"GREEN"<<endl;
	}
}