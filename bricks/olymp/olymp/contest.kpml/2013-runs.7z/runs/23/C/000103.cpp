#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
using namespace std;
int use [10]={0};
int glub;
int mass[10];
void fun (int i, int n)
{
	use[i]=1;
	if(glub==n)
	{
		for(i=1; i<=n; i++)
			printf("%d ", mass[i]);
		for(i=1; i<n; i++)
			printf("%d ", mass[i]);
	}
	for(int j=2; j<=n; j++)
	{
		if(!use[j])
		{
			glub++;
			mass[glub]=j;
			fun(j, n);
			glub--;
			use[j]=0;
		}
	}
}
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	freopen("cipher.in", "r", stdin);
	freopen("cipher.out", "w", stdout);
	int i, j, k, l, m, n;
	mass[1]=1;
	glub=1;
	scanf("%d", &n);
	m=1;
	for(i=1; i<n; i++)
		m*=i;
	m*=(2*n-1);
	printf("%d\n", m);
	fun(1, n);
	return 0;
}