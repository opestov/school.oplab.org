#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <algorithm>
using namespace std;

long long n, m, i, j, a[100010], t[100010], b[100010], mas[12],  minn, jj, tt;
struct ol
{
	long long n; 
	long long i;
} ans[100010];
int max(long long a, long long b) {
	return (a > b) ? a : b;
}
bool cmp (ol a, ol b)
{
	if(a.n<b.n)
		return 1;
	return 0;
}
bool cmp2 (ol a, ol b)
{
	if(a.i<b.i)
		return 1;
	return 0;
}
int main() {
	freopen("bank.in", "r", stdin);
	freopen("bank.out", "w", stdout);

	scanf("%lld %lld", &n, &m);
	for (i = 0; i < n; i++) {
		scanf("%lld %lld %lld", &t[i], &a[i], &b[i]);
	}

	for (i = 0; i < n; i++) {
		minn = 1000000010;
		for (j = 0; j < m; j++) {
			if (minn > mas[j]) {
				minn = mas[j];
				jj = j;
			}
		}
		mas[jj] = max(t[i], mas[jj]) + a[i];
		ans[i].n = mas[jj];
		ans[i].i=i;
	}
	sort(&ans[0], &ans[n], cmp);
	for (i = 0; i < n; i++) {
		ans[i].n = max(tt, ans[i].n) + b[ans[i].i];
		tt = ans[i].n;
		//printf("%d\n", tt);
	}
	sort(&ans[0], &ans[n], cmp2);
	for(i=0; i<n; i++)
		printf("%lld\n", ans[i].n);
}