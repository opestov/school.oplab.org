#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
using namespace std;
int fun (int r, int g, int b, int a, int c)
{
	int m=min(min(r, g), b)*c;
	return a*(r*r+g*g+b*b)+m;
}
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	int i, j, k, n;
	scanf("%d", &n);
	n++;
	k=1;
	int kor=pow(n, 0.5);
	for(i=2; i<=kor; i++)
	{
		if(n%i==0)
			k++;
	}
	k*=2;
	if(n%kor==0&&n/kor==kor)
		k--;
	printf("%d", k);
	return 0;
}