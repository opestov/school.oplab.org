#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
using namespace std;
set <int> y;
set <int> x;
struct atata 
{
	int x;
	int y;
} mass[100001];
bool cmp (atata& a, atata &b)
{
	if(a.x<b.x)
		return 1;
	else if(a.x==b.x&&a.y<b.y)
		return 1;
	return 0;
}
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	freopen("division.in", "r", stdin);
	freopen("division.out", "w", stdout);
	int i, j, k, l, m, n;
	scanf("%d", &n);
	for(i=1; i<=n; i++)
	{
		scanf("%d%d", &mass[i].x, &mass[i].y);
	}
	sort(&mass[1], &mass[n+1], cmp);
	for(i=1; i<n; i++)
	{
		if(mass[i].x==mass[i+1].x)
		{
			y.insert(mass[i+1].y);
		}
		else x.insert(mass[i+1].x);
	}
	printf("%d\n", x.size()+y.size());
	set <int>::iterator it;
	for(it=x.begin(); it!=x.end(); ++it)
	{
		printf("x %d\n", *it);
	}
	for(it=y.begin(); it!=y.end(); ++it)
	{
		printf("y %d\n", *it);
	}
	return 0;
}