#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
using namespace std;
int matr [301][301], matr2[301][301];
int mx[300], my[301];
typedef pair <int, int> Pair;
map <int, int> mass;
int color [600]={0};

struct ololo 
{
	int i;
	char r;
};
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	freopen("supreme.in", "r", stdin);
	freopen("supreme.out", "w", stdout);
	int i, j, k, l, m, n;
	scanf("%d%d", &n, &m);
	for(i=1; i<=n; i++)
		for(j=1; j<=m; j++)
		{
			scanf("%d",& matr[i][j]);
			if(mass.find(matr[i][j])==mass.end())
			{
				mass.insert(Pair(matr[i][j], 1));
			}
			else ++mass[matr[i][j]]; 
		}
		map <int, int> ::iterator it;
		for(it=mass.begin(); it!=mass.end(); ++it)
		{
			if((*it).second/(double)(n*m)>=0.01)
			{
				color[++color[0]]=(*it).first;
			}
		}
	for(i=1; i<=color[0]; i++)
	{
		ololo ans[1001];
		int use1[301], use2[301];
		for(j=1; j<=n; j++)
			for(k=1; k<=m; k++)
				matr2[j][k]=matr[j][k];
		int c=0;
		while (1)
		{
			bool f=0;
			for(j=1; j<=n; j++)
			{
				int ch=0;
				if(use1[j]==1)
					continue;
				for(k=1; k<=m; k++)
				{
					if(matr2[j][k]==color[i])
						ch++;
				}
				if(ch*2>m)
				{
					use1[j]=1;
					f=1;
					for(k=1; k<=m; k++)
						matr2[j][k]=color[i];
					ans[++c].i=j;
					ans[c].r='R';
				}
			}
			for(j=1; j<=m; j++)
			{
				int ch=0;
				if(use2[j]==1)
					continue;
				for(k=1; k<=n; k++)
				{
					if(matr2[k][j]==color[i])
						ch++;
				}
				if(ch*2>m)
				{
					use2[j]=1;
					f=1;
					for(k=1; k<=n; k++)
						matr2[k][j]=color[i];
					ans[++c].i=j;
					ans[c].r='C';
				}
			}
			if(f==0)
				break;
			
		}
		int flag=0;
			for(j=1; j<=n; j++)
				if(use1[j]==0)
					flag=1;
		
			for(j=1; j<=m; j++)
				if(use2[j]==0)
					flag=1;
			if(!flag)
			{
				printf("%d\n", c);
				for(i=1; i<=c; i++)
					printf("%c %d\n", ans[i].r, ans[i].i);
				return 0;
			}
	}
	printf("Poor Kazimir");
	return 0;
}