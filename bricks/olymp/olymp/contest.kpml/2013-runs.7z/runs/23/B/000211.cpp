#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
using namespace std;
set <int> y;
set <int> x;
struct atata 
{
	int x;
	int y;
} mass[100001];
bool cmp (atata a, atata b)
{
	if(a.x<b.x)
		return 1;
	else if(a.x==b.x&&a.y<b.y)
		return 1;
	return 0;
}
bool fun (char * str1)
{
		char str2[100];
		int m=0;
		int l=strlen(str1);
		int ch=0;
		int f=0;
		while(str1[m]!=NULL)
		{
			if(str1[l-1-m]=='0'&&!f)
				ch++;
			else 
			{
				f=1;
				str2[m]=str1[l-1-m-ch];
				m++;
			}
		}
		str1[l-ch]=NULL;
		str2[m]=0;
		if(strcmp(str1, str2)==0)
		{
			return 1;
		}
		return 0;
}
int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	//freopen("division.in", "r", stdin);
	//freopen("division.out", "w", stdout);
	int i, j, k, l, m, n;
	
	/*for(i=1; i<=1000000000; i++)
	{
		k=i;
		l=0;
		k++;
		char str1[100], str2[100];
		while(k!=0)
		{
			if(k%10==0&&l==0)
			{
				k/=10;
				continue;
			}
			str1[l]='0'+k%10;
			l++;
			k/=10;
		}
		str1[l]=NULL;
		m=0;
		while(str1[m]!=NULL)
		{
			str2[m]=str1[l-1-m];
			m++;
		}
		str2[l]=0;
		if(strcmp(str1, str2)==0)
		{
			char str3[100], str4[100];
			l=0;
			k=i-1;
			while(k!=0)
			{
				if(k%10==0&&l==0)
				{
					k/=10;
					continue;
				}
				str3[l]='0'+k%10;
				l++;
				k/=10;
			}
			str3[l]=NULL;
			m=0;
			while(str3[m]!=NULL)
			{
				str4[m]=str3[l-1-m];
				m++;
			}
			str4[l]=0;
			if(strcmp(str3, str4)==0)
				printf("%d\n", i);
		}
	}*/
/*	char str[20];
	long long k1=0, k2;
	k=0;
	k1=2;
	for(i=1; i<=18; i++)
	{
		k1=2;
		k1*=pow(10.0, i);
		k1+=1;
		k=pow(2.0, i-1);
		for(j=0; j<k; j++)
		{
			long long ll=0;
			int h=j;
			k1=2;
			k1*=pow(10.0, i);
			k1+=1;
			while(h!=0)
			{
				ll*=10;
				ll+=2*(h%2);
				h/=2;
			}
			ll*=10;
			k1+=ll;
			k1-=1;
			long long g=k1, gg;
			k2=0;
			while(g!=0)
			{
				if(g%10==0)
					g=g/10;
				else break;
			}
			gg=g;
			while(g!=0)
			{
				k2*=10;
				k2+=g%10;
				g/=10;
			}
			if(gg==k2)
			{
				k2=0;
				k1+=2;
				g=k1;
				while(g!=0)
				{
					if(g%10==0)
						g=g/10;
					else break;
				}
				gg=g;
				while(g!=0)
				{
					k2*=10;
					k2+=g%10;
					g/=10;
				}
				if(k2==gg)
					printf("%lld\n", k1-1);
			}
		}
	}*/
	return 0;
}