#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
using namespace std;
int fun (int r, int g, int b, int a, int c)
{
	int m=min(min(r, g), b)*c;
	return a*(r*r+g*g+b*b)+m;
}
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	freopen("bet.in", "r", stdin);
	freopen("bet.out", "w", stdout);
	int i, j, k, l, m, n, a, c, r, g, b;
	scanf("%d", &l);
	for(i=1; i<=l; i++)
	{
		scanf("%d%d", &a, &c);
		scanf("%d%d%d", &r, &g, &b);
		k=fun(r+1, g, b, a, c);
		m=	fun(r, g+1, b, a, c);
		n=	fun(r,g, b+1, a, c);
		if(k<m)
		{
			if(m>n)
				printf("GREEN\n");
			else printf("BLUE\n");

		}
		else 
		{
			if(k>n)
				printf("RED\n");
			else printf("BLUE\n");
		}
	}
	return 0;
}