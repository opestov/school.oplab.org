#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
using namespace std;

int a[10010][110], i, j, n, m, ans1[110], ans2[110], ans3[110], n1,n2,n3, tt, ttt;

int main()
{
	freopen("disease.in", "r", stdin);
	freopen("disease.out", "w", stdout);
	//freopen("equation.in", "r", stdin);
	//freopen("equation.out", "w", stdout);

	scanf("%d %d", &n, &m);
	for (i = 0; i < m; i++) {
		for (j = 0; j <= n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		if (a[i][n] == 0) {
			for (j = 0; j < n; j++) {
				if (a[i][j] == 1)
					ans1[j] = 1;
			}
		}
	}

	for (i = 0; i < m; i++) {
		tt = 0;
		if (a[i][n] == 1) {
			for (j = 0; j < n; j++) {
				if ((a[i][j] == 1) && (ans1[j] == 0)) {
					tt++;
					ttt = j;
				}
			}
			if (tt == 1)
				ans2[ttt] = 1;
			if (tt == 0) {
				printf("Incorrect");
				return 0;
			}
		}
	}

	for (i = 0; i < n; i++)
		if (ans1[i] == 1)
			n1++;
	printf("%d ", n1);
	for (i = 0; i < n; i++)
		if (ans1[i] == 1)
			printf("%d ", i + 1);

	printf("\n");

	for (i = 0; i < n; i++)
		if (ans2[i] == 1)
			n2++;
	printf("%d ", n2);
	for (i = 0; i < n; i++)
		if (ans2[i] == 1)
			printf("%d ", i + 1);
	
	printf("\n");

	for (i = 0; i < n; i++)
		if ((ans1[i] == 0) && (ans2[i] == 0))
			n3++;
	printf("%d ", n3);
	for (i = 0; i < n; i++)
		if ((ans1[i] == 0) && (ans2[i] == 0))
			printf("%d ", i + 1);


	return 0;
}