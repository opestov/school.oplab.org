#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxN = 302;

struct point{
	char t;
	int x;
};

int a[maxN][maxN], c[maxN][maxN];
point an[200000];
int b[1000002];
int n, m;

bool make(int color) {
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			c[i][j] = a[i][j];

	int ans = 0;
	for (int t = 1; t <= n + m; t++) {
	    bool bl = true;

		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= m; j++)
				if (c[i][j] != color) {
					bl = false;
					break;
				}
		if (bl)
			break;

		for (int i = 1; i <= n; i++) {
			int k = 0;
			for (int j = 1; j <= m; j++)
				k += (c[i][j] == color);
			if (k > m / 2 && k < m) {
				for (int j = 1; j <= m; j++)
					c[i][j] = color;
				ans++;
				an[ans].t = 'R';
				an[ans].x = i;
				bl = true;
				break;
			}
		}
		if (bl)
			continue;
		for (int j = 1; j <= m; j++) {
			int k = 0;
			for (int i = 1; i <= n; i++)
				k += (c[i][j] == color);
			if (k > n / 2 && k < n) {
				for (int i = 1; i <= n; i++)
					c[i][j] = color;
				ans++;
				an[ans].t = 'C';
				an[ans].x = j;
				bl = true;
				break;
			}
		} 
		if (!bl)
			return false;
				
	}
	
	

//	cout << color << endl;
	cout << ans << endl;
	for (int i = 1; i <= ans; i++)
		printf("%c %d\n", an[i].t, an[i].x);
	return true;

}

int main() {

	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) {
			cin >> a[i][j];
			b[a[i][j]]++;
		}

	for (int i = 1; i <= 1e6; i++)
		if (b[i] > (n * m) / 4) {
			if (make(i))
				exit(0);

		}

	cout << "Poor Kazimir";
	
	
	return 0;
}