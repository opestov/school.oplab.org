#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxN = 100010;

struct point{
	int x, y;
};
struct pp{
	int z;
	char t;
};

point p[maxN];
pp an[maxN * 2];
int us[maxN * 2];
int n, ans, ans2;

bool cmp1(point p1, point p2) {
	return (p1.x < p2.x || (p1.x == p2.x && p1.y < p2.y));
}

bool cmp2(pp a1, pp a2) {
	return (a1.t < a2.t || (a1.t == a2.t && a1.z < a2.z));
}

int main() {
	
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> p[i].x >> p[i].y;
	
	sort(p + 1, p + n + 1, &cmp1);

	for (int i = 2; i <= n; i++)
		if (p[i].x != p[i - 1].x) {
			ans++;
			an[ans].z = p[i - 1].x + 1;
			an[ans].t = 'x';
		}
		else 
			if (p[i].y != p[i - 1].y) {
				ans++;
				an[ans].z = p[i - 1].y + 1;
				an[ans].t = 'y';
			}
	/*
	sort(p + 1, p + n + 1, &cmp2);

	for (int i = 2; i <= n; i++)
		if (p[i].y != p[i - 1].y) {
			ans++;
			an[ans].z = p[i - 1].y + 1;
			an[ans].t = 'y';
		}
	 
	*/

	sort(an + 1, an + ans + 1, &cmp2);

	int ans2 = 1;
	us[1] = 1;
	for (int i = 2; i <= ans; i++)
		if (an[i].t != an[i - 1].t || an[i].z != an[i - 1].z) {
			ans2++;
			us[ans2] = i;
		}

	cout << ans2 << endl;
	for (int i = 1; i <= ans2; i++)
		printf("%c %d\n", an[us[i]].t, an[us[i]].z);
	
	return 0;
}