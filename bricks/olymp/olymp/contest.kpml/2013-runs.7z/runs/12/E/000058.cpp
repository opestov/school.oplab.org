#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxN = 100010;

struct point{
	int x, y;
};
struct pp{
	int z;
	char t;
};

point p[maxN];
pp an[maxN * 2];
int n, ans;

bool cmp1(point p1, point p2) {
	return (p1.x < p2.x);
}

bool cmp2(point p1, point p2) {
	return (p1.y < p2.y);
}

int main() {
	
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> p[i].x >> p[i].y;
	
	sort(p + 1, p + n + 1, &cmp1);

	for (int i = 2; i <= n; i++)
		if (p[i].x != p[i - 1].x) {
			ans++;
			an[ans].z = p[i - 1].x + 1;
			an[ans].t = 'x';
		}
	
	sort(p + 1, p + n + 1, &cmp2);

	for (int i = 2; i <= n; i++)
		if (p[i].y != p[i - 1].y) {
			ans++;
			an[ans].z = p[i - 1].y + 1;
			an[ans].t = 'y';
		}
	 

	cout << ans << endl;
	for (int i = 1; i <= ans; i++)
		printf("%c %d\n", an[i].t, an[i].z);
	
	return 0;
}