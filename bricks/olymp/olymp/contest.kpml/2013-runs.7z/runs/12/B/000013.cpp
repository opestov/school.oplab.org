#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

int main() {

	int t;
	cin >> t;
	for (int i = 1; i <= t; i++) {
		int a, c, r, g, b;
		cin >> a >> c >> r >> g >> b;
		r++;
		int t1 = a * (r * r + g * g + b * b) + c * min(min(r, g), b);
		r--;
		g++;
		int t2 = a * (r * r + g * g + b * b) + c * min(min(r, g), b);
		g--;
		b++;
		int t3 = a * (r * r + g * g + b * b) + c * min(min(r, g), b);
		
		if (t1 >= t2 && t1 >= t3) 
			cout << "RED\n";
		else
			if (t2 >= t1 && t2 >= t3)
				cout << "GREEN\n";
			else
				cout << "BLUE\n";
	}
	
	return 0;
}