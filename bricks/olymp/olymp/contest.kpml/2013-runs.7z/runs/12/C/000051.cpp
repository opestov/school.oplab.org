#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxN = 9;

int a[11], us[11];
int an[2000001], kol;
int n;

void rec(int x) {
	if (x >= n) {
		for (int i = 1; i < n; i++)
			an[i + kol] = a[i];
		an[n + kol] = n;
		kol += n;
		for (int i = 1; i < n; i++)
			an[i + kol] = a[i];
		kol += n - 1;
		return;
	}

	for (int i = 1; i < n; i++)
		if (us[i] == 0) {
			a[x] = i;
			us[i] = 1;
			rec(x + 1);
			us[i] = 0;
		}
}

int main() {

	kol = 0;
	cin >> n;
	rec(1);

	cout << kol << endl;
	for (int i = 1; i <= kol; i++)
		cout << an[i] << ' ';

	
	return 0;
}