#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxN = 100;

int a[11000][200];
int ans[200];
int n, m;

void no() {
	cout << "Incorrect";
	exit(0);
}

int main() {

	cin >> n >> m;
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n + 1; j++)
			cin >> a[i][j];
		if (a[i][n + 1] == 0)
			for (int j = 1; j <= n; j++)
				if (a[i][j] == 1)
					ans[j] = 1;

	}	

	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= n; j++)
			if (a[i][j] == 1 && ans[j] == 1)
				a[i][j] = 0;

	for (int i = 1; i <= m; i++) {
		int s = 0;
		for (int j = 1; j <= n; j++) 
			s += a[i][j];
		if (s == 0 && a[i][n + 1] == 1)
			no();
		if (s == 1 && a[i][n + 1] == 1)
			for (int j = 1; j <= n; j++)
				if (a[i][j] == 1)
					ans[j] = 2;
	}

	int k = 0;
	for (int i = 1; i <= n; i++)
		if (ans[i] == 1)
			k++;
	cout << k << ' ';
	for (int i = 1; i <= n; i++)
		if (ans[i] == 1)
			cout << i << ' ';
	cout << endl;

	k = 0;
	for (int i = 1; i <= n; i++)
		if (ans[i] == 2)
			k++;
	cout << k << ' ';
	for (int i = 1; i <= n; i++)
		if (ans[i] == 2)
			cout << i << ' ';
	cout << endl;

	k = 0;
	for (int i = 1; i <= n; i++)
		if (ans[i] == 0)
			k++;
	cout << k << ' ';
	for (int i = 1; i <= n; i++)
		if (ans[i] == 0)
			cout << i << ' ';
	cout << endl;




	
	return 0;
}