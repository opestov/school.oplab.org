#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxM = 2000;

ll a[maxM];

int main() {


	int 	ans = 0;
	for (int k = 0; k <= 20; k++)
		for (int l = 0; l <= 20; l++) {
			if ((l + 1) * (k + 1) + 1 > 18)
				continue;
			ll x = 8;
			for (int i = 1; i <= k; i++)
				x = x * 10 + 9;
			for (int i = 1; i <= l; i++) {
				x = x * 10 + 7;
				for (int j = 1; j <= k; j++)
					x = x * 10 + 9;
			}
			x = x * 10 + 9;
			ans++;
			a[ans] = x;
				

		}

	for (int k = 1; k <= 20; k++)
		for (int l = 1; l <= 20; l++) {
			if (l * (k + 1) + 1 > 18)
				continue;
			ll x = 0;
			for (int i = 1; i <= l; i++) {
				x = x * 10 + 2;
				for (int j = 1; j <= k; j++)
					x *= 10;
			}
			x = x * 10 + 1;
			ans++;
			a[ans] = x;
		}

	for (int i = 2; i <= 18; i++) {
		ll x = 0;
		for (int j = 1; j < i; j++)
			x = x * 10 + 2;
		x = x * 10 + 1;
		ans++;
		a[ans] = x;
	}

for (int i = 2; i <= 19; i++) {
		ll x = 1;
		for (int j = 1; j < i; j++)
			x = x * 10;
		ans++;
		a[ans] = x;
	}
for (int i = 1; i < 10; i++) {
		ans ++;
		a[ans] = i;
	}

	/*cout << ans << endl;
	for (int i = 1; i <= ans; i++)
		cout << a[i] << '\n';
	*/
	/*sort(a + 1, a + ans + 1);
	for (int i = 2; i <= ans; i++)
		if (a[i] == a[i - 1]) {
			cout << "BAGET" << endl;
		}   */


	int t;
	cin >> t;
	for (int i = 0; i < t; i++) {
		ll l, r;
		cin >> l >> r;
		int cur = 0;
		for (int j = 1; j <= ans ; j++)
			if (l <= a[j] && a[j] <= r)
				cur++;
		cout << cur << endl;
	}
	
	return 0;
}