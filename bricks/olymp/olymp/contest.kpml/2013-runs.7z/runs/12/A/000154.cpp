#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxN = 200001;

struct point{
	ll t;
	int b;
	int i;
};

int a[maxN], b[maxN], t[maxN], ans[maxN];
ll c[20];
point d[maxN];
int n, m;

bool cmp(point a, point b) {
	return (a.t < b.t || (a.t == b.t && a.i < b.i));
}


int main() {

	cin >> n >> m;
	for (int i = 1; i <= n; i++) 
		cin >> t[i] >> a[i] >> b[i];
	c[0] = 2000000001;

	for (int i = 1; i <= n; i++) {
		int k = 1;
		for (int j = 1; j <= m; j++)
			if (c[j] < c[k])
				k = j;
		d[i].t = max((ll)t[i], c[k]) + a[i];
		c[k] = d[i].t;
		d[i].i = i;
		d[i].b = b[i];
	}	

	sort(d + 1, d + n + 1, &cmp);

	ll x = 1;
	for (int i = 1; i <= n; i++) {
		x = max(x, (ll)d[i].t) + d[i].b;
		ans[d[i].i] = x;
	}

	for (int i = 1; i <= n; i++)
		cout << ans[i] << endl;		

	return 0;
}