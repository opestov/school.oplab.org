#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

int n;

int main() {

	cin >> n;
	n++;

	int x = sqrt(n);
	int ans = 0;

	for (int i = 1; i <= x; i++)
		if (n % i == 0) {
			ans++;
			if (n / i != i)
				ans++;	
		}

	cout << ans;
	
	return 0;
}