#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

#define next sajkdfhjas

const int maxN = 510;
const int md = 1e9 + 9;

struct point{
	int i, j, t;
};

char a[maxN][maxN];
int d[maxN][maxN][5], e[maxN][maxN][5];
point q[maxN * maxN * 4];
point go[10];
int n, m;

void init() {
	go[1].i = 1;
	go[1].j = 0;
	go[2].i = 0;
	go[2].j = 1;
	go[3].i = -1;
	go[3].j = 0;
	go[4].i = 0;
	go[4].j = -1;
}

void push(point p, int t, int &r) {
	r++;
	q[r].i = p.i;
	q[r].j = p.j;
	q[r].t = t;
}	

point pop(int &l) {
	l++;
	return q[l];
}

void bfs(point p) {
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			for (int t = 0; t <= 2; t++)
				d[i][j][t] = -1;

	d[p.i][p.j][0] = 0;
	e[p.i][p.j][0] = 1;

	int l = 0;
	int r = 0;
	push(p, 0, r);
	int kol = 0;

	while (r > l) {
		kol++;
		point c = pop(l);

		//printf("%d %d %d\n", c.i, c.j, c.t);
		//if (kol > 100)
		//	break;

		for (int i = 1; i <= 4; i++) {
			point nx;
			nx.i = c.i + go[i].i;
			nx.j = c.j + go[i].j;

			if (nx.i > 0 && nx.i <= n && nx.j > 0 && nx.j <= m && a[nx.i][nx.j] != '#') {
				if (d[nx.i][nx.j][0] == -1) {
					d[nx.i][nx.j][0] = d[c.i][c.j][0] + c.t + 1;
					e[nx.i][nx.j][0] = (e[nx.i][nx.j][0] + e[c.i][c.j][c.t]) % md;
					push(nx, 0, r);
				}
				else {
	            	if (d[c.i][c.j][0] + c.t + 1 - d[nx.i][nx.j][0] <= 2) {
	            		int tt = d[c.i][c.j][0] + c.t + 1 - d[nx.i][nx.j][0];
						if (d[nx.i][nx.j][tt] == -1) {
	                    	d[nx.i][nx.j][tt] = d[nx.i][nx.j][0] + tt;
							e[nx.i][nx.j][tt] = (e[nx.i][nx.j][tt] + e[c.i][c.j][c.t]) % md;
				            push(nx, tt, r);
						}
						else 
							e[nx.i][nx.j][tt] = (e[nx.i][nx.j][tt] + e[c.i][c.j][c.t]) % md;
					}
				}
				
			}
		}
	}  

}

int main() {
	
	init();
	cin >> n >> m;
	point p;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) {
			cin >> a[i][j];
			if (a[i][j] == 'E') {
				p.i = i;
				p.j = j;
			}
		}

	bfs(p);

	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			if (a[i][j] == 'X')
				cout << e[i][j][2];

	
	
	return 0;
}