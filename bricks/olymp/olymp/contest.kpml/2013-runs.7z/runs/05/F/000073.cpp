#include <iostream>

using namespace std;

int main()
{
    int n, ans = 2;
    cin >> n;
    if (n == 0)
    {
        cout << 0;
        return 0;
    }
    for (int i = 1; i <= n/2; i++)
        if ((n - i) / (i + 1.0) - (n - i) / (i + 1) == 0)
        ans++;
    cout << ans;
    return 0;
}
