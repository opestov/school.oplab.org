n= int(input())
y=[]
x=[]
for i in range(n):
    a,b = map(int, input().split())
    x.append(a)
    y.append(b)
x.sort()
y.sort()
x = list(set(x[:n-2]))
y = list(set(y[:n-2]))
print(len(list(y)) + len(list(y)))
if len(x)>0:
    print('x', *list(set([i + 1 for i in x[:n-1]])))
if len(y) > 0:
    print('y', *list(set([i + 1 for i in y[:n-1]])))