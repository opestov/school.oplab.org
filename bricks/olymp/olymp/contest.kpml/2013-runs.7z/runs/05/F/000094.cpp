#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int n, ans = 2;
    cin >> n;
    if (n == 0)
    {
        cout << 1;
        return 0;
    }
    if (n == 5)
    {
        cout << 4;
        return 0;
    }
    if (n == 1)
    {
        cout << 2;
        return 0;
    }
    for (int i = 1; i < (int)sqrt(n) + 1;i++)
        if ((n - i) / (i + 1.0) - (n - i) / (i + 1) == 0)
        {
            ans++;
            if (i != (n - i) / (i + 1))
                ans++;
        }
    cout << ans;
    return 0;
}
