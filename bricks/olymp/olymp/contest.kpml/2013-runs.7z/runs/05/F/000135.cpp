#include <iostream>
#include <math.h>
using namespace std;
int okr(double v)
{
    if ((int)(v * 10) % 10 >= 5)
        return ((int)v + 1);
    else
        return (int)  v;
}
int main()
{
    int n, ans = 2;
    cin >> n;
    if (n == 0)
    {
        cout << 1;
        return 0;
    }
    for (int i = 1; i <  okr(sqrt(n)) ;i++)
        if ((n - i) / (i + 1.0) - (n - i) / (i + 1) == 0)
        {
            if (i != (n - i) / (i + 1))
                ans += 2;
            else
                ans++;
        }
    cout << ans;
    return 0;
}
