def ans(a,c,r,g,b):
    return a * (r ** 2 + g ** 2+ b ** 2) + c * min([r,g,b])

n = int(input())
for i in range(n):
    a,c = map(int, input().split())
    r,g,b = map(int,input().split())
    typ = 0;
    mx = 0
    if ans(a,c,r+1,g,b) > mx:
        mx = ans(a,c,r+1,g,b)
        typ = 1
    if ans(a,c,r,g+1,b) > mx:
        mx = ans(a,c,r,g+1,b)
        typ = 2
    if ans(a,c,r,g,b+1) > mx:
        mx = ans(a,c,r,g,b+1)
        typ = 3
    #print(typ)
    if typ == 1:
        print('RED')
    elif typ == 2:
        print('GREEN')
    elif typ == 3:
        print('BLUE')