
from itertools import permutations
def magic(x):
    for i in x:
        if i[1] == False:
            return False
    return True

n = int(input())
a = [list(j) for j in list(permutations([i + 1 for i in range(n)],n))]
for i in range(len(a)):
    a[i] = [a[i],False]
a[0][1] = True

ans = a[0][0][:]
while(not magic(a)):
    for i in range(n - 1, -1,-1):
        fl = 0
        temp = ans[::-1][:i][::-1]
        for j in a:
            if j[0][:i] == temp and j[1] == False:
                j[1] = True
                fl = 1
                for h in j[0][i:]:
                    ans.append(h)
                break
        if fl == 1:
            break
print(len(ans))
print(*ans)                  