a = []
for i in range(1,11):
    a.append(i)
for i in range(20):
    a.append(int('1' + '0' * (i + 1)))
for i in range(20):
    a.append(int('2' + '0' * i + '1'))
    a.append(int('2' + '2' * i + '1'))
a = list(set(a))
n = int(input())
for i in range(n):
    ans = 0
    l,r = map(int,input().split())
    for j in a:
        if j >= l and j <= r:
            ans += 1
    print(ans)