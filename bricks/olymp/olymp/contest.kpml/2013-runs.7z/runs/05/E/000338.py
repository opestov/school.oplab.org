n = int(input())
x = []
y = []
a = []
for i in range(n):
    a.append([int(x) for x in input().split()])
a.sort()
for i in range(n - 1):
    if a[i][0] != a[i + 1][0]:
        x.append(a[i+1][0])
    else:
        y.append(a[i+1][1])
x = list(set(x))
y = list(set(y))
print(len(x) + len(y))
for i in x:
    print('x',i)
for j in y:
    print('y',j)