#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
using namespace std;
vector < pair <int, int> > p;
vector <int > x;
vector <int> y;
bool cm(pair<int, int> a, pair<int, int> b)
{
    return a.first < b.first || (a.first == b.first && a.second < b.second);
}
int main()
{
    int a, c, b;
    cin >> a;
    for (int i = 0 ; i < a; i++)
    {
        cin >> c >> b;
        p.push_back({c, b});
    }
    sort(p.begin(),p.end(),cm);
    for (int i = 0; i < a - 1; i++)
        if (p[i].first != p[i + 1].first)
            x.push_back(p[i + 1].first);
        else
            if ( p[i].second > p[i + 1]. second)
                y.push_back(p[i].second);
            else
                y.push_back(p[i + 1].second);
    set<int> xx, yy;
    for (int i = 0 ; i < x.size(); i++)
        xx.insert(x[i]);
    for (int i = 0; i < y.size(); i++)
        yy.insert(y[i]);
    cout << xx.size() + yy.size() << '\n';
    if (xx.size() > 0)
    {
        cout << "x ";
        for (set<int>::iterator i = xx.begin(); i != xx.end(); i++)
            cout << *i << " ";
        cout << endl;
    }
    if (yy.size() > 0)
    {
        cout << "y ";
        for (set<int>::iterator i = yy.begin(); i != yy.end(); i++)
            cout << *i << " ";
    }
}
