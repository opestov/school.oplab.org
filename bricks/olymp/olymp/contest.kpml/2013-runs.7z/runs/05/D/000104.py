n,m = map(int, input().split())
a = []
x = []
y = []
z = []
for i in range(m):
    a .append([int(x) for x in input().split()])
a.sort(key = lambda x : x[-1])
for t in a:
    #print(t)
    #print(x)
    for k in x:
        t[k] = 0
    if t[-1] == 0:
        for j in range(n):
            if t[j] == 1:
                x.append(j)
    else:
        if sum(t[:-1]) == 1:
            for j in range(n):
                if t[j] == 1:
                    y.append(j)
        elif sum(t[:-1]) > 1:
            for j in range(n):
                if t[j] == 1:
                    if j not in y:
                        z.append(j)
        else:
            print('Incorrect')
            exit()
print(len(x),*sorted([i + 1 for i in x]))
print(len(y),*sorted([i + 1 for i in y]))
print(len(z),*sorted([i + 1 for i in z]))
    