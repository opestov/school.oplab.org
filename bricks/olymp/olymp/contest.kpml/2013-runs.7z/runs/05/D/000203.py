n,m = map(int, input().split())
a = []
x = []
y = []
z = []
for i in range(m):
    a .append([int(x) for x in input().split()])
a.sort(key = lambda x : x[-1])
for t in a:
    #print(t)
    #print(x)
    for k in x:
        t[k] = 0
    if t[-1] == 0:
        for j in range(n):
            if t[j] == 1:
                x.append(j)
    else:
        if sum(t[:-1]) == 1:
            for j in range(n):
                if t[j] == 1:
                    y.append(j)
                    if j in z:
                        z.remove(j)
        elif sum(t[:-1]) > 1:
            for j in range(n):
                if t[j] == 1:
                    if j not in y and j not in z:
                        z.append(j)
        else:
            print('Incorrect')
            exit()
print(len(list(set(x))),*sorted(list(set([i + 1 for i in x]))))
print(len(list(set(y))),*sorted(list(set([i + 1 for i in y]))))
print(len(list(set(z))),*sorted(list(set([i + 1 for i in z]))))
    