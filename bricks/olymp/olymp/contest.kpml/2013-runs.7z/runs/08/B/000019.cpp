#include <fstream>

using namespace std;
#ifndef _DEBUG
#define FILENAME "bet"
#define INFILE FILENAME".in"
#define OUTFILE FILENAME".out"
#else
#define INFILE "input.txt"
#define OUTFILE "output.txt"
#endif
ifstream cin(INFILE);
ofstream cout(OUTFILE);


int sqr(int a){
  return a * a;
}

int my_min(int a, int b, int c){
  return min(min(a, b), c);
}

int my_max(int a, int b, int c){
  return max(max(a, b), c);
}

int main(){
  int n;
  cin >> n;
  for(int i = 0; i < n; i++){
    int a, c, r, g, b;
    cin >> a >> c >> r >> g >> b;
    int ans1, ans2, ans3;
    ans1 = a * (sqr(r) + sqr(g + 1) + sqr(b)) + c * my_min(r, g + 1, b); //+1 green
    ans2 = a * (sqr(r) + sqr(g) + sqr(b + 1)) + c * my_min(r, g, b + 1); //+1 blue
    ans3 = a * (sqr(r + 1) + sqr(g) + sqr(b)) + c * my_min(r + 1, g, b); //+1 red
    if(my_max(ans1, ans2, ans3) == ans1){
      cout << "GREEN\n";
      continue;
    }
    if(my_max(ans1, ans2, ans3) == ans2){
      cout << "BLUE\n";
      continue;
    }
    cout << "RED\n";
  }
	return 0;
}