#include <fstream>

using namespace std;
#ifndef _DEBUG
#define FILENAME "equation"
#define INFILE FILENAME".in"
#define OUTFILE FILENAME".out"
#else
#define INFILE "input.txt"
#define OUTFILE "output.txt"
#endif
ifstream cin(INFILE);
ofstream cout(OUTFILE);



int main(){
  int kol = 0, b = 0;
  double x, x1 = -10000, n;
  cin >> n;
  for(double i = 0; i * i  <= n; i++){
    x = (n - i) / (1 + i);
    if(x == (int) x)kol++;
    if(x == i)b++;
    if(i == x1){
      kol--;
      break;
    }
    x1 = x;
  }
  cout<<(kol * 2 - b);
	return 0;
}