#include <fstream>
#include <vector>
#include <set>
#include <cstdlib>
#include <algorithm>
using namespace std;

#ifndef _DEBUG
#define FILENAME "bank"
#define INFILE FILENAME".in"
#define OUTFILE FILENAME".out"
#else
#define INFILE "input.txt"
#define OUTFILE "output.txt"
#endif
ifstream cin(INFILE);
ofstream cout(OUTFILE);

int m[15];
int mn, n;
int mini(int a, int t){
  int minim = 99999999, j;
  for(int i = 0; i < mn; i++){
    if(m[i] < minim){
      minim = m[i];
      j = i;
    }
  }
  m[j] += a;
  return m[j];
}

class gnomi{
public:
  int a, b, t;
};
  vector< pair<int, int> > after;
  vector< pair<int, int> >  g;
  gnomi gnom[100000];
int main(){

  int index;
  int b = 0;

  cin >> n >> mn;
  for(int i = 0; i < n; i++){
    cin >> gnom[i].t >>  gnom[i].a >>  gnom[i].b;
    g.push_back(make_pair(gnom[i].t, i));
  }
  sort(g.begin(), g.end());
  for(int i = 0; i < n; i++){
    index = g[i].second;
    gnom[index].t += mini(gnom[index].a, gnom[index].t);
    after.push_back(make_pair(gnom[index].t, i));
  }
  sort(after.begin(), after.end());
  for(int i = 0; i < n; i++){
    index = after[i].second;
    b = max(gnom[index].t, b) + gnom[index].b;
    gnom[index].t = b;
  }
  for(int i = 0; i < n; i++){
    cout << gnom[i].t << '\n';
  }

}