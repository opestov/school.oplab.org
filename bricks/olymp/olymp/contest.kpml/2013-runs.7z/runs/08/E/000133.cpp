#include <fstream>
#include <vector>
#include <set>
using namespace std;
#ifndef _DEBUG
#define FILENAME "division"
#define INFILE FILENAME".in"
#define OUTFILE FILENAME".out"
#else
#define INFILE "input.txt"
#define OUTFILE "output.txt"
#endif
ifstream cin(INFILE);
ofstream cout(OUTFILE);

int n;
string s;
typedef pair<int,int> pos;
set <pos> kor;
pos k;
set <pos> ::iterator j, l, pre_end;
set <int> ans_x, ans_y;

int main(){
  cin>>n;
  for(int i = 0; i < n; i++){
    cin>>k.first >> k.second;
    kor.insert(k);
  }
  pre_end = kor.end();
  pre_end--;
  set <pos>::iterator beginer;
  beginer = kor.begin();
  for(j = kor.begin(); j != pre_end; j++){
    l = j;
    l++;
    if(j->first == l->first){
      ans_y.insert(l->second);
    }
    if(l->first != beginer->first){
      ans_x.insert(l->first);
    }
  }
  cout << ans_x.size() + ans_y.size() << endl;
  set<int>::iterator it;
  for(it = ans_x.begin(); it != ans_x.end(); it++){
    cout << "x " << *it << endl;
  }
  for(it = ans_y.begin(); it != ans_y.end(); it++){
    cout << "y " << *it << endl;
  }
}