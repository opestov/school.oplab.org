#include <fstream>
#include <vector>
#include <set>
#include <cstdlib>
using namespace std;
#ifndef _DEBUG
#define FILENAME "disease"
#define INFILE FILENAME".in"
#define OUTFILE FILENAME".out"
#else
#define INFILE "input.txt"
#define OUTFILE "output.txt"
#endif
ifstream cin(INFILE);
ofstream cout(OUTFILE);

int sum[10020], a[10020][120], n, m;
vector<int> can, cannot, doubt;
bool pos[10020];

int main(){
  int checker, cnt, ch2;
  cin >> n >> m;
  for(int i = 0; i < m; i++){
    for (int j = 0; j < n; j++){
      cin >> a[i][j];
      sum[i] += a[i][j];
    }
    sum[i]--;
    cin >> pos[i];
    if(!pos[i]){
      sum[i] = 0;
    }
  }
  for(int j = 0; j < n; j++){
    checker = -1;
    for(int i = 0; i < m; i++){
      if(checker == -1){
        if(a[i][j] != 0){ 
          if(sum[i] == 0){
            checker = pos[i];
          }
        }
      }else{
        if(sum[i] > 0 || a[i][j] == 0) continue;
        ch2 = pos[i];
        if(ch2 != checker){
          cout << "Incorrect";
          exit(0);
        }
      }
    }
    if(checker == -1){
      doubt.push_back(j+1);
    }
    if(checker == 1){
      can.push_back(j+1);
    }
    if(checker == 0){
      cannot.push_back(j+1);
    }
    if (checker == -1) continue;
    for(int i = 0; i < m; i++){
      if(sum[i] > 0 && a[i][j] == 1)
        sum[i]--;
    }

  }
  cout << cannot.size() << ' ';
  for(int i = 0; i < (int) cannot.size(); i++){
    cout << cannot[i] << ' ';
  }
  cout << '\n';
  cout << can.size() << ' ';
  for(int i = 0; i < (int)can.size(); i++){
    cout << can[i] << ' ';
  }
  cout << '\n';
  cout << doubt.size() << ' ';
  for(int i = 0; i < (int)doubt.size(); i++){
    cout << doubt[i] << ' ';
  }

  return 0;
}