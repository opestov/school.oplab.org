#include <fstream>
#include <vector>
#include <cstdlib>
#include <set>
#include <algorithm>
using namespace std;
#ifndef _DEBUG
#define FILENAME "cipher"
#define INFILE FILENAME".in"
#define OUTFILE FILENAME".out"
#else
#define INFILE "input.txt"
#define OUTFILE "output.txt"
#endif
ifstream cin(INFILE);
ofstream cout(OUTFILE);

vector <vector <int> > perms;
vector <bool> used;
vector <int> ans;

int n;

int find(int la, int ra){
  vector <int> slice;
  bool ok = true;
  for(int i = la; i < ra; i++){
    slice.push_back(ans[i]);
  }
  for(int i = 0; i < perms.size(); i++){
    if(used[i])
      continue;
    ok = true;
    for(int j = 0; j < slice.size(); j++){
      if(slice[j] != perms[i][j]){
        ok = false;
        break;
      }
    }
    if(ok)
      return i;
  }
  return -1;
}


int main(){
  cin >> n;
  vector <int> foo;
  for(int i = 1; i <= n; i++){
    foo.push_back(i);
  }
  perms.push_back(foo);
  while(next_permutation(foo.begin(), foo.end())){
    perms.push_back(foo);
  }
  used.resize(perms.size());
  fill(used.begin(), used.end(), false);
  used[0] = true;
  int used_cnt = 1;
  for(int i = 0; i < perms[0].size(); i++){
    ans.push_back(perms[0][i]);
  }

  int i = 1;

  while(used_cnt < perms.size()){
    int finded = find(i, ans.size());
    if(finded == -1){
      i++;
      continue;
    }
    int last_match = 0;
    while(i + last_match < ans.size() && perms[finded][last_match] == ans[i + last_match]){
      last_match++;
    }
    bool added = false;
    for(int k = last_match; k < perms[finded].size(); k++){
      ans.push_back(perms[finded][k]);
      added = true;
    }
    if(added)
      i = ans.size() - n + 1;
    used[finded] = true;
    used_cnt++; 
  }
  cout << ans.size() << endl;
  for(int i = 0; i < ans.size(); i++){
    cout << ans[i] << " ";
  }
  return 0;
}