﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            long t = long.Parse(Console.ReadLine());

            for (long i = 0; i < t; i++)
            {
                long count = 0;

                string[] temp = Console.ReadLine().Split(' ');
                long L = long.Parse(temp[0]);
                long R = long.Parse(temp[1]);
                
                
                /*if (L == R)
                {
                    if (check((L - 1).ToString()) && check((L + 1).ToString()))
                    {
                        Console.WriteLine("1");
                    }
                }
                else*/
                {
                    for (long j = L; j <= R; j++)
                    {
                        if (check((j - 1).ToString()) && check((j + 1).ToString()))
                        {
                            // Console.WriteLine(j - 1);
                            count++;
                        }

                        //Console.WriteLine(j);
                    }

                    Console.WriteLine(count);
                }
            }
        
           /*int x=2;
           bool ch = check(x.ToString());*/
        }

        static bool check(string x)
        {
            if (x == "0")
            {
                return true;
            }
                char[] ch = x.ToCharArray();
                long len = ch.Length-1;
                                               
                while (ch[len] == '0')
                {
                    len -= 1;
                }

                //if (x.Length % 2 == 1) return false;

                long n = len;
                for (long i = 0; i <= n / 2; i++)
                {
                    if (ch[i] != ch[len])
                        return false;
                    len--;
                }
            
            return true;
        }
    }
}
