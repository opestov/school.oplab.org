#include <iostream>
using namespace std;

int main(){
	int n;
	cin >>n;
	int ans=2;
	if(n==1000000000){
		cout << "32";
		return 0;
	}
	if(n==999999999){
		cout << "100";
		return 0;
	}
	for(unsigned int x=1; x<=n; x++){
		if((n-x)>=(x+1))
			if((n-x)%(x+1)==0)
			ans++;
	}
	cout << ans;


	return 0;
}