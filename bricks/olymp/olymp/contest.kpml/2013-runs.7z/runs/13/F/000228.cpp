#include <iostream>
#include <cmath>
using namespace std;

int main(){
	int n;
	cin >>n;
	n++;
	int limit = sqrt(n);
	int a = 1, b = 1;
	int s = 0;
	while (a <= limit)
	{
		if (n%a == 0)
        {
			s += 2;
			b = a;
        }
        a++;
	}
	if (limit * b == n) s--;
	cout << s;


	return 0;
}
