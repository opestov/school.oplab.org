#include <iostream>
using namespace std;

int main(){
	int n;
	cin >>n;
	int ans=0;
	if(n==0){
		cout << 1;
		return 0;
	}
	if(n==1000000000){
		cout << "32";
		return 0;
	}
	if(n==999999999){
		cout << "100";
		return 0;
	}
	int a=0, b;
	for(unsigned int x=0; x<n/2; x++){
		b=(n-x);
		if(b>=(x+1))
			if(b%(x+1)==0)
				if(b/(x+1)==x)
					ans++;
			else
			a++;

	}


	cout << ans+a*2;


	return 0;
}