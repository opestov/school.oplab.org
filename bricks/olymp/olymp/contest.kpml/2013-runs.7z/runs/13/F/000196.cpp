#include <iostream>
#include <cmath>
using namespace std;

int main(){
	int n;
	cin >>n;

	n++;
	int limit = sqrt(n);
	int a(1), b(1);
	int s(0);
	do
	{
		if (n%a == 0)
			s += 2;
	} while (a <= limit)
	b = n/a;
	if (b == a) s--;
	cout << s;


	return 0;
}