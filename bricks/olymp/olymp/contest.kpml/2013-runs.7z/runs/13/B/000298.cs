#include <iostream>
#include <algorithm>
using namespace std;

inline int count(int a, int c, int r, int g, int b)
{
	return a*(r*r+g*g+b*b)+c*min(r, min(g, b));
}
int main(){
	int N;
	cin >> N;
	int a, c;
	int r, g, b;
	for (int i = 0; i < N; i++)
		{
			cin >> a>> c>> r>> g>> b;
			int q, w,e;
			q=count(a, c, r+1, g, b);
			w=count(a, c, r, g+1, b);
			e=count(a, c, r, g, b+1);
			if (q>= w && q>= e) cout << "RED\n";
			else if (w>=e) cout << "GREEN\n";
			else cout << "BLUE\n";

		}

	return 0;
}