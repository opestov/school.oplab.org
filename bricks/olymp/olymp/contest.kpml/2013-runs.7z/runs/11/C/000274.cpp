#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

#define pb push_back

int n;
vector < int > v, perm, gans;
vector <bool> used;

const int p[10] = {(int)1e0, (int)1e1, (int)1e2, (int)1e3, (int)1e4, (int)1e5, (int)1e6, (int)1e7, (int)1e8, (int)1e9};




void binsearch(long long x) {
    int l = 0;
    int r = perm.size();
    while (r - l > 1) {
        int m = (l + r) / 2;
        if (perm[m] > x) {
            r = m;
        }
        else {
            l = m;
        }
    }
    //cout << l << endl;
    used[l] = true;
}


void do_it(int x) {
    long long ans;
    gans.clear();
    //ans = x * p[n - 1] + x / 10;
    ans = x;
    for (int i = 0; i < n - 1; ++i) {
        ans = ans * 10;
        ans = ans + (ans / p[n]) % 10;
        //cout << ans % p[n] << endl;
        binsearch(ans % p[n]);
    }
    for (int i = 0; i < 2 * n - 1; ++i) {
        gans.pb(ans % 10);
        ans = ans / 10;
    }
    for (int i = gans.size() - 1; i >= 0; --i) {
        cout << gans[i] << " ";
    }
    
}



int main() {
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);   
    cin >> n;
    for (int i = 1; i <= n; i++)
        v.pb(i);
    do {
        int q = 0;
        int d = 1;                 
        for (int j = n - 1; j + 1; j--){
            q += v[j] * d;
            d *= 10;
        }
        perm.pb(q);
        used.pb(false);
       // printf("%d\n", q);
    } while (next_permutation(v.begin(), v.end()));
    cout << (perm.size() / n) * (2 * n - 1) << endl;;
    for (int i = 0; i < (int)perm.size(); ++i) {
        if (not(used[i])) {
            
            used[i] = true;
            do_it(perm[i]);
        }
    }
    return 0;
}