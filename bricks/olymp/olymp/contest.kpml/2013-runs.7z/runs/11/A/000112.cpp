#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;
struct req{
    int n, a, b;
    long long t;
};

vector <req> mas;
vector <req> newq;
req r;
int n, m;
long long masq[10], mast[100000];

bool comp(req r1, req r2) {
    if (r1.t == r2.t) {
        return r1.n < r2.n;
    }
    return r1.t < r2.t;
}

int main() {
    freopen("bank.in", "r", stdin);
    //freopen(".out", "w", stdout);   
    cin >> n >> m;
    for (int i = 0; i < n; ++i) {
        cin >> r.t >> r.a >> r.b;
        r.n = i;
        mas.push_back(r);
    }
    sort(mas.begin(), mas.end(), comp);

    for (int i = 0; i < (int) mas.size(); ++i) {
        long long mint = 1000000000000001;
        int mem = 0;
        for (int j = 0; j < m; ++j) {
            if (mint > masq[j]) {
                mint = masq[j];
                mem = j;
            }
        }
        masq[mem] = max(masq[mem] + mas[i].a, mas[i].t + mas[i].a);
        //cout << mas[i].n << " " << masq[mem] << " " << mem << endl;
        req newr;
        newr.t = masq[mem];
        newr.n = mas[i].n;
        newr.b = mas[i].b;
        newq.push_back(newr);
    }
    sort(newq.begin(), newq.end(), comp);
    long long tim = newq[0].t;
    for (int i = 0; i < (int) newq.size(); ++i) {
        tim = max(tim + newq[i].b, newq[i].t + newq[i].b);
        mast[newq[i].n] = tim;       
    }

    for (int i = 0; i < n; ++i) {
        cout << mast[i] << endl;
    }

    return 0;
}