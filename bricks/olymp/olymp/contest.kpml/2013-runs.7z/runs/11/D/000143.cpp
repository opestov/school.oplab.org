#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

int n, m, masb[100], an[10000][100], ans[10000];

vector <int> o, no;

int main() {
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);   
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> an[i][j];
        }
        cin >> ans[i];
        if (ans[i] == 0) {
            for (int j = 0; j < n; ++j) {
                if (an[i][j] == 1) {
                    masb[j] = 1;
                    no.push_back(j + 1);
                }
            }
        }

    }
    for (int i = 0; i < m; ++i) {
        if (ans[i] == 1) {
            int sum = 0, mem = 0;
            for (int j = 0; j < n; ++j) {
                if (an[i][j] == 1 && masb[j] == 0) {
                    ++sum;
                    mem = j;
                }
            }
            if (sum == 1) {
                masb[mem] = 2;
                o.push_back(mem + 1);
            }
            if (sum == 0) {
                cout << "Incorrect";
                return 0;
            }
        }

    }
    sort(no.begin(), no.end());
    sort(o.begin(), o.end());
    cout << no.size() << " ";
    for (int i = 0; i < (int) no.size(); ++i) {
        cout << no[i] << " ";
    }
    cout << endl;
    cout << o.size() << " ";
    for (int i = 0; i < (int) o.size(); ++i) {
        cout << o[i] << " ";
    }
    cout << endl;
    cout << n - ((int) o.size() + (int) no.size()) << " ";
    for (int i = 0; i < n; ++i) {
        if (masb[i] == 0) {
            cout << i + 1 << " ";
        }
    }
    return 0;
}