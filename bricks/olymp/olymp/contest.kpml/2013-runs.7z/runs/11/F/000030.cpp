#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

long long ans, n;


int main() {
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);   
    cin >> n;
    ++n;
    ans = 0;
    for (int i = 1; i < sqrt(n); ++i) {
        if (n % i == 0) {
            //cout << i << endl;
            ++ans;    
        }
    }
    ans = ans * 2;
    if ((int)sqrt(n) * (int)sqrt(n) == n) {
        ++ans;
    }
    cout << ans; 
    return 0;
}