#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

int t, dr[3] = {1, 0, 0}, dg[3] = {0, 1, 0}, db[3] = {0, 0, 1};
string masa[3] = {"RED", "GREEN", "BLUE"};

int main() {
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);   
    cin >> t;
    for (int i = 0; i < t; ++i) {
        int A, C, r, g, b;
        cin >> A >> C >> r >> g >> b;
        int maxv = 0, mem = 0;
        for (int j = 0; j < 3; ++j) {
            int nr = r + dr[j], ng = g + dg[j], nb = b + db[j];
            //cout << nr << " " << ng << " " << nb << endl;
            if (maxv < A * (nr * nr + ng * ng + nb * nb) + C * min(nr, min(ng, nb))) {
                maxv = A * (nr * nr + ng * ng + nb * nb) + C * min(nr, min(ng, nb));
                //cout << maxv << " " << j << endl;
                mem = j;
            }
        }
        cout << masa[mem] << endl;
    }
    return 0;
}