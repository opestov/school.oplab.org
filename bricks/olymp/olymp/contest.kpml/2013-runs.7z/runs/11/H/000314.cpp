#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

int n, l, r;
int mas[11] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 21};

int main() {
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);   
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> l >> r;
        int num = 0;
        for (int i = 0; i < 11; ++i) {
            if (l <= mas[i] && r >= mas[i]) {
                ++num;
            }
        }
        cout << num << endl;
    }
    
    return 0;
}