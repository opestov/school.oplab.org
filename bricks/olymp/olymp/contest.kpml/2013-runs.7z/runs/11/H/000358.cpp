#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

int n, l, r;
vector <long long> mas;
long long dm[12] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 21, 89};

int main() {
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);   
    long long ds = 100, db = 222;
    for (int i = 0; i < 17; ++i) {
        mas.push_back(ds);
        mas.push_back(db - 1);
        //cout << ds;
        db *= 10;
        db += 2;
        ds *= 10;    
    }
    for (int i = 0; i < 12; ++i) {
        mas.push_back(dm[i]);
    }
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> l >> r;
        int num = 0;
        for (int i = 0; i < (int) mas.size(); ++i) {
            if (l <= mas[i] && r >= mas[i]) {
                ++num;
            }
        }

        cout << num << endl;
    }
    
    return 0;
}