#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

int n, m, masc[1000000], num, mas[300][300];
vector <int> ans;
vector <string> typeans;

int main() {
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);   
    cin >> n >> m;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> num;
            mas[i][j] = num;
            ++masc[num - 1];
        }
    }
    int maxn = 0, mem = 0;
    for (int i = 0; i < 1000000; ++i) {
        if (maxn < masc[i]) {
            maxn = masc[i];
            mem = i;
        }
    }
    while (true) {
        bool truly = true;
        for (int i = 0; i < n; ++i) {
            int sum = 0;
            for (int j = 0; j < m; ++j) {
                if (mas[i][j] == mem) {
                    ++sum;
                }
            }
            if (sum < m && sum > m / 2) {
                truly = false;
                typeans.push_back("R");
                ans.push_back(i + 1);
                for (int j = 0; j < m; ++j) {
                    mas[i][j] = mem;
                }    
            }
        }
        for (int i = 0; i < m; ++i) {
            int sum = 0;
            for (int j = 0; j < n; ++j) {
                if (mas[j][i] == mem) {
                    ++sum;
                }
            }
            if (sum < n && sum > n / 2) {
                truly = false;
                typeans.push_back("C");
                ans.push_back(i + 1);
                for (int j = 0; j < n; ++j) {
                    mas[j][i] = mem;
                }    
            }
        }
        if (truly) {
            break;
        }
    }
    //bool truly = true;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (mas[i][j] != mem) {
                cout << "Poor Kazimir";
                return 0;
            }
        }
    }
    for (int i = 0; i < (int) ans.size(); ++i) {
        cout << typeans[i] << " " << ans[i] << endl;
    }
    return 0;
}