#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>

using namespace std;

#define pb push_back
#define mp make_pair
#define ff first
#define ss second

int n;

vector < int > vx;
vector < int > vy;

vector < int > ax;
vector < int > ay;

int main() {
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		vx.pb(x);
		vy.pb(y);
	}
	sort(vx.begin(), vx.end());
	sort(vy.begin(), vy.end());
	for (int i = 0; i < n;) {
		ax.pb(vx[i]);
		int j;
		for (j = i; vx[i] == vx[j] && j < n; j++);
		i = j;
	}	
	for (int i = 0; i < n;) {
		ay.pb(vy[i]);
		int j;
		for (j = i; vy[i] == vy[j] && j < n; j++);
		i = j;
	}
	int sx = ax.size();
	int sy = ay.size();

	printf("%d\n", sx + sy - 2);

	if (sx > 1) {
		printf("x ");
		for (int i = 0; i < sx - 1; i++) 
			printf("%d ", ax[i] + 1);
		printf("\n");
	}

	if (sy > 1) { 
		printf("y ");
		for (int i = 0; i < sy - 1; i++) 
			printf("%d ", ay[i] + 1);
		printf("\n");
	}

    return 0;
}