#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>
#include <set>

using namespace std;

#define pb push_back
#define mp make_pair
#define ff first
#define ss second

int n;

vector < pair < int, int > > v;

vector < int > xans;
vector < int > yans;
vector < int > nyans;

int main() {
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		v.pb(mp(x, y));
	}
	sort(v.begin(), v.end());
	for (int i = 1; i < n; i++) {
		if (v[i].ff == v[i - 1].ff) 
			yans.pb(v[i].ss);
		else
			xans.pb(v[i].ff);
	}
	int sx = xans.size();
	int sy = yans.size();
	printf("%d\n", sx + sy);
	if (sx) {
		printf("x ");
		for (int i = 0; i < sx; i++)
			printf("%d ", xans[i]);
		printf("\n");
	}

	sort(yans.begin(), yans.end());
	for (int i = 0; i < sy;) {
		nyans.pb(yans[i]);
		int j = i;
		for (;yans[j] == yans[i] && j < sy; j++);
		i = j;
	}
	int nsy = nyans.size();

	if (nsy) {
		printf("y ");
		for (int i = 0; i < nsy; i++)
			printf("%d ", nyans[i]);
		printf("\n");
	}

    return 0;
}

