#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>
#include <set>

using namespace std;

#define pb push_back
#define mp make_pair
#define ff first
#define ss second

int n;

vector < pair < int, int > > v;

vector < int > ax;
vector < int > qay;
vector < int > ay;

int main() {
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		v.pb(mp(x, y));
	}
	sort(v.begin(), v.end());

	for (int i = 0; i < n; ) {
		//printf("! %d\n", i);
		ax.pb(v[i].ff + 1);
		int j;
		for (j = i; v[j].ff == v[i].ff && j < n; j++);
		i = j;
	}
	ax.pop_back();
	for (int i = 0; i < n;) {
		int j;
		for (j = i + 1; v[j].ff == v[i].ff && j < n; j++) {
			qay.pb(v[j].ss);
		}
		i = j;
	}	
	int sax = ax.size();
	int sqay = qay.size();
	sort(qay.begin(), qay.end());
	for (int i = 0; i < sqay;) {
		ay.pb(qay[i]);
		int j;
		for (j = i; qay[j] == qay[i] && j < sqay; j++);
		i = j;
	}

	int say = ay.size();
	printf("%d\n", sax + say);
	printf("x ");
	if (sax) {
		for (int i = 0; i < sax; i++)
			printf("%d ", ax[i]);
		printf("\n");
	}
	printf("y ");
	if (say) {
		for (int i = 0; i < say; i++) {
			printf("%d ", ay[i]);
			//ay.pop();
		}
		printf("\n");
	}
    return 0;
}

