using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = Int32.Parse(Console.ReadLine());
            if (i % 2 == 0)
                Console.Write("Yes");
            else
                Console.Write("No");
        
        }
    }
}
