using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            string str1 = Console.ReadLine();
            string[] temp = str.Split(' ');
            string[] temp2 = str1.Split(' ');

            int count = 0;

            for (int i = 0; i < temp.Length; i++)
            {
                for (int j = 0; j < temp2.Length; j++)
                {
                    if (temp[i] == temp2[j])
                    {
                        count++;
                    }
                }
            }
            if (count >= temp2.Length)
            {
                Console.Write("Yes");
            }
            else
            {
                Console.Write("No");
            }
        }
    }
}
