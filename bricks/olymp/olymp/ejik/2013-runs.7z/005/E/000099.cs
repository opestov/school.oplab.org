using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = Console.ReadLine().Split(' ');
            int w = Int32.Parse(str[0]);
            int h = int.Parse(str[1]);

            int count = 0;

            for (int i = 0; i < h; i++)
            {
                string temp = Console.ReadLine();
                temp = temp.Replace(".", "");
                count += temp.Length;
            }

            Console.Write(count);
        }
    }
}
