#include <iostream>
#include <string>
using namespace std;

int main()
{
  string a;
  string b;
  cin >> a;
  cin >> b;

   while(a == b)
   {
    cout << "Yes";
    return 0;
   }

cout << "No";

    return 0;
}
