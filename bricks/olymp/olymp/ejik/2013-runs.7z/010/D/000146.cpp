#include <iostream>

using namespace std;

int main()
{
    int o = 1000;
    int a[o];
    unsigned long long i;
    unsigned long long Sum;
    cin >> i;
    while(a[o] == i){



  cin >> a[o];
o++;
    }

cout << a[o];

    return 0;
}
