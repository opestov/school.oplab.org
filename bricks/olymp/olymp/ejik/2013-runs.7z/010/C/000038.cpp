#include <iostream>
using namespace std;

int main()
{
 double l,r,h,n;
 cin >> l;
 cin >> r;
 h = r-l;
n = r-l;
if (h < 0)
{
    n = h * (-1);

}

cout << n;
    return 0;
}
