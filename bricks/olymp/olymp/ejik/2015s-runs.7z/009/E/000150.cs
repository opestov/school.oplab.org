﻿using System;
using System.Collections.Generic;

class num {
	public int k, n;
}

class Program {
	static int cmp(num x, num y) {
		return y.k - x.k;
	}
	static void Main() {
		int d = 0;
		Queue<int> q = new Queue<int>();
		int g = Convert.ToInt32(Console.ReadLine());
		string[] tea = Console.ReadLine().Split(' ');
		num[] a = new num[g + 1];
		for (int i = 0; i < tea.Length; i ++) {
			a[i] = new num();
			a[i].k = Convert.ToInt32(tea[i]);
			a[i].n = i + 1;
		}
		a[g] = new num();
		a[g].k = 0;
		a[g].n = 0;
		Array.Sort(a, cmp);
		while ((a[1].k != 0) && (a[0].k != 0)) {
			int i = 1;
			while ((a[0].k >= a[1].k) && (a[i].k > 0) && (a[0].k > 0)) {
				q.Enqueue(a[0].n);
				a[0].k --;
				q.Enqueue(a[i].n);
				a[i].k --;
				i ++;
				d += 2;
			}
			Array.Sort(a, cmp);
		}
		if (a[0].k != 0) {
			q.Enqueue(a[0].n);
			d ++;
		}
		Console.WriteLine(d);
		while (q.Count != 0)
			Console.Write(q.Dequeue() + " ");
	}
}