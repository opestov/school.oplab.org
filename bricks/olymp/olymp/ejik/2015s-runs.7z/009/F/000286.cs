﻿using System;

class Program {
	static void Main() {
		string[] nk = Console.ReadLine().Split();
		int n = Convert.ToInt32(nk[0]), k = Convert.ToInt32(nk[1]);
		int s = 0, i = 0, good = 1, ch = 0, nch = 0;
		while ((i < k) && (good < n)) {
			i += good;
			s ++;
			if (s % 2 == 0) {
				if (ch + good <= n) {
					i += ch;
					int t = good;
					good += ch;
					ch += t;
				}
				else {
					i += n - ch;
					good = n;
				}
			}
			else {
				if (nch + good <= n) {
					i += nch;
					int t = good;
					good += nch;
					nch += t;
				}
				else {
					i += n - nch;
					good = n;
				}
			}
		}
		while (i < k) {
			i += good;
			s ++;
		}
		Console.WriteLine(s);
	}
}