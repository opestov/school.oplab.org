n = int(input())
##a = [int(x) for x in input().split(' ')]
##a = dict(zip(range(1,101), map(int, input().split(' '))))
a = dict(zip(map(int, input().split(' ')), range(1,101)))
res = []
if n == 1:
    print(1)
elif n == 2:
    if min(a) == max(a):
        t = 2*min(a)
    else:
        t = 2*min(a) + 1
    for i in range(t):
        if i % 2 == 0:
            res.append(a[max(a)])
        else:
            res.append(a[min(a)])
    print(res)
else:
    pass
