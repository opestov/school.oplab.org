h, w = map(int, input().split(' '))
field = []
for i in range(h):
    field.append(list(input()))
res = 0
if h == 1:
    for i in range(w-1):
        if field[0][i] == '>':
            res += 1
elif w == 1:
    for i in reversed(range(h)):
        if field[i][0] == '^':
            res += 1
else:
    pass
print(res)
        
