h, w = map(int, input().split(' '))
field = []
for i in range(h):
    field.append(list(input()))
res = 0
isAns = True
if h == 1:
    for i in range(w-1):
        if field[0][i] == '>':
            res += 1
        else:
            print(-1)
            isAns = False
            break
    if isAns:
        print(res)
elif w == 1:
    for i in reversed(range(1, h)):
        if field[i][0] == '^':
            res += 1
        else:
            print(-1)
            isAns = False
            break
    if isAns:
        print(res)
else:
    pass
