n,k = map(int, input().split(' '))
time = 0
if n == 1:
    time = k*n
    print(time)
elif n == 2:
    t = 0
    if k == 1:
        print(1)
    else:
        if k%2 != 0:
            while t <= k:
                if t == 0:
                    time += 2
                    t += 2
                else:
                    time += 1
                    t += 2
            print(time)
        else:
            while t != k:
                if t == 0:
                    time += 2
                    t += 2
                else:
                    time += 1
                    t += 2
            print(time)
