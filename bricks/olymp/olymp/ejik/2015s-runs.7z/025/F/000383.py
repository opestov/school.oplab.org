n,k = map(int, input().split(' '))
time = 0
if n == 1:
    time = k*n
    print(time)
elif n == 2:
    t = 0
    if k == 1:
        print(1)
    else:
        if k%2 != 0:
            while t <= k:
                if t == 0:
                    time += 2
                    t += 2
                else:
                    time += 1
                    t += 2
            print(time)
        else:
            while t != k:
                if t == 0:
                    time += 2
                    t += 2
                else:
                    time += 1
                    t += 2
            print(time)
elif n == 3:
    produced = 0
    if k == 1:
        print(1)
    elif k == 2:
        print(2)
    else:
        if k%2 != 0:
            while produced <= k:
                if produced == 0:
                    time += 2
                    produced += 2
                elif produced == 2:
                    time += 1
                    produced += 2
                else:
                    time += 1
                    produced += 3
            print(time)
        else:
            while produced != k:
                if produced == 0:
                    time += 2
                    produced += 2
                elif produced == 2:
                    time += 1
                    produced += 2
                else:
                    time += 1
                    produced += 3
            print(time)

