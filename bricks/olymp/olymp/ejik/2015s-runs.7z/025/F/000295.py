n,k = map(int, input().split(' '))
res = 0
if n == 1:
    res = k*n
print(res)
