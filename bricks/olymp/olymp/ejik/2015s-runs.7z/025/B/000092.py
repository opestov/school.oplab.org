n = int(input())
tea = []
for i in range(n):
    tea.append(1)
##res = 0
for i in range(1, 2001):
    if i == 1 or i%2 == 0:
        if 1 in tea:
##            res += 1
            tea[tea.index(1)] /= 2
        else:
            res = i
            break
print(res-1)
