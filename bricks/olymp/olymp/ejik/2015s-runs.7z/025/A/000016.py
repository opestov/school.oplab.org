import math

n, m, x = map(int, input().split(' '))
res = math.ceil(((m*(n+1)) / x))
print(res)
