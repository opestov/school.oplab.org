#include <iostream>
#include <cmath>
using namespace std;

int main()
{
int n;
cin >> n;
int mas;

    cin >> mas;

if(n == 1)
{


cout << "1";
}


}


