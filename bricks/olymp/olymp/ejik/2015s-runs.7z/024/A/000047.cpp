#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n,m,x;
    cin>>n>>m>>x;
    if((x - (n+1)*m) > 0)
    {
        cout << "1";
    }
    else{

        cout <<ceil((n+1)*m/x);

    }
}
