#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double n,m,x;
    cin>>n>>m>>x;
    cout<<ceil(n*m/x);
}
