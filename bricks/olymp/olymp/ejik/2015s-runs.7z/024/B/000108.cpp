#include <iostream>
#include <cmath>
using namespace std;

int main()
{
   long double n,a;
   int res=0;
   cin>>n;
   if ((n!=1)&&((n/2)!=floor(n/2))) res+=1;
   res+=n;
   while(true)
   {
       a=n-floor(n);
       n=floor(n);
        n/=2;
       res+=n;
       n+=a;
       if (n<1) break;
   }
   cout<<res;

}
