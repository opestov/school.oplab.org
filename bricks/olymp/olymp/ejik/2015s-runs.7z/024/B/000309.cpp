#include <iostream>
#include <cmath>
using namespace std;

int main()
{
   long double n,a;
   int res=0;
   cin>>n;
   while(true)
   {
       a=n-floor(n);
       n=floor(n);
        res+=n;
        n/=2;
       n+=a;
       if (n<1) break;
   }
   cout<<res;

}
