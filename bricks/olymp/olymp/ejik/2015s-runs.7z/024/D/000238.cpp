#include <iostream>

using namespace std;

int main()
{
    int h,w,x,y,res,a;
    res=0;
    a=0;
    bool result=true;
    cin>>h>>w;
    x=h-1;
    y=0;
    char table[h][w];
    int mass[h*w][2];
    for (int i=0;i<h;i++)
        for (int j=0;j<w;j++)
        cin>>table[i][j];
    while (true)
    {
       mass[res][0]=x;
       mass[res][1]=y;
       if (table[x][y]=='>') y+=1;
       else if (table[x][y]=='<') y-=1;
       else if (table[x][y]=='v') x+=1;
       else if (table[x][y]=='^') x-=1;
       res+=1;
       if ((x==0)&&(y==(w-1))) break;
       if (((x<h)&&(y<w)&&(x>=0)&&(y>=0))==false) {result=false;}
       for (int i=0; i<res;i++)
        if ((mass[i][0]==x)&&(mass[i][1]==y)) {result=false;}
        if (result==false) break;
    }
    if ((h==1)&&(w==1)&&(table[0][0]=='.')) cout<<0;
    else if (result==false) cout<<-1;
    else cout<<res;
}
