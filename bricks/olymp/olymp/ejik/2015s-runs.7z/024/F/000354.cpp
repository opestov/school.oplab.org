#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    long double n,k;
    cin>>n>>k;
    if (n==1) cout<<k;
    else if (n==2) cout<<(2+ceil((k-2)/n));
    else if (n==3) cout<<(3+ceil((k-4)/n));
}
