import java.util.Scanner;

public class ejik {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=scanner.nextInt()+1;
        int m=scanner.nextInt();
        int x=scanner.nextInt();
        if ((n*m)%x==0){
        System.out.println(n*m/x);
        }else {
            if (n*m<x){
                System.out.println(1);
            }else {
                System.out.println((n*m/x)+1);
            }
        }
    }
}
