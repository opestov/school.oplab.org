import java.util.Scanner;

public class n {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int a=scanner.nextInt();
        int d=scanner.nextInt();
        for (int i=0;i<a;i++){
            scanner.nextInt();
        }
        if (d==a+1){
            System.out.println(1);
        }else {
            System.out.println(2);
        }
    }
}
