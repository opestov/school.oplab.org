import java.util.Scanner;

public class ejik2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int h = scanner.nextInt(), w = scanner.nextInt();
        int scet = 0, str = h-1, sim = 0;
        String[] pole = new String[h];

            for (int i = -1; i < h; i++) {
                try { pole[i] = scanner.nextLine(); }
                catch (ArrayIndexOutOfBoundsException ew){

                }
            }

        for (; ; scet++) {
            try {
                if (pole[str].charAt(sim) == '.') {
                    System.out.println(scet);
                    break;
                } else {
                    if (pole[str].charAt(sim) == '>') {
                        sim++;
                    } else {
                        if (pole[str].charAt(sim) == '^') {
                            str--;
                        } else {
                           if (pole[str].charAt(sim) =='<'){
                               sim--;
                           }else {
                               str++;
                           }
                        }
                    }
                }
            } catch (StringIndexOutOfBoundsException e) {
                System.out.println(-1);
                break;
            }
        }
    }
}
