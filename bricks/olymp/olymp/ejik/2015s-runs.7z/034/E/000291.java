import java.util.Scanner;

public class e {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int i=scanner.nextInt();
        if (i==1){
            scanner.nextInt();
            System.out.println(1);
            System.out.println(1);
        }else {
            if (i==2){
                int per=scanner.nextInt();
                int f=scanner.nextInt();
                if (per==f){
                System.out.println(f*2);
                    for (int q=0;q<f;q++){
                        System.out.print(1);
                        System.out.print(2);
                    }
                }
                else {
                    System.out.println(Math.min(per,f)*2+1);
                    if (Math.min(per,f)==f){
                        for (int q=0;q<f;q++){
                            System.out.print(1);
                            System.out.print(2);
                        }
                        System.out.print(1);
                    }else {
                        for (int q=0;q<f;q++){
                            System.out.print(2);
                            System.out.print(1);
                        }
                        System.out.print(2);
                    }
                }
            }
        }
    }
}
