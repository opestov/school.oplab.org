import java.util.Scanner;

public class n {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        scanner.nextInt();
        int d=scanner.nextInt();
        System.out.print(d);
    }
}
