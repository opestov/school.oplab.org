import java.util.Scanner;

public class ejik {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=scanner.nextInt();
        int col=0;
        for (Double i =(double) n; i/2>=1;col++,i/=2){

        }
        System.out.println(col+n);
    }
}
