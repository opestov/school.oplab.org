﻿using System;

namespace ConsoleApplication10
{
    class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            int t = 0;
            while (n >= 1)
            {
                n -= 0.5;
                t++;
            }
            Console.WriteLine(t);
            Console.ReadLine();
        }
    }
}
