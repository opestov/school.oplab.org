﻿using System;

namespace ConsoleApplication12
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = Console.ReadLine().Split(' ');
            int n = int.Parse(str[0])+1;
            int m = int.Parse(str[1]);
            int x = int.Parse(str[2]);

            int ans = n * m / x;
            if (n * m % x != 0) ans++;
            Console.WriteLine(ans);
            Console.ReadLine();
        }
    }
}
