#include <iostream>

using namespace std;

int main()
{
    int n, m, x;
    cin >> n >> m >> x;
    n++;
    cout << (n * m + x - 1) / x <<endl;
    return 0;
}
