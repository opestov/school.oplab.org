#include <iostream>

using namespace std;

int main()
{
    int n, k;
    cin >> n >> k;
    int active = 0;
    int t = 0;
    int c = 0;
    while (k > c) {
        c += active + 1;
        if (active < n-1) {
            c += (t-1)/2-1;
        }
        t++;
        active += (t+1)/2 - 1;
        if (active > n-1) active = n-1;
    }
    cout << t-1 << endl;
    return 0;
}
