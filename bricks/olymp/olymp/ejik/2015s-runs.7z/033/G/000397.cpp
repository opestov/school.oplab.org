#include <iostream>

using namespace std;

int main()
{
    int n, k;
    cin >> n >> k;
    int mas[n];
    int minn = 1000000001, maxx = 0, maxx2 = 1;
    int mx, mn, mx2;
    for (int i = 0; i < n; i++) {
        cin >> mas[i];
        if (maxx < mas[i]) {
            mx = i;
            maxx = mas[i];
        }
        if (minn > mas[i]) {
            mn = i;
            minn = mas[i];
        }
        if (maxx2 < mas[i] && maxx > mas[i]) {
            maxx2 = mas[i];
            mx2 = i;
        }
    }
    if (n == 1) {
        cout << '0' << endl;
        return 0;
    }
    if (k == n + 1) {
        cout << maxx - minn << endl;
    }
    if (k == n + 2) {
        cout << maxx2 - minn << endl;
    }
    return 0;
}
