n=int(input())
a=list(map(int,input().split()))
if n==1:
    print(1)
    print(1)
else:
    if sum(a)%2==0:
        print(sum(a))
        for i in range(sum(a)//2):
            print(1, 2, sep=' ', end=' ')
    else:
        print(sum(a)+1)
        for i in range(sum(a)//2):
            print(1, 2, sep=' ', end=' ')
        print(1)