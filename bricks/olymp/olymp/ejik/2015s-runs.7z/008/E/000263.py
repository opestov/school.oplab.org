n=int(input())
a=list(map(int,input().split()))
if n==1:
    print(1)
    print(1)
else:
    if a[0]==a[1]:
        print(sum(a))
        for i in range(sum(a)//2):
            print(1, 2, sep=' ', end=' ')
    else:
        print(min(a)*2+1)
        for i in range((min(a)*2)//2):
            print(1, 2, sep=' ', end=' ')
        print(1)