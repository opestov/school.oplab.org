n=int(input())
a=list(map(int,input().split()))
if n==1:
    print(1)
    print(1)
else:
    if a[0]==a[1] and a[0]!=1 and a[1]!=1:
        print(sum(a))
        for i in range(sum(a)//2):
            print(1, 2, sep=' ', end=' ')
    elif a[0]==1 or a[1]==1 and a[0]!=a[1]:
        print(3)
        if a[0]==1:
            print(2,1,2,sep=' ')
        if a[1]==1:
            print(1,2,1,sep=' ')
    else:
        print(min(a)*2+1)
        for i in range((min(a)*2)//2):
            print(1, 2, sep=' ', end=' ')
        print(1)