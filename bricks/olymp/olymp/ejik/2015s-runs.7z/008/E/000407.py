n=int(input())
a=list(map(int,input().split()))
if n==1:
    print (1)
    print (1)
elif n==2:
    if a[0]>a[1]:
        k=a[1]
        print (a[1]*2+1)
        while k!=0:
            print (1,2 , sep=" ",end=" ")
            k-=1
        print (1)
    else :
        k=a[0]
        print (a[0]*2+1)
        while k!=0:
            print (2,1, sep=" ",end=" ")
            k-=1
        print (2)
            
    
        
    