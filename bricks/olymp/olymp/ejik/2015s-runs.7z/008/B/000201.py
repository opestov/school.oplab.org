n=int(input())
zav=0
pac=0
ost=0
l=0
if n>=1:
    pac=n/2
    zav=zav+n
    if pac//1>=1:
        l=(pac//1)/2
        zav=zav+pac//1+l
        ost=l%2+pac%1
    if ost>=1:
        zav=zav+ost//1
        ost=ost/2
print(int(zav))
    