n,m,x=map(int, input().split())
n=n+1
if (n*m)%x!=0:
    print((n*m)//x+1)
else:
    print((n*m)//x)