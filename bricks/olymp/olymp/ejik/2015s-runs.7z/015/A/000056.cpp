#include <iostream>
#include <cmath>

using namespace std;

int main() {
	int n, m, x;

	cin >> n >> m >> x;

	cout << ceil((n * m) / x + 0.5);

	return 0;
}