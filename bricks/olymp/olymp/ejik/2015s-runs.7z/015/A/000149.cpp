#include <iostream>
#include <cmath>

using namespace std;

int main() {
	int n, m, x;

	cin >> n >> m >> x;

	cout << ceilf(((n + 1.0) * m) / (double)x);

	return 0;
}