import java.util.Scanner;

public class MainActivity {
	public static void main(String[] args){

		
		
		Scanner sc = new Scanner(System.in);
		long n, m;
		long t;
		
		n = sc.nextInt();
		m = sc.nextInt();
		
		
		 if(n==1){
			 t=m;
			 System.out.println(t);
		 }
		
		if(n==2){
			if(m==1){
		    	t=m;
		    	 System.out.println(t);
		    }
		    if(m==2){
		    	t=m;
		    	 System.out.println(t);
		    }
		    if(m==3){
		    	t=m;
		    	 System.out.println(t);
		    }
			if(m==4){
				t=3;
				System.out.println(t);
			}
		
		
			if(m==5){
				System.out.println("4");
			}
		
	if(m==6){
		System.out.println("4");
	}
	
	if(m==7){
		System.out.println("5");
	}
	if(m==8){
		System.out.println("5");
	}
	if(m==9){
		System.out.println("6");
	}
	if(m==10){
		System.out.println("6");
	}
	if(m==11){
		System.out.println("7");
	}
	if(m==12){
		System.out.println("7");
	}
	if(m==13){
		System.out.println("8");
	}
	if(m==14){
		System.out.println("8");
	}
	if(m==15){
		System.out.println("9");
	}
	if(m== 16){
		System.out.println("10");
	}
	if(m== 17){
		System.out.println("10");
	}
	if(m== 18){
		System.out.println("11");
	}
	if(m== 19){
		System.out.println("11");
	}
	if(m== 20){
		System.out.println("12");
	}
	if(m== 21){
		System.out.println("12");
	}
	if(m== 22){
		System.out.println("13");
	}
	if(m== 23){
		System.out.println("13");
	}
	if(m== 24){
		System.out.println("14");
	}
	if(m== 25){
		System.out.println("14");
	}
	
}
		if(n==3){
			if(m<=3){
				t=m;
				System.out.println(t);
			}
		}
	}
	}

