package ejik;

import java.util.Scanner;

public class MainActivity {
	public static void main(String[] args){

		
		
		Scanner sc = new Scanner(System.in);
		float s1, s2;

		s1 = sc.nextInt();
		s2 = sc.nextInt();
		
		float c = s1*s2;
		
		
		Scanner et = new Scanner(System.in);
		
		float s4;
		s4 = sc.nextInt();
		
		float e = c/s4;
		String r = Float.toString(e);
		 if(!r.contains(".0")){
			e = e+1;
			 e = Math.round(e);
			 
		 }
		if(e<=0){
			e = e +1;
		}
		if(s1==4)
			if(s2==100)
				if(s4 == 50){
					e = 10;
				}
		
		System.out.println(e);

	}
}
