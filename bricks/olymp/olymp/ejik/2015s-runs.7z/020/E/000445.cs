﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] tea = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            if (n == 1)
            {
                Console.WriteLine(1);
                Console.WriteLine(1);
            }
            if (n == 2)
            {
                if (tea[0] == tea[1])
                {
                    Console.WriteLine(Math.Min(tea[0], tea[1]) * 2);
                    for (int i = 0; i < n; i++)
                        Console.Write("1 2 ");
                }
                if (tea[0] > tea[1])
                {
                    Console.WriteLine(Math.Min(tea[0], tea[1]) * 2 + 1);
                    for (int i = 0; i < Math.Min(tea[0], tea[1]); i++)
                        Console.Write("1 2 ");
                    Console.Write('1');
                }
                if (tea[0] < tea[1])
                {
                    Console.WriteLine(Math.Min(tea[0], tea[1]) * 2 + 1);
                    Console.Write("2 ");
                    for (int i = 0; i < Math.Min(tea[0], tea[1]); i++)
                        Console.Write("1 2 ");
                }
            }
        }
    }
}