﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] sa = Console.ReadLine().Split().Select(x1 => int.Parse(x1)).ToArray();
            int h = sa[0], w = sa[1];
            string[] a=new string[h];
            for (int i = 0; i < h; i++)
            {
                a[i] = Console.ReadLine();
            }
            int ans = 0;
            int x = 0, y = h-1;
            while (true)
            {
                ans++;
                if (a[y][x] == '>')
                    x++;
                else
                if (a[y][x] == '<')
                    x--;
                else
                if (a[y][x] == '^')
                    y--;
                else
                if (a[y][x] == 'v')
                    y++;
                
                if(x<0||y<0||x>=w||y>=h){
                    Console.WriteLine(-1);
                    return;
                }
                if (x == w - 1 && y == 0)
                    break;
            }
                Console.WriteLine(ans);
        }
    }
}/*
3 4
>>>.
>^<v
^>^v
*/