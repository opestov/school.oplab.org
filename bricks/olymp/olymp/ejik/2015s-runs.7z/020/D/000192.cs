﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main1()
        {
            int n = int.Parse(Console.ReadLine());
            double m = n;
            int ans = 0;
            while (m>1)
            {
                ans += (int)Math.Floor(Math.Floor(m)/2.0);
                m = Math.Floor(m) / 2.0 + (m - Math.Floor(m));
            }
        }
        static void Main(string[] args)
        {
            string[] s = Console.ReadLine().Split();
            int h = int.Parse(s[0]);
            int w = int.Parse(s[1]);
            int[] r=new int[w*h];
            int i = -1;
            string s1;
            for (int i1 = 0; i1 < h; i1++)
            {
                s1 = Console.ReadLine();
                for (int i2 = 0; i2 < w; i2++)
                {
                    i++;
                    r[i] = -1;
                    if ((s1[i2] == '>') && (i2 % w!=w-1)) r[i]=i+1;
                    if ((s1[i2] == '<') && (i2 % w != 0)) r[i]=i-1;
                    if ((s1[i2] == '^') && (i >= w)) r[i]=i - w;
                    if ((s1[i2] == 'v') && (i < w * (h - 1))) r[i]=i+w;
                }
            }

            var q=new int[w*h*2];
            int had = 0;
            q[0] = w * (h - 1);
            while((q[had]!=w-1)&&(r[q[had]]!=-1))
            {
                if (had > q.Length || had >= q.Length || q[had] >= r.Length)
                {
                    Console.WriteLine(-1);
                    return;
                }
                q[had + 1] = r[q[had]];
                had++;
            }
            if((had!=0)&&(q[had]==w-1)) Console.WriteLine(had);
            else Console.WriteLine(-1);
        }
    }
}
