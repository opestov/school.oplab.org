n=int(input())
s=0
while n>0.1:
    s=n+s
    n=n/2
print(int(s))
