n, m = map(int, input().split()) 
a = [0] * n
b=0
e=0
if n == 1:
    e=m
else:
    if n==2:
        while b<m:
            a[0]=a[0]+1
            e=e+1
            if a[0]>=3:
                a[1]=a[1]+1
                b=a[0]+a[1]
    else:
        while b < m :
            a[0]=a[0]+1
            e=e+1    
            if a[0]>= 3:
                a[1]=a[1]+1
                if a[0]>= 4:
                    a[2]=a[2]+1
                    b = a[0]+a[1]+a[2]
print(e)