a,b,x=map(int,input().split())
a=a+1
s=0
s=a*b/x
if a*b%x>0:
    s=s+1
print(s)