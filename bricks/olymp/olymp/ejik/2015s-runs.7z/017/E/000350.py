n=int(input())
s=0
if n==1 :
    a=int(input())
    print('1')
    print('1')
elif n==2:
    a,b=map(int,input().split())
    if a>b :
        print(min(a,b)*2+1)
        for i in range(b):
            print('1 2',end=' ')
        print('1')
    if a==b:
        print(min(a,b)*2)
        for i in range(b):
            print('1 2', end=' ')
    if a<b:
        print(min(a,b)*2+1)
        for i in range(a):
            print('2 1' ,end =' ')
        print('2')
elif n==3:
    a,b,c=map(int,input().split())
    if a==b and a==c:
        print(c)
        for i in range(c):
            print('1 2 3',end= ' ')
    if a>b and b>c :
        print(3*c+3*(b-c)+1)
        for i in range(c):
            print('1 2 3', end=' ')
        for i in range(b-c):
            print('1 2',end=' ')
        print('1')
    if a>b and c>b and a>c:
        print(3*b+2*(c-b)+1)
        for i in range(b):
            print('1 3 2', end=' ')
        for i in range(c-b):
            print('1 3' , end=' ')
        print('1')
else:
    z=list(map(int,input().split()))
    print(3*z[1])
    for i in range(z[1]):
        for i in range(1,n+1):
            print(i,end=' ')
    
        
        
        
    