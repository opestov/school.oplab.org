n=int(input())
s=0
if n==1 :
    a=int(input())
    print('1')
    print('1')
if n==2:
    a,b=map(int,input().split())
    if a>b :
        print(min(a,b)*2+1)
        for i in range(b):
            print('1 2',end=' ')
        print('1')
    if a==b:
        print(min(a,b)*2)
        for i in range(b):
            print('1 2', end=' ')
    if a<b:
        print(min(a,b)*2+1)
        for i in range(a):
            print('2 1' ,end =' ')
        print('2')