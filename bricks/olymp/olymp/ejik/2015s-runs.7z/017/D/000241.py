h,w=map(int,input().split())
q=0
u=0
p=0
b=[[0]*w for i in range(h)]
a=[[0]*w for i in range(h)]
for i in range(h):
    q=input()
    for j in range(w):
        a[i][j]=q[j]
i=h-1
j=0
l=i
m=j
for k in range(100000000):
    i=l
    j=m
    b[i][j]=b[i][j]+1
    
    if u==1:
        break
    if b[i][j]>1:
        u=1
    if a[i][j]=='>':
        if j==w-1:
            u=1
        m=m+1
    if a[i][j]=='<': 
        if j==0:
            u=1
        m=m-1
    if a[i][j]=='^':
        if i==0:
            u=1
        l=l-1
    if a[i][j]=='v':       
        if i==h-1:
            u=1
        l=l+1
    p=p+1
        
        
    if u==1:
        print(-1)
        break
    if a[i][j]=='.':
        print(p-1)
        u=1
        break

        
    
        
        
    
      
      
      
      
      
        