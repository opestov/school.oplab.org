ClistCtrl  *   lst=  (ClistCtrl*) GetDlgI tem(IDS_LIST_CONTROL) ;
lst->Inster tColumn(1,L"Имена"LVCFMT_LEFT,
lst->Inster tColumn(1,L"Даты рождения"LVCFMT_LEFT,
CListCtrl   *   lst=  (CListCtrl   *)GetDlgI tem(IDS_LIST_CONTROL) ;
lst->InstertItem(0,L" ");
lst->SetItemText(0,  0,"Дима,1997")
lst->SetItemText(0,  1,"Вася,1996")
lst->SetItemText(0,  2,"Наталия,1997")
lst->SetItemText(0,  3,"Катя,1997")
lst->SetItemText(0,  4,"Рома,1996")