n,m = input().split(' ')
n = int(n); m = int(m)
l = [None]*n
i = 0
s = input().split(' ')
while i < n:
     l[i] = int(s[i])
     i+=1
if sum(l)!= 100:
    print('It is a fake!')
else:
    i = 0
    for l[i] in l:
        if (m*l[i] / 100)%1 != 0:
            print('It is a fake!')
            break
        else:
            print('Violations were not found.')
            break
