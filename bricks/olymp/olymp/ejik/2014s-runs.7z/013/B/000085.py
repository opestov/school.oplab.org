N = int(input())
if N % 2 != 0:
    l = [None]*N
    i = 0
    while i < N:
        l[i] = input()
        i += 1
    print('Nobody')
else:
    l = [None]*N
    i = 0
    while i < N:
        l[i] = input()
        i += 1
    ind = l.index('Lesha')
    if ind <= len(l)/2:
        print(l[ind + int(N/2)])
    else:
        print(l[ind - int(N/2)])
