r,w,h = input().split(' ')
int(r); int(w); int(h)
if r*2 < w or r*2 < h:
    print('No')
else:
    print('Yes')
