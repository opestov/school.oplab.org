﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var str = Console.ReadLine();
            var result= str.Split(new []{' '});
            int R =Convert.ToInt16(result[0]);
            int W =Convert.ToInt16(result[1]);
            int H = Convert.ToInt16(result[2]);
            if (R * 2 < W || R * 2 < H)
                Console.WriteLine("No");
            else
                Console.WriteLine("Yes");
            Console.ReadKey();
        }
    }
}
