R,W,H = input().split(' ')
int(R); int(W); int(H)
if R*2 < W or R*2 < H:
    print('No')
else:
    print('Yes')
