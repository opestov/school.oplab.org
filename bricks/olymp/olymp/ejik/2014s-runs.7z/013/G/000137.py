n = int(input())
i = 0
count = 0
while i < n:
    s = input()
    if s == 'ejik':
        count+=2
    i += 1
print(count)
