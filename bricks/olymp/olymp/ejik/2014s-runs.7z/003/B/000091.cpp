Var s:array [1..100] of String;
n,i:integer;
x:string;
Begin
Readln(n);
For i:=1 to n do
 Readln(s[i]);
x:=s[1];
While s[1]<>'Lesha' do
 Begin
  For i:=1 to n do s[i]:=s[i+1];
  s[n]:=x;
 End;
If n mod 2=0 then writeln(s[n div 2+1])
 Else writeln('Nobody');
End.
