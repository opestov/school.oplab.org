#include <iostream>

using namespace std;

int main()
{
    int mens;
    cin >> mens;
    int mini[mens];
    int maxi[mens];
    for (int i = 0; i < mens; i++)
    {
        cin >> mini[i] >> maxi[i];
    }
    int sr[mens];
    for (int i = 0; i < mens; i++)
    {
        sr[i] = (mini[i] + maxi[i]) / 2;
        //cout << mini[i] << " " << maxi[i] <<  " " << sr[i] << endl;
    }
    int sum = 0;
    for (int i = 0; i < mens; i++)
    {
        sum = sr[i] + sum;
    }
    sum /= mens;
    cout << sum << endl;
    return 0;
}
