#include <iostream>

using namespace std;

int main()
{
    int N;
    cin >> N;
    char T[N][N];
    for (int i = 0; i < N; i++)
    {
        for (int a = 0; a < N; a++)
        {
            cin >> T[i][a];
        }
    }
    int toch = 0;
    for (int i = 0; i < N; i++)
    {
        for (int a = 0; a < N; a++)
        {
            /*if ((T[i][a] == 'e' && T[i - 1][a] == 'j' && T[i - 2][a] == 'i' && T[i - 3][a] == 'k') ||
             (T[i][a] == 'e' && T[i - 1][a] == 'j' && T[i - 2][a] == 'i' && T[i - 2][a - 1] == 'k') ||
             (T[i][a] == 'e' && T[i - 1][a] == 'j' && T[i - 2][a] == 'i' && T[i - 2][a + 1] == 'k') ||
             (T[i][a] == 'e' && T[i + 1][a] == 'j' && T[i + 2][a] == 'i' && T[i + 3][a] == 'k') ||
             (T[i][a] == 'e' && T[i + 1][a] == 'j' && T[i + 2][a] == 'i' && T[i + 2][a + 1] == 'k') ||
             (T[i][a] == 'e' && T[i + 1][a] == 'j' && T[i + 2][a] == 'i' && T[i + 2][a - 1] == 'k') ||
             (T[i][a] == 'e' && T[i][a + 1] == 'j' && T[i][a + 2] == 'i' && T[i][a + 3] == 'k') ||
             (T[i][a] == 'e' && T[i][a + 1] == 'j' && T[i][a + 2] == 'i' && T[i - 1][a + 2] == 'k') ||
             (T[i][a] == 'e' && T[i][a + 1] == 'j' && T[i][a + 2] == 'i' && T[i + 1][a + 2] == 'k') ||
             (T[i][a] == 'e' && T[i][a - 1] == 'j' && T[i][a - 2] == 'i' && T[i][a - 3] == 'k') ||
             (T[i][a] == 'e' && T[i][a - 1] == 'j' && T[i][a - 2] == 'i' && T[i - 1][a - 2] == 'k') ||
             (T[i][a] == 'e' && T[i][a - 1] == 'j' && T[i][a - 2] == 'i' && T[i + 1][a - 2] == 'k')) toch++;*/
             if (T[i][a] == 'e')
             {
                 toch++;
             }
        }
    }
    toch *= 2;
    cout << toch << endl;
    return 0;
}
