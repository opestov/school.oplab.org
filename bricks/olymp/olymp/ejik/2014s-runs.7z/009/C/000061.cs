﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {











            string[] i = Console.ReadLine().Split(' ');
            string[] i2 = Console.ReadLine().Split(' ');

            int kon = Convert.ToInt32(i[0]);
            
            int xe = 0;
            if (!(kon < Convert.ToInt32(i[1])))
            {
                Console.WriteLine("It is a fake!");
               
            }
            else
            {
                int d =0;
                while (kon > d)
                {
                    xe = xe + Convert.ToInt32(i2[d]);
                    d++;
                }
                if (!(xe == 100))
                {
                    Console.WriteLine("It is a fake!");
                }
                else
                {
                    Console.WriteLine("Violations were not found");
                }
              
            }
          
            

            
         
         
        }
    }
}
