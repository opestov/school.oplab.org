﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.ReadLine());
            string[] kk = "".Split(); 
            
            
          string[] ko = "".Split();
            if (!(a % 2 == 0))
            {
                Console.WriteLine("Nobody");
            }
            else
            {






                Console.WriteLine("Egor");
                    
                  
                    
                    
                
                    

                
        
              
                
                   

                
            }


          
            

            
         
         
        }
    }
}
