﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {











            string i = Console.ReadLine();
            string[] i2 = Console.ReadLine().Split(' ');
            if (Convert.ToInt32(i) == Convert.ToInt32(i2[0]))
            {
                Console.WriteLine(i2[0]);
            }
            else
            {
                int xoxo = 0;
                for (int z = 0; z< Convert.ToInt32(i);z++)
                {

                xoxo = xoxo + Convert.ToInt32(i2[z]);
            }
                int i3 = Convert.ToInt32(i);
                int i4 = Convert.ToInt32(i2[0]) + Convert.ToInt32(i2[i3-1]);
                 int i5 = Convert.ToInt32(i2[1]) + Convert.ToInt32(i2[i3-2]);
                 if (i5 <= i4)
                 {
                     int rez = xoxo / 2;
                     Console.WriteLine(rez);
                    
                 }
                 else
                 {
                     int rez = xoxo / 3;
                     Console.WriteLine(rez);
                     
                 }
            }



                    
                
              
            
          
            

            
         
         
        }
    }
}
