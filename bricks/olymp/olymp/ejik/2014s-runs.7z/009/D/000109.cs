﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {











            string i = Console.ReadLine();
            Console.WriteLine("200");
           
           
           
                
            



            
               
             
         
         
            



                    
                
              
            
          
            

            
         
         
        }
    }
}
