﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] a = Console.ReadLine().Split(' ');
            int r = Convert.ToInt32(a[0]);
            int w = Convert.ToInt32(a[1]);
            int h = Convert.ToInt32(a[2]);
            int dia = r * 2;
            if (dia <= w)
            {
                if (dia <= h)
                {
                    Console.WriteLine("Yes");
                }
                else
                {
                    Console.WriteLine("No");
                }
            }
            else
            {
                Console.WriteLine("No");
            }
            
            

            
         
         
        }
    }
}
