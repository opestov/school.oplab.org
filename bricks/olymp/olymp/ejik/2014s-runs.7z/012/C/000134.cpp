#include <iostream>
#include <string>
#include <time.h>
#include <cstdlib>
using namespace std;

int main()
{



	int j;
	cin >> j;
	int h[j];
	int sum(0);
for(int i(1);i <= j;i++)
{

cin >> h[i];
sum = sum + h[i];
}


if(sum == 100)
{

cout << "Violations were not found";
}
else{
cout << "It is a fake!";
}




    return 0;
}
