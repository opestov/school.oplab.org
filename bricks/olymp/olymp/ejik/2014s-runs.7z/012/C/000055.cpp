#include <iostream>
#include <string>


using namespace std;



int main(){







		int i;
		cin >> i;
		int u;
		cin >> u;
int l;
	int a[i-1];
for(int k(0);k <=i-1; k++)
{
cin >> a[k];
}
	for(int j(0);j <= i-1; j++){



	l = l + a[j];


	if(l == 100){


	}


    }



	if(l > 100){

        cout << "It is a fake!";
        return 0;
	}
	if(l < 100)
    {
   cout << "It is a fake!";
   return 0;
    }




		return 0;

	}








