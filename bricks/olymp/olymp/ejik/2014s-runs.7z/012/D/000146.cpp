#include <iostream>
#include <string>
#include <random>
#include <time.h>
using namespace std;

int main()
{


	int j;
int k;
int h[k];
for(int i(1);i < k;i++)
{
cin >> h[i];
}

for(int i(1);i < k;i++)
{

if(h[i] < h[i+1]
{
if(h[i] == h[i+1]){
        cout << h[i];
}
}


}

int a;
cin >> a;
int j1[a];
int j2[a];
int j3[a];
for(int i(1);i<= a;i++)
{
    cin >> j1[i];



}



for(int i(1);i<= a;i++)
{
    cin >> j2[i];

	
}
for(int i(0);i <= a;i++){


    j3[i] = j2[i] - j1[i];

if(j3[i] <j3[i+1])
{
	int k = rund()% j3[i];
	j3[i] = k + j3[i];
	cout << j3[i];
	
}

}


    return 0;
}

