#include <iostream>
#include <string>
#include <time.h>
#include <cstdlib>
using namespace std;

int main()
{
srand(time(NULL));



int a;
cin >> a;
int j1[a];
int j2[a];
int j3[a];
for(int i(1);i<= a;i++)
{
    cin >> j1[i];



}



for(int i(1);i<= a;i++)
{
    cin >> j2[i];


}
for(int i(1);i <= a;i++){






    j3[i] = j2[i] - j1[i];
    int h = j3[i];
	int k = rand()% h;
	int o;
    o = k + j3[i];
	cout << "1" << o;

}




    return 0;
}
