#include <iostream>
#include <string>


using namespace std; 



int main(){

int N;
cin >> N;


for(int i(1);i <= N;i++){

string a;
cin >> a;
}
	
	if((N/2)*2 < N){

cout << "Nobody";
}

	



return 0;
}