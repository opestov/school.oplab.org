#include <iostream>
#include <string>


using namespace std; 



int main(){
	int R,W,H;
	cin >> R;
	cin >> W;
	cin >> H;
	

		
		
			R = 2*R;
		if(R <= W & R <= H){
		
		
		cout << "Yes";
		
		return -1;
			
			}
		
		
		
		
		
		
		
	cout << "No";	
		
	
	
	

	



return 0;
}