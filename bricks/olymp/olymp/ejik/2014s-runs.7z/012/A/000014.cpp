#include <iostream>
#include <conio.h>
#include <string>


using namespace std; 



int main(){
	int R,W,H;
	cin >> R;
	cin >> W;
	cin >> H;
	

		if(50 <= W, W <= 10000){
		if(50 <= R, R <= 10000){
		if(50 <= H, H <= 10000){
		{
			R = 2*R;
		if(R <= W & R <= H){
		
		
		cout << "Yes";
		_getch();
		return -1;
			}
			}
		
		}
		}
		
		
		}
		
	cout << "No";	
		
	
	
	

	


	
_getch();
return 0;
}