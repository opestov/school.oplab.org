#include <iostream>
#include <string>
#include <time.h>
#include <cstdlib>
using namespace std;

int main()
{
int i;
cin >> i;
char a1[15];
char a2[15];
char a3[15];
char a4[15];
cin >> a1,a2,a3,a4;
cout << "4";



    return 0;
}
