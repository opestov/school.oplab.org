#include <iostream>
using namespace std;
int main(){
	int u, s, g;
	cin >> u >> s >> g;
	int m[s+1];
	for(int i=0; i<=s; i++)
		m[i]=0;

	for(int i=0, a, b; i<g; i++){
		cin >> a >> b;
		for(;a<=b; a++)
			m[a]=1;
	}

	/*for(int i=1; i<=s; i++)
		cout << m[i];*/

	int mid = s/2;
	int l=mid-s%2, r=mid+s%2;
	if(s%2==0)
		r++;

	if(m[mid]==0){
		u--;
		m[mid]=1;
		if(u==0){
			cout << mid<< endl;
			return 0;
		}
	}

	for(int i=0; u>0;i++){
		if(l-i>0 && m[l-i]==0){
			u--;
			m[l-i]=1;
			if(u==0){
				cout << l-i<< endl;
				return 0;
			}
		}else
		if(r+i<s && m[r+i]==0){
			u--;
			m[i+r]=1;
			if(u==0){
				cout << r+i<< endl;
				return 0;
			}
		}
	}

	//cout<<"er"<<endl;
	return 0;
}