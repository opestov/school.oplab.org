#include <iostream>
using namespace std;
int an[100001]={0};

void pls(int a, int b){
	for(; a<=b; a++)
		an[a]++;
}
int main(){
	int n, a, b;
	cin >> n;
	for (int i=0; i<n; i++){
		cin >> a >> b;
		pls(a, b);
	}
	int ans=0, max=0;
	for(int i=0; i<100001; ++i){
		if(an[i]>=max){
			max =an[i];
			ans =i;
		}
	}
	cout << ans << endl;
	return 0;
}