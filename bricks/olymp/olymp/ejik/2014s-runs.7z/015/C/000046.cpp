#include <iostream>
using namespace std;
int main(){
	long long n, m, d,s=0, t;
	cin >> n >> m;
	//cout << 3*100/75;
	for(int i=0; i<n; i++)
	{
		cin >> d;
		s+=d;
		if(d>0){
			t=m*d/100;
			if(m!=t*100/d){
				cout << "It is a fake!" << endl;
				return 0;
			}
		}	
		if(s>100){
				cout << "It is a fake!"<<endl;
				return 0;
			}
	}
	if(s==100)
	cout << "Violations were not found.";
	else{
		cout << "It is a fake!"<<endl;
				return 0;
	}
	return 0;
}