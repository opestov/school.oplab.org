#include <iostream>
using namespace std;
int main(){
	int r, w, h, d;
	cin >> r >> w >> h;
	d=2*r;
	if(d>w||d>h){
		cout << "NO"<<endl;
	}else 
	cout << "YES"<<endl;

	
	return 0;
}