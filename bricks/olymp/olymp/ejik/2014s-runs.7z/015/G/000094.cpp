#include <iostream>
using namespace std;
int ans=0;
char f[101][101];
char ej[4]={'e', 'j', 'i','k'};
int x[4]={0, 1, 0,-1};
int y[4]={1, 0,-1, 0};
int n;
int check(int i, int j, int k){
	
	//cout << ej[k] << endl;
	if(f[i][j]==ej[k])
		for(int w=0; w<4; w++)
			if(i+x[w]<n && j+y[w]<n){
				if(k==3){
					return 1;
				}
				if(check(i+x[w], j+y[w], k+1)==1)
					return 1;	
		}
	return 0;
}

int main(){
	//int n;
	cin >> n;
	char c;
	for(int i=0; i<n; i++)
		for(int j=0; j<n; ++j){
			cin >> c;
			f[i][j]=c;
		
		}
		
	
	for(int i=0; i<n; i++)
		for(int j=0; j<n; ++j){
			if(f[i][j]=='e'){
				for(int w=0; w<4; w++)
					if(i+x[w]<n && j+y[w]<n)
						if(check(i+x[w], j+y[w], 1)==1){
							ans++;
							break;
						}
				//f[i][j]='e';
			}
		}
	cout << 2*ans << endl;	
	return 0;
}