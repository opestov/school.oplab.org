import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());
		//sc.next();
		if (n % 2 == 1) {
			System.out.println("Nobody");
		} else {
			String[] guests = new String[n + n + 1];
			String s;
			for (int i = 0; i < n; i++) {
				s = sc.nextLine();
				//System.out.println(s);
				guests[i] = s;
				guests[i + n] = s;
			}
			for (int i = 0; i < n; i++) {
				if (guests[i].equals("Lesha")) {
					System.out.println(guests[i + n / 2]);
				}

			}
		}
	}
}
