#include <iostream>
using namespace std;
int main(){
	
	cout << 3 <<endl;

	
	return 0;
}