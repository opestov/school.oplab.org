#include <iostream>

int main()
{
	unsigned long int result;
	unsigned long int peoples_buy;
	unsigned long int * const amount_mest = new unsigned long int;
	unsigned long int amount_groups;
	std::cin >> peoples_buy >> *amount_mest >> amount_groups;
	bool mesta[*amount_mest];
	unsigned long int center;
	if(*amount_mest % 2)
		center = *amount_mest/2;
	else
		center = (*amount_mest+1)/2;
	
	for(int i = 0; i < *amount_mest; i++)
	{
		mesta[i] = 0;
	}
	
	for(unsigned long int i = 0; i < amount_groups; i++)
	{
		unsigned long int a1, a2;
		std::cin >> a1 >> a2;
		for(unsigned long int i2 = a1;  i2 <= a2; i2++)
		{
				mesta[i2-1] = true;
		}				
	}
	
	for(unsigned long int i = 0; i < peoples_buy; i++)
	{
		unsigned long int res1;
		for(unsigned long int i2 = center; i2 <= *amount_mest; i2++)
		{
			if(!mesta[i2-1])
			{
				res1 = i2;
				break;
			}   	
		}
		unsigned long int res2;
		for(unsigned long int i2 = center; i2 >= 1; i2--)
		{
			if(!mesta[i2-1])
			{
				
				res2 = i2;
				break;
			}
		}
		if(res1 - center <= center - res2)
			mesta[res1-1] = true;
		else
			mesta[res2-1] = true;
		result = res1;
	}
	std::cout << result;

	return 0;
}
