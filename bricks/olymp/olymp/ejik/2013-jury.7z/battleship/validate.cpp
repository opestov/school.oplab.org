#include "testlib.h"

using namespace std;

string a[1000];

int main()
{
    registerValidation();
    
    int w = inf.readInt(1, 1000); inf.readSpace();
    int h = inf.readInt(1, 1000); inf.readEoln();

    // read and check length
    for (int i = 0; i < h; ++i) {
      a[i] = inf.readString();
      ensure(a[i].size() == w);
    }

    for (int i = 0; i < h; ++i)
      for (int j = 0; j < w; ++j)
        if (a[i][j] == '#') {
          if (i && j) ensure(a[i - 1][j - 1] != '#');
          if (i && j < w - 1) ensure(a[i - 1][j + 1] != '#');
        }

    return 0;
}
