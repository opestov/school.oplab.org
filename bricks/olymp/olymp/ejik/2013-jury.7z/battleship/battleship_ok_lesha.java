import java.io.PrintWriter;
import java.util.Scanner;


public class battleship_ok_lesha {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		int m = in.nextInt();
		int n = in.nextInt();
		int ans = 0;
		for (int i = 0;i<n;i++){
			String s = in.next();
			for (int j = 0;j<s.length();j++){
				if (s.charAt(j) =='#') ans++;
			}
		}
		out.print(ans);
		out.flush();
	}

}
