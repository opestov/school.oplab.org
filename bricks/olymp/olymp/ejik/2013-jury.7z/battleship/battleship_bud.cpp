#include <cstdio>
#include <iostream>

using namespace std;

int h, w;
string s;

int main() {
    cin >> w >> h;

    int ans = 0;
    for (int i = 0; i < h; ++i) {
        cin >> s;
        for (int j = 0; j < w; ++j) {
            if (s[j] == '#') {
                ++ans;
            }
        }
    }

    cout << ans;
    
    return 0;
}