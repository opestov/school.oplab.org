#include <stdio.h>

int main() {
  int w, h, k = 0;
  char s[1001];

  scanf("%d%d\n", &w, &h);
  for (int i = 0; i < h; ++i) {
    gets(s);
    for (int j = 0; j < w; ++j)
      if (s[j] == '#')
        ++k;    
  }
  printf("%d\n", k);
}