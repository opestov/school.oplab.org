import random
random.seed(150895)

for i in range(1, 21):
    outp = open("0" * (2 - len(str(i))) + str(i), "w")
    #ansp = open("0" * (2 - len(str(i))) + str(i) + ".a", "w")
    if (i == 1):
        a = [5,18,3,6];
    if (i == 2):
        a = [1,28,8,16];
    if (i == 3):
        a = [1,2,2,3];
    if (i == 4):
        a = [1,1000,998,999];
    if (i == 5):
        a = [99,990,11,110];
    if (i in range(5,11)):
        n = random.randint(10,100)
        m = random.randint(10,100)
        a = [random.randint(1,n-1),n,random.randint(1,m-1),m]
    if (i in  range(11,21)):
        n = random.randint(800,1000)
        m = random.randint(800,1000)
        a = [random.randint(1,n-1),n,random.randint(1,m-1),m]
    outp.write(str(a[0]) + " " + str(a[1])+"\n")
    outp.write(str(a[2]) + " " + str(a[3]))
    #ansp.write(str(b - a))