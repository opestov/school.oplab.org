#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

int a, b, n, m;

int main() {
    cin >> a >> n >> b >> m;

    int rans = 1000000000;
    int nump = 10000;
    int memi, memj;
    for (int i = -n + a + 1; i <= m - b - 1; ++i) {
        for (int j = -a + 1; j <= b - 1; ++j) {
            //cout << i << " " << j << endl;
            if(rans > fabs((a + j) * (m - i - j) - (b - j) * (n + i + j))) {
                //cout << "@" << i << " " << j << endl;// << " " << fabs((a + j) / ((n + i) * 1.0) - (b - j) / ((m - i) * 1.0)) << endl;
                //cout << "@\n";
                nump = abs(i) + abs(j);
                rans = fabs((a + j) * (m - i - j) - (b - j) * (n + i + j));
                memi = i;
                memj = j;
            } else if (rans == fabs((a + j) * (m - i - j) - (b - j) * (n + i + j))) {
                //cout << "#" << i << " " << j << endl;
                nump = min(nump, abs(i) + abs(j));
                memi = i;
                memj = j;
            }
        }
    }

    cout << nump;// << " " << a + memj << " " << n + memi + memj << " " << b - memj << " " << m - memi - memj;

    return 0;
}