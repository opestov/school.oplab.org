#include "testlib.h"

using namespace std;


int main()
{
    registerValidation();
    
    int a = inf.readInt(1, 1000); inf.readSpace();
    int n = inf.readInt(a + 1, 1000); inf.readEoln();
    int b = inf.readInt(1, 1000); inf.readSpace();
    int m = inf.readInt(b + 1, 1000); inf.readEoln();
    inf.readEof();


    return 0;
}
