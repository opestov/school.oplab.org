// only in one direction
#include <stdio.h>

int main() {
  int g1, t1, g2, t2;
  scanf("%d%d%d%d", &g1, &t1, &g2, &t2);

  int bx = g1*t2-g2*t1;
  if (bx < 0) bx = -bx;
  int by = t1*t2;
  int aa = 0;

  for (int g = 0; g <= g1; ++g)
    for (int b = 0; b < t1-g1; ++b) {
      int x1 = g1-g, y1 = t1-g-b;
      int x2 = g2+g, y2 = t2+g+b;
      
      int xx = x1*y2-x2*y1;
      if (xx < 0) xx = -xx;
      int yy = y1*y2;
      if (bx*yy>by*xx || (bx*yy==by*xx && g+b<aa)) {
        bx = xx;
        by = yy;
        aa = g+b;
      }        
    }

  for (int g = 0; g <= g2; ++g)
    for (int b = 0; b < t2-g2; ++b) {
      int x1 = g1+g, y1 = t1+g+b;
      int x2 = g2-g, y2 = t2-g-b;
      
      int xx = x1*y2-x2*y1;
      if (xx < 0) xx = -xx;
      int yy = y1*y2;
      if (bx*yy>by*xx || (bx*yy==by*xx && g+b<aa)) {
        bx = xx;
        by = yy;
        aa = g+b;
      }        
    }

  printf("%d\n", aa);
  return 0;
}