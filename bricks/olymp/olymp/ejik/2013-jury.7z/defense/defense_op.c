#include <stdio.h>

int main() {
  int x, i;
  scanf("%d", &x);

  for (i = 1; i*i < x; ++i);

  if (i*i == x)
    printf("forforfor\n");
  else
    printf("%d\n", i*i-x);

  return 0;
}