#include <stdio.h>

int main() {
  printf("forforfor\n");
  return 0;
}