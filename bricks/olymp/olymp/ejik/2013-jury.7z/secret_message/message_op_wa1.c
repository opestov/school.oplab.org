#include <ctype.h>
#include <stdio.h>
#include <string.h>

int main() {
  printf("Yes\n");
  return 0;
}