#include "testlib.h"
#include <ctype.h>

using namespace std;

int main()
{
    registerValidation();
    
    string t = inf.readString();
    string p = inf.readString();

    ensure(t.size() <= 10000);
    ensure(p.size() <= 100);

    for (int i = 0; i < t.size(); ++i)
      ensure(t[i] >= 30 && t[i] <= 127);
    
    int a = 0;
    for (int i = 0; i < p.size(); ++i)
      if (isalpha(p[i]))
        ++a;
      else
        ensure(p[i] == ' ');
    ensure(a+1 == p.size());

    return 0;
}
