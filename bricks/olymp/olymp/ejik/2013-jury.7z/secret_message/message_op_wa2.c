#include <ctype.h>
#include <stdio.h>
#include <string.h>

int main() {
  printf("No\n");
  return 0;
}