al = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"
s = raw_input().strip()
a, b = raw_input().strip().split()
s += "~"

s1 = ""
s2 = ""

l = len(s)
truly = True
co = 0
for i in xrange(l):
    #print s
    if (not s[i - co] in al):
        mem = s1
        s1 = s2
        s2 = s[: i - co].lower()
        
        s = s[i - co:]
        co += i - co
        while (len(s) > 0 and not s[0] in al):
            s = s[1:]
            #co -= 1
        print (s2, s, co)
        if (s1 == a and s2 == b):
            #print ("Yes")
            truly = False
            break
    if (len(s) == 0):
        break


if (truly):
    print ("No")
         