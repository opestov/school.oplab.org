#include <ctype.h>
#include <stdio.h>
#include <string.h>

int main() {
  char t[10003], p[101];
  int n, m, flag = 1, i;
  
  gets(t + 1);
  gets(p + 1);

  t[0] = ' ';  
  for (n = 0, i = 0; t[i]; ++i)
    if (isalpha(t[i])) {
      t[n++] = tolower(t[i]);
      flag = 1;
    }
    else {
      if (flag) t[n++] = ' ';
      flag = 0;
    }
  if (t[n-1] != ' ')
    t[n++] = ' ';
  t[n] = 0;

  p[0] = ' ';  
  m = strlen(p);
  p[m++] = ' ';
  p[m] = 0;

  if (strstr(t, p) == NULL)
    printf("No\n");
  else
    printf("Yes\n");

  return 0;
}