#include <iostream>

using namespace std;

int n;

int main() {
    cin >> n;
    if (n % 2 == 0) {
        cout << "Yes";
    }
    else {
        cout << "No";
    }
    return 0;
}