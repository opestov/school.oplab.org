#include "testlib.h"

using namespace std;

int main()
{
    registerValidation();
    
    int n = inf.readInt(3, 10000); inf.readEoln();
    inf.readEof();
    return 0;
}
