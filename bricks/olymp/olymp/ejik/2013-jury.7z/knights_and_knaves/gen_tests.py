import random

mas = [100, 90, 95, 99, 1000, 986, 999, 785, 9998, 9562, 9832, 9973, 9753, 239, 10000]

for i in xrange(11, 26):
    outp = open("0" * (2 - len(str(i))) + str(i), "w")
    ansp = open("0" * (2 - len(str(i))) + str(i) + ".a", "w")
    #if (random.random() < 0.5):
    #    a -= 12
    #    b -= 12

    outp.write(str(mas[i - 11]))
    if (mas[i - 11] % 2 == 0):
        ansp.write("Yes")
    else:
        ansp.write("No")