#include <stdio.h>
#include <algorithm>

using namespace std;

int main() {	
  int n;
	scanf("%d", &n);

  int a[n];
  for (int i = 0; i < n; ++i)
    scanf("%d", &a[i]);
  sort(a, a+n);

  int r = 0;
  for (int i = 0, x = -1; i < n; ++i) {
    if (a[i] > x)
      x = a[i];
    else
      ++x;
    r += x;
  }
  printf("%d\n", r);
	return 0;
}