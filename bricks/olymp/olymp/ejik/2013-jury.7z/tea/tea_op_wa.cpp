// print sum
#include <stdio.h>
#include <algorithm>

using namespace std;

int main() {	
  int n, x, r = 0;
	scanf("%d", &n);
  for (int i = 0; i < n; ++i) {
    scanf("%d", &x);
    r += x;
  }
  printf("%d\n", r);
	return 0;
}