import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;


public class tea_ok_lesha {

  /**
   * @param args
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    Scanner in = new Scanner(System.in);
    PrintWriter out = new PrintWriter(System.out);
    int n = in.nextInt();
    int[] a = new int[n];
    for (int i = 0;i<n;i++){
      a[i] = in.nextInt();
    }
    Arrays.sort(a);
    for (int i = 0; i<n;i++){
      if ((i!=0)&&(a[i]<=a[i-1])) {
        a[i] = a[i-1] + 1;
      }
    }
    int ans = 0;
    for (int i = 0;i<n;i++){
      ans+=a[i];
    }
    out.print(ans);
    out.flush();
  }

}
