/*
	более умное решение
	(бинпоиск + дерево фенвика)
	за N * log^2(MAXN + MAXTHIRST)
*/

#include <stdio.h>

using namespace std;

const int MAXTHIRST = (int)1e6;
const int MAXN = (int)1e3;
const int MAXSIZE = MAXN + MAXTHIRST;

int t[MAXSIZE];

int n;

void incel(int a){
	for (int i = a; i < MAXSIZE; i += i & (-i))
		t[i]++;
	return;
}

int gs(int a) {
	int sum = 0;
	for (int i = a; i; i -= i & (-i))
		sum += t[i];
	return sum;
}

int getsum(int l, int r) {
	return gs(r) - gs(l - 1);
}

bool check(int l, int r) {
	if (r >= MAXSIZE)
		return false;
	return getsum(l, r) == r - l + 1;
}

int main() {
	int ans = 0;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int p;
		scanf("%d", &p);
		int m;
		if (getsum(p, p) == 0) {
			m = p;
		}
		else {
			int l = p, r = MAXSIZE;
			while (r - l > 1) {
				int mid = (l + r) / 2;
				if (check(p, mid))
					l = mid;
				else
					r = mid;
			}
			m = r;
		}
		incel(m);
		ans += m;
	}
	return 0;
}