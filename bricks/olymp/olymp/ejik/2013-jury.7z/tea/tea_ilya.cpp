/*
	решение "в лоб" за N^2
*/
#include <stdio.h>

using namespace std;

const int MAXTHIRST = (int)1e6;
const int MAXN = (int)1e3;

bool d[MAXTHIRST + MAXN];

int n;

int main() {
	int ans = 0;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int t;
		scanf("%d", &t);
		int m = t;
		while(d[m])
			m++;
		ans += m;
		d[m] = true;
	}
	printf("%d\n", ans);
	return 0;
}