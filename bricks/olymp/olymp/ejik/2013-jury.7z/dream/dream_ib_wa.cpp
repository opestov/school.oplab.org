#include <iostream>

using namespace std;

int l, r;

int main() {
    cin >> l >> r;
    //if (l < 12 && 12 < r) {
    //    cout << r - l - 1;
    //}
    //else {
        cout << r - l;
    //} 
    return 0;
}