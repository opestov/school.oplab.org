import random

for i in xrange(11, 17):
    outp = open("0" * (2 - len(str(i))) + str(i), "w")
    ansp = open("0" * (2 - len(str(i))) + str(i) + ".a", "w")
    a = random.randint(0, 12)
    b = random.randint(13, 23)
    #if (random.random() < 0.5):
    #    a -= 12
    #    b -= 12

    outp.write(str(a) + " " + str(b))
    #ansp.write(str(b - a))