#include <cstdio>
#include <iostream>

using namespace std;

int l, r, ans = 0;
double mas_time[22] = {0, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 10.5, 12, 13.5, 14.5, 15.5, 16.5, 17.5, 18.5, 19.5, 20.5, 21.5, 22.5};

int main() {
    cin >> l >> r;
    
    for (int i = 0; i < 22; ++i) {
        if (l <= mas_time[i] && mas_time[i] <= r) {
            ++ans;
        }
    }
    cout << ans;
    return 0;
}