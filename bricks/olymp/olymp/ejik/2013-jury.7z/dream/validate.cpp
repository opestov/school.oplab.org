#include "testlib.h"

using namespace std;



int main()
{
    registerValidation();
    
    int l = inf.readInt(0, 22); inf.readSpace();
    inf.readInt(l + 1, 23); inf.readEoln();
    inf.readEof();

    //ensure(l < r);
    return 0;
}
