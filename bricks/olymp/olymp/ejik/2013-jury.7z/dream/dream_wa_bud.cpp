#include <cstdio>
#include <iostream>
//ans = r - l
using namespace std;

int l, r;

int main() {
    cin >> l >> r;
    cout << r - l;
    return 0;
}