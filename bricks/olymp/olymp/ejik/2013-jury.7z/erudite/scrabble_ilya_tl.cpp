/*
	решение "в лоб" за N^4
*/

#include <stdio.h>
#include <algorithm>

using namespace std;

const int MAXN = (int)1e5;
const int MAXA = (int)1e4;

int n;
int mas[MAXN];

int main() {
	int ans = MAXN * MAXA + 1;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &mas[i]);
	for (int i = 0; i <= n - 4; i++) { // i -- последний элемент в первой группе 
		for (int j = i + 1; j <= n - 3; j++) { // j -- последний элемент во второй группе
			for (int k = j + 1; k <= n - 2; k++) { // k -- последний элемент в третьей группе
				int sum = 0;
				int localmax = 0;

				for (int l = 0; l <= i; l++)
					localmax = max(localmax, mas[l]);
				sum += localmax;
				localmax = 0;

				for (int l = i + 1; l <= j; l++)
					localmax = max(localmax, mas[l]);
				sum += localmax;
				localmax = 0;

				for (int l = j + 1; l <= k; l++)
					localmax = max(localmax, mas[l]);
				sum += localmax;
				localmax = 0;

				for (int l = k + 1; l < n; l++)
					localmax = max(localmax, mas[l]);
				sum += localmax;

				ans = min(ans, sum);
			}
		}
	} 
	printf("%d\n", ans);
	return 0;
}