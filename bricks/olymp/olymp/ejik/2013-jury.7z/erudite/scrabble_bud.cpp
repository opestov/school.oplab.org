#include <cstdio>
#include <iostream>
#include <cmath>

using namespace std;

int n, mas[100000], maxbe[100000], maxeb[100000];

int main() {
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> mas[i];
        if (i == 0) {
            maxbe[0] = mas[i];
        } else {
            maxbe[i] = max(maxbe[i - 1], mas[i]);
        }
    }
    

    for (int i = n - 1; i >= 0; --i) {
        if (i == n - 1) {
            maxeb[n - 1] = mas[n - 1];
        } else {
            maxeb[i] = max(maxeb[i + 1], mas[i]);
        }
    }
    //cout << "@";
    int ans = 10000 * 4 + 1;
    for (int i = 1; i <= n - 3; ++i) {
        int l, r;
        l = min(mas[0] + maxbe[i], mas[i] + maxbe[i]);
        r = min(mas[n - 1] + maxeb[i + 1], mas[i + 1] + maxeb[i + 1]);
        ans = min(ans, l + r);    
    }   
    
    cout << ans;

    return 0;
}