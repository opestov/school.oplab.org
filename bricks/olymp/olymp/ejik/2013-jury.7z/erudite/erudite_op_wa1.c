// greedy: take smallest from a[0] and a[size-1]
#include <stdio.h>

int main() {
  int n;
  scanf("%d", &n);

  int a[n];
  for (int i = 0; i < n; ++i)
    scanf("%d", &a[i]);

  int l = 0, r = n - 1;
  int b = 0;
  for (int i = 1; i <= 3; ++i)
    if (a[l] < a[r]) {
      b += a[l];
      ++l;
    }
    else {
      b += a[r];
      --r;
    }

  int x = a[l];
  for (int i = l; i <= r; ++i)
    if (a[i] > x)
      x = a[i];    

  b += x;
  printf("%d\n", b);

  return 0;
}