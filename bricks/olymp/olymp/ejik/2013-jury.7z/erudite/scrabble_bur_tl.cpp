#include <cstdio>
#include <iostream>


using namespace std;


long long int arr[100000], n, ans;



long long int get_ans(int r1, int r2, int r3) {
    long long int ans1, ans2, ans3, ans4;
    ans1 = 0;
    ans2 = 0;
    ans3 = 0;
    ans4 = 0;
    for(int t = 1; t <= n; ++t) {
        if (t <= r1) {
            ans1 = max(ans1, arr[t]);   
        }
        if (t > r1 && t <= r2) {    
            ans2 = max(ans2, arr[t]);
        }
        if (t > r2 && t <= r3) {
            ans3 = max(ans3, arr[t]);
        }
        if (t > r3) {
            ans4 = max(ans4, arr[t]);
        }
    }
    return ans1 + ans2 + ans3 + ans4;
}


int main() {
    //freopen("test.test", "r", stdin);
    cin >> n;
    ans = (int)1e15;
    for(int i = 1; i <= n; ++i) {
        cin >> arr[i];
    }
    for(int i = 1; i <= n - 3; ++i) {
        for(int j = i + 1; j <= n - 2; ++j) {
            for(int k = j + 1; k <= n - 1; ++k) {
                ans = min(ans, get_ans(i, j, k));
            }
        }
    }
    cout << ans;
    fclose(stdin);
    return 0;
}
