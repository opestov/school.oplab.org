/*
	решение за N
*/

#include <stdio.h>
#include <algorithm>

using namespace std;

const int MAXN = (int)1e5;
const int MAXA = (int)1e4;

int n;
int mas[MAXN];

int maxp0[MAXN]; // максимум на отрезке [0 ... i]
int maxp1[MAXN]; // максимум на отрезке [1 ... i]
int maxs0[MAXN]; // максимум на отрезке [i ... n - 1]
int maxs1[MAXN]; // максимум на отрезке [i ... n - 2]

int main() {
	int ans = MAXN * MAXA + 1;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &mas[i]);

	maxp0[0] = mas[0];
	for (int i = 1; i < n; i++)
		maxp0[i] = max(maxp0[i - 1], mas[i]);

	maxp1[1] = mas[1];
	for (int i = 2; i < n; i++)
		maxp1[i] = max(maxp1[i - 1], mas[i]);

	maxs0[n - 1] = mas[n - 1];
	for (int i = n - 2; i >= 0; i--)
		maxs0[i] = max(maxs0[i + 1], mas[i]);

	maxs1[n - 2] = mas[n - 2];
	for (int i = n - 3; i >= 0; i--)
		maxs1[i] = max(maxs1[i + 1], mas[i]);

	for (int i = 1; i <= n - 3; i++) { // i -- последний элемент во второй группе
		int localans = 0;
		localans += min(mas[0] + maxp1[i], mas[i] + maxp0[i - 1]);
		localans += min(mas[n - 1] + maxs1[i + 1], mas[i + 1] + maxs0[i + 2]);
		ans = min(ans, localans);
	}
	printf("%d\n", ans);
	return 0;
}
