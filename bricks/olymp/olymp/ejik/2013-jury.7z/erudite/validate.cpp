#include "testlib.h"

using namespace std;

int main()
{
  registerValidation();
  
  int n = inf.readInt(4, 100000);
  inf.readEoln();

  for (int i = 0; i < n; ++i) {
    if (i) inf.readSpace();
    inf.readInt(1, 10000);
  }
  inf.readEoln();
  inf.readEof();

  return 0;
}
