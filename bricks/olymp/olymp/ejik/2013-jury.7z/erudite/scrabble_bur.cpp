#include <iostream>
#include <cstdio>

using namespace std;                                       
                                 
long long int arrmax[100001], arr[100001], n, rmax, ans; 


long long int get_min(long long int rmax, long long int r) {
    long long int ans1 = 0;
    ans1 += rmax;
    ans1 += min(arr[1], arr[r]);
    ans1 += min(arr[r + 1], arr[n]);
    ans1 += arrmax[r];
    return ans1;              
}   


int main() {
    //freopen("test.test", "r", stdin);
    cin >> n;
    ans = (long long int)1e15;
    for(int i = 1; i <= n; ++i) {
        cin >> arr[i];
    }
    rmax = arr[n];
    for(int i = n; i > 1; --i) {
        rmax = max(rmax, arr[i]);
        arrmax[i - 1] = rmax;
    }
    rmax = arr[1];
    for(int i = 2; i <= n - 2; ++i) {
        rmax = max(rmax, arr[i]);
        ans = min(ans, get_min(rmax, i));
    }
    cout << ans;
    fclose(stdin);
    return 0;
}