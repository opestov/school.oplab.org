// print size of groups
#include <stdio.h>
#define min(a,b) (((a)<(b))?(a):(b))
#define max(a,b) (((a)>(b))?(a):(b))

int main() {
  int n, i;
  scanf("%d", &n);

  int a[n];
  for (i = 0; i < n; ++i)
    scanf("%d", &a[i]);

  int lm[n], rm[n];
  for (lm[0] = a[0], i = 1; i < n; ++i)
    lm[i] = max(lm[i-1], a[i]);
  for (rm[n-1] = a[n-1], i = n-2; i >= 0; --i)
    rm[i] = max(rm[i+1], a[i]);

  int b = 40000;
  for (i = 1; i + 2 < n; ++i)
    b = min(b, lm[i] + min(a[0], a[i]) + rm[i+1] + min(a[i+1], a[n-1]));

  for (i = 1; i + 2 < n; ++i)
    if (b == lm[i] + min(a[0], a[i]) + rm[i+1] + min(a[i+1], a[n-1])) {
      int g1, g2, g3, g4;
      if (a[0] < a[i]) { g1 = 1; g2 = i; } else { g1 = i; g2 = 1; }
      if (a[i+1] < a[n-1]) { g3 = 1; g4 = n-i-2; } else { g3 = n-i-2; g4 = 1; }
      printf("n=%d    %d %d %d %d\n", n, g1, g2, g3, g4);
    }
     
  
  return 0;
}