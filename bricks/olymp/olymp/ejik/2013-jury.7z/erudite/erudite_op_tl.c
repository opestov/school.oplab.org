// right idea but without precalc - O(n^2)
#include <stdio.h>

int main() {
  int n, i, z, l1, r1, l2, r2;
  scanf("%d", &n);

  int a[n];
  for (i = 0; i < n; ++i)
    scanf("%d", &a[i]);

  int b = 40000;
  for (i = 1; i + 2 < n; ++i) {
    int x = 0;
    if (a[0] < a[i]) 
      x += a[0], l1 = 1, r1 = i;
    else
      x += a[i], l1 = 0, r1 = i-1;
    z = a[l1];
    for (int j = l1+1; j <= r1; ++j)
      if (a[j] > z)
        z = a[j];
    x += z;

    if (a[i+1] < a[n-1])
      x += a[i+1], l2 = i+2, r2 = n-1;
    else
      x += a[n-1], l2 = i+1, r2 = n-2;
    z = a[l2];
    for (int j = l2+1; j <= r2; ++j)
      if (a[j] > z)
        z = a[j];
    x += z;


    if (x < b)
      b = x;
  }
  printf("%d\n", b);

  return 0;
}
