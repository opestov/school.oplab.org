#include <stdio.h>

void print_test(int n)
{
    static int test = 1;
    static char path[10];

    sprintf(path, "%03d", test++);
    FILE *file = fopen(path, "wt");

    fprintf(file, "%d\n", n);
    fclose(file);
}

int main()
{
    for (int i = 1; i <= 100; ++i)
        print_test(i);
    return 0;
}
