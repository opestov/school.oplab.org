#include "testlib.h"

using namespace std;

int main() {
    registerValidation();

    int budget = inf.readInt(1, 100000); inf.readSpace();
    int k = inf.readInt(1, 25); inf.readEoln();
    int n = inf.readInt(k, 25); inf.readEoln();
    
    int a[n];
    for (int i = 0; i < n; ++i) {
        if (i) inf.readSpace();
        a[i] = inf.readInt(1, 100000);
    }
    inf.readEoln();
    inf.readEof();

    sort(a, a + n);

    int sum = 0;
    for (int i = 0; i < k; ++i)
        sum += a[i];
    ensure(sum <= budget);

    return 0;
}
