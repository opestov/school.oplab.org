import random

for i in xrange(3, 21):
    n = min(i + 10, 25)
    k = random.randint(1, n)
    r = random.randint(10000, 100000)
    sum_prep = random.randint(0, r - k)
    arr = []
    for j in xrange(k - 1):
        arr.append(random.randint(0, sum_prep - 1))

    arr.append(0)
    arr.append(sum_prep - 1)
    arr.sort()
    out = []
    for j in xrange(k):
        out.append(arr[j + 1] - arr[j] + 1)
    for j in xrange(n - k):
        out.append(random.randint(r - sum_prep - k, r))

    random.shuffle(out)
    if (i == 18):
        out.sort()
    if (i == 19):
        out.sort()
        out.reverse()
    outp = open("0" * (2 - len(str(i))) + str(i), "w")
    outp.write(str(r) + " " + str(k) + "\n" + str(n) + "\n")
    for j in xrange(n):
        outp.write(str(out[j]) + " ")
    outp.write("\n")