#include <cstdio>
#include <iostream>
#include <ctime>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#define puba push_back
#define mapa make_pair
#define ff first
#define ss second
#define all(_x) _x.begin(), _x.end()
#define szof(_x) (int) _x.size()

using namespace std;
typedef long long LL;
const int MAXN = 30, MAXR = 1e5 + 5;

LL r, k, n;
int presents[MAXN];
bool given[MAXN], mem[MAXN];


int main() {    
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);
    srand(time(NULL));
    cin >> r >> k >> n;
    
    for (int i = 0; i < n; ++i) {        
        cin >> presents[i];
    }
    for (int i = 0; i < k; ++i) {
        given[i] = true;
    }
    //random_shuffle(all(presents));
    int bsb = 1 << n;
    int maxsum = 0;
    for (int i = 0; i < bsb; ++i) {
        int sum = 0;
                
        for (int j = 0; j < n; ++j) {
            //cout << given[j] << " ";
            if (given[j]) {
                sum += presents[j];                
                if (sum > r) {
                    break;
                }
            }            
        }
        //cout << endl;
        //cout << sum << endl;
        if (sum <= r) {            
            //cout << "@" << endl;
            if (maxsum < sum) {
                maxsum = sum;
                memcpy(&mem, &given, sizeof given);
            }
        }
        int where = -1, num = 0;
        for (int i = 0; i < n - 1; ++i) {
            if (given[i] && !given[i + 1]) {
                where = i;
                break;
            }
            num += given[i];
        }
        if (where == -1) {
            break;
        }
        memset(given, 0, where + 1);
        memset(given, 1, num);
        assert(!given[where]);
        given[where + 1] = true;
    }

    //cout << mem << endl;
    
    for (int i = 0; i < n; ++i) {
        //cout << mem % 2;
        if (mem[i]) {
            cout << i + 1 << " ";
        }
    }
    cout << endl;
            
    return 0;
}