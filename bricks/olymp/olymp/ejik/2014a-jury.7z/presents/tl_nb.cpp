#include <cstdio>
#include <iostream>
#include <ctime>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#define puba push_back
#define mapa make_pair
#define ff first
#define ss second
#define all(_x) _x.begin(), _x.end()
#define szof(_x) (int) _x.size()

using namespace std;
typedef long long LL;
const int MAXN = 30, MAXR = 1e5 + 5;

LL r, k, n;
vector <pair <int, int> > presents;

int main() {    
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);
    srand(time(NULL));
    cin >> r >> k >> n;
    
    for (int i = 0; i < n; ++i) {
        int num;
        cin >> num;
        presents.puba(mapa(num, i));
    }
    random_shuffle(all(presents));
    int bsb = 1 << n;
    int maxsum = 0, mem = -1;
    for (int i = 0; i < bsb; ++i) {
        int nump = 0, sum = 0;
        int temp = i;
        for (int j = 0; j < n; ++j) {
            if (temp % 2) {
                sum += presents[j].ff;
                ++nump;
            }
            temp >>= 1;
        }
        if (nump == k && sum <= r) {
            if (maxsum < sum) {
                maxsum = sum;
                mem = i;
            }
        }
    }

    vector <int> ans;
    
    for (int i = 0; i < n; ++i) {
        //cout << mem % 2;
        if (mem % 2) {
            ans.puba(presents[i].ss + 1);
        }
        mem >>= 1;
    }
    //cout << endl;
    
    random_shuffle(all(ans));
    for (int i = 0; i < szof(ans); ++i) {
        cout << ans[i] << " ";
    }

    cout << endl;
        
    return 0;
}