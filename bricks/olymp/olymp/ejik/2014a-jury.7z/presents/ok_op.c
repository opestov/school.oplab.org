#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int budget, k, n;
    int *items, *cart, *answer;

    scanf("%d%d%d", &budget, &k, &n);

    items = malloc(n * sizeof(int));
    cart = malloc(k * sizeof(int));
    answer = malloc(k * sizeof(int));

    for (int i = 0; i < n; ++i)
        scanf("%d", &items[i]);

    int sum = 0, best = -1;
    for (int i = 0; i < k; ++i) {
        cart[i] = i;
        sum += items[cart[i]];
    }

    while (1) {
        if (sum <= budget && sum > best) {
            memcpy(answer, cart, k * sizeof(int));
            best = sum;
        }
        int i;
        for (i = k - 1; i >= 0 && cart[i] == i + n - k; --i)
            sum -= items[cart[i]];
        if (i < 0)
            break;
        sum = sum - items[cart[i]] + items[cart[i] + 1];
        cart[i]++;
        for (i = i + 1; i < k; ++i) {
            cart[i] = cart[i - 1] + 1;
            sum += items[cart[i]];
        }
    }

    for (int i = 0; i < k; ++i) {
        if (i) printf(" ");
        printf("%d", answer[i] + 1);
    }
    printf("\n");

    return 0;
}
