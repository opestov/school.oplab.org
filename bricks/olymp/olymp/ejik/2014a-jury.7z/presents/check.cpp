#include "testlib.h"
#include <string>
#include <vector>
#include <sstream>
#include <iostream>

using namespace std;
const int MAXN = 50;

string ending(int x)
{
    x %= 100;
    if (x / 10 == 1)
        return "th";
    if (x % 10 == 1)
        return "st";
    if (x % 10 == 2)
        return "nd";
    if (x % 10 == 3)
        return "rd";
    return "th";
}

int presents[MAXN];

int main(int argc, char * argv[])
{
    setName("compare files as price of presents's set");
    registerTestlibCmd(argc, argv);

    

    int r = inf.readInt();    
    int k = inf.readInt();
    int n = inf.readInt();
    for (int i = 0; i < n; ++i) {
        presents[i] = inf.readInt();
    }

    int sum1 = 0;

    for (int i = 0; i < k; ++i) {        
        int num = ouf.readInt();
        if (num < 1 || num > n) {
            quitf(_pe, "Number of present must belong to [1..%d]", n);
        }
        sum1 += presents[num - 1];
        //cout << i << endl;
    }
    //ouf.readEof();
    int sum2 = 0;
    for (int i = 0; i < k; ++i) {
        int num = ans.readInt();
        sum2 += presents[num - 1];
        //cout << i << endl;
    }
    
    if (sum1 == sum2) {
        quitf(_ok, "Prices of present's set is equal");
    }
    if (sum1 < sum2) {
        quitf(_wa, "Price of your present's set is less than right price of present's set");
    }
    
    quitf(_wa, "Price of your present's set is more than right price of present's set");
}
