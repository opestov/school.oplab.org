// Take sequence of k one after another. 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int *items;

int cmp(const void *a, const void *b)
{
    return items[*((int*)a)] - items[*((int*)b)];
}

int main()
{
    int budget, k, n;
    scanf("%d%d%d", &budget, &k, &n);

    items = malloc(n * sizeof(int));
    for (int i = 0; i < n; ++i)
        scanf("%d", &items[i]);

    int *order = malloc(n * sizeof(int));
    for (int i = 0; i < n; ++i)
        order[i] = i;
    qsort(order, n, sizeof(int), cmp);

    int sum = 0, best = -1, answer = -1;
    for (int i = 0; i + k <= n; ++i) {
        sum = 0;
        for (int j = 0; j < k; ++j)
            sum += items[order[i + j]];
        if (sum <= budget && sum > best) {
            answer = i;
            best = sum;
        }
    }

    for (int i = 0; i < k; ++i) {
        if (i) printf(" ");
        printf("%d", order[answer + i] + 1);
    }
    printf("\n");

    return 0;
}
