#include <cstdio>
#include <iostream>
#include <ctime>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#define puba push_back
#define mapa make_pair
#define ff first
#define ss second
#define all(_x) _x.begin(), _x.end()
#define szof(_x) (int) _x.size()

using namespace std;
typedef long long LL;
const int MAXN = 1005;

int n, m;
int max_jump_h = 2;
int wall[MAXN][MAXN];
int to[MAXN][MAXN];
bool used[MAXN][MAXN];
vector <char> ans;
pair <int, int> start, finish;

int dfs(int x, int y) {    
    if (to[x][y] == -1) {
        return 0;
    }
    
    x = to[x][y];
    
    used[x][y] = true;
    if (mapa(x, y) == finish) {
        return 1;
    }
    if (y > 0 && to[x][y - 1] != -1 && !used[to[x][y - 1]][y - 1]) {
        if (!(to[x][y - 1] < x && wall[x - 1][y])) {
            if (dfs(to[x][y - 1], y - 1)) {
                ans.puba('L');
                return 1;
            }
        }        
    }
    if (y < m - 1 && to[x][y + 1] != -1 && !used[to[x][y + 1]][y + 1]) {
        if (!(to[x][y + 1] < x && wall[x - 1][y])) {
            if (dfs(to[x][y + 1], y + 1)) {
                ans.puba('R');
                return 1;
            }
        }        
    }
    return 0;
}

int main() {    
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);
    cin >> n >> m;

    for (int i = 0; i < n; ++i) {
        string s;
        cin >> s;
        for (int j = 0; j < m; ++j) {
            if (s[j] == 'P') {
                start = mapa(i, j);
            } else if (s[j] == 'F') {
                finish = mapa(i, j);
            } else if (s[j] == '#') {
                wall[i][j] = 1;
            }
        }
    }

    

    for (int i = 0; i < m; ++i) {
        int lasty = n;
        bool to_teleport = false;
        for (int j = n - 1; j >= 0; --j) {
            if (mapa(j, i) == finish) {
                to_teleport = true;
            }
            if (wall[j][i]) {
                lasty = j;
                to[j][i] = -1;
                to_teleport = false;
                if (j > 0 && !wall[j - 1][i]) {
                    to[j][i] = j - 1;
                } 
            } else if (lasty - j - 1 > max_jump_h && !to_teleport) {
                to[j][i] = -1;
            } else {
                to[j][i] = lasty - 1;
                if (to_teleport) {
                    to[j][i] = finish.ff;
                }
            }
        }
    }
    /*
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cout << to[i][j] << " ";
        }
        cout << endl;
    }
    */
    if (dfs(start.ff, start.ss)) {
        reverse(all(ans));
        for (int i = 0; i < szof(ans); ++i) {
            cout << ans[i];
        }
        cout << endl;       
    } else {
        cout << "I don't need no walls around me!\n";
    }

    return 0;
}