#include "testlib.h"
#include <string>
#include <vector>
#include <sstream>
#include <iostream>

using namespace std;
const int MAXN = 1005;
const int MH = 2;

string ending(int x)
{
    x %= 100;
    if (x / 10 == 1)
        return "th";
    if (x % 10 == 1)
        return "st";
    if (x % 10 == 2)
        return "nd";
    if (x % 10 == 3)
        return "rd";
    return "th";
}

int wall[MAXN][MAXN];
int startx, starty, finishx, finishy;

int main(int argc, char * argv[])
{
    setName("compare files as hedgehog's actions");
    registerTestlibCmd(argc, argv);

    std::string strAnswer;

    std::string a = ouf.readLine();    
    std::string b = ans.readLine();    
    ouf.readEof();    
    
    for (int i = a.size() - 1; i >= 0; --i) {
        if (a[i] == ' ') {
            a.resize(i);
        } else {
            break;
        }
    }
    //cout << a << endl;

    if (a == "I don't need no walls around me!" && a == b) {
        quitf(_ok, "No way");
    }
    if (a == "I don't need no walls around me!") {
        quitf(_wa, "Way exists, but you think otherwise");
    }

    for (int i = 0; i < (int) a.size(); ++i) {
        if (a[i] != 'L' && a[i] != 'R') {
            //a.resize(i);
            quitf(_pe, "Incorrect char: %c", a[i]);
        }
    }
    if ((int) a.size() > 1e6) {
        quitf(_pe, "Too large string");
    }
    
    if (b == "I don't need no walls around me!") {                
        quitf(_wa, "Way doesn't exist, but you think otherwise");
    }

    
    

    int n = inf.readInt();
    int m = inf.readInt();
    string s = inf.readLine();
    for (int i = 0; i < n; ++i) {
        s = inf.readLine();
        for (int j = 0; j < m; ++j) {
            if (s[j] == '#') {
                wall[i][j] = 1;
            } else if (s[j] == 'P') {
                startx = i;
                starty = j;
            } else if (s[j] == 'F') {
                finishx = i;
                finishy = j;
            }
        }
    }
    int nowx = startx, nowy = starty;
    for (int i = 0; i < (int) a.size(); ++i) {
        int h = 0;
        while (nowx < n - 1 && !wall[nowx + 1][nowy]) {
            ++nowx;
            if (nowx == finishx && nowy == finishy) {
                quitf(_ok, "Hedgehog walked out");
            }
            ++h;
        }
        if (h > MH) {
            quitf(_wa, "Hedgehog broke its legs");
        }
        if (a[i] == 'L' && nowy > 0) {
            if (!wall[nowx][nowy - 1]) {
                --nowy;
            } else {
                if (nowx > 0 && !wall[nowx - 1][nowy - 1] && !wall[nowx - 1][nowy]) {
                    --nowy;
                    --nowx;
                }
            }
        }
        if (a[i] == 'R' && nowy < m - 1) {
            if (!wall[nowx][nowy + 1]) {
                ++nowy;
            } else {
                if (nowx > 0 && !wall[nowx - 1][nowy + 1] && !wall[nowx - 1][nowy]) {
                    ++nowy;
                    --nowx;
                }
            }
        }
        if (nowx == finishx && nowy == finishy) {
            quitf(_ok, "Hedgehog walked out");
        }
    }
    int h = 0;
    while (nowx < n - 1 && !wall[nowx + 1][nowy]) {
        ++nowx;
        if (nowx == finishx && nowy == finishy) {
            quitf(_ok, "Hedgehog walked out");
        }
        ++h;
    }
    if (h > MH) {
        quitf(_wa, "Hedgehog broke its legs");
    }
    //cout << a << endl;
    quitf(_wa, "Hedgehog didn't walk out %d %d", nowx, nowy);
}
