// this solution does not check that cell above is empty when moving diagonally

#include <assert.h>
#include <stdio.h>

#define MR 1002
#define MC 1002
#define MH 2

struct cell {
    int r, c;
};

int rows, cols;
char maze[MR][MC];
struct cell from, to;

int height[MR][MC];
struct cell prev[MR][MC];

char path[MR * MC];

void calc_height()
{
    for (int r = rows - 1; r >= 0; --r)
        for (int c = 0; c < cols; ++c)
            if (maze[r][c] == '#')
                height[r][c] = -1;
            else
                height[r][c] = height[r + 1][c] + 1;
}

void dfs(struct cell v, struct cell p)
{
    if (prev[v.r][v.c].r != -1)
        return;
    prev[v.r][v.c] = p;

    if (v.r == to.r && v.c == to.c)
        return;

    static int dc[] = {-1, 1};

    for (int i = 0; i < 2; ++i) {
        int nc = v.c + dc[i];
        // down >= 0
        if (maze[v.r][nc] == '.') {
            int h = height[v.r][nc];
            if (nc == to.c && v.r <= to.r && v.r + h >= to.r)
                prev[to.r][to.c] = v;
            else if (h <= MH)
                dfs((struct cell){v.r + h, nc}, v);
        }
        // up 1
        if (maze[v.r][nc] == '#' && maze[v.r - 1][nc] == '.')
            dfs((struct cell){v.r - 1, nc}, v);
    }
}

void doit()
{
    calc_height();
    for (int r = 0; r < rows; ++r)
        for (int c = 0; c < cols; ++c) {
            if (maze[r][c] == 'P') {
                from = (struct cell) {r, c};
                maze[r][c] = '.';
            }
            if (maze[r][c] == 'F') {
                to = (struct cell) {r, c};
                maze[r][c] = '.';
            }
            prev[r][c] = (struct cell) {-1, -1};
        }

    assert(height[from.r][from.c] >= 0);
    assert(height[to.r][to.c] >= 0);

    int h = height[from.r][from.c];
    if (from.c == to.c && from.r <= to.r && from.r + h >= to.r) {
	from = to;
        prev[to.r][to.c] = from;
    }
    else if (h <= MH) {
        from.r = from.r + height[from.r][from.c];
        dfs(from, from);
    }

    if (prev[to.r][to.c].r == -1)
        printf("%s\n", "I don't need no walls around me!");
    else {
        struct cell v;
        v = to;

        int k = 0;
        while (v.r != from.r || v.c != from.c) {
            struct cell p = prev[v.r][v.c];
            if (p.c < v.c)
                path[k++] = 'R';
            else
                path[k++] = 'L';
            v = p;
        }
        for (int i = k - 1; i >= 0; --i)
            printf("%c", path[i]);
        printf("\n");
    }
}

int main()
{
    while (scanf("%d%d\n", &rows, &cols) == 2) {
        for (int r = 1; r <= rows; ++r) {
            fgets(maze[r] + 1, cols + 2, stdin);
            maze[r][0] = '#';
            maze[r][cols + 1] = '#';
        }
        for (int c = 0; c < cols + 2; ++c) {
            maze[0][c] = '#';
            maze[rows + 1][c] = '#';
        }

        rows += 2;
        cols += 2;
        doit();
    }

    return 0;
}
