#include "testlib.h"

using namespace std;

int main() {
    registerValidation();

    int h = inf.readInt(1, 1000); inf.readSpace();
    int w = inf.readInt(1, 1000); inf.readEoln();

    int p = 0, f = 0;
    for (int i = 0; i < h; ++i) {
        for (int j = 0; j < w; ++j) {
            char c = inf.readChar();
            ensure(c == '.' || c == '#' || c == 'P' || c == 'F');
            if (c == 'P') {
                ensure(p == 0);
                p = 1;
            }
            if (c == 'F') {
                ensure(f == 0);
                f = 1;
            }
        }
        inf.readEoln();
    }

    return 0;
}
