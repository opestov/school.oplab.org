import random

size = [1000, 3]

outp = open("25", "w")

outp.write(str(size[0]) + " " + str(size[1]) + "\n")

wall = ["."] * size[0]
for i in xrange(size[0]):
    wall[i] = ["."] * size[1]

for i in xrange(0, size[0], 2):
    for j in xrange(1, size[1], 2):
        wall[i][j] = "#"

for i in xrange(1, size[0], 2):
    for j in xrange(0, size[1], 2):
        wall[i][j] = "#"

wall[0][size[1] / 2] = "F"
wall[size[0] - 1][size[1] / 2] = "P"

for i in xrange(size[0]):
    for j in xrange(size[1]):
        outp.write(wall[i][j])
    outp.write("\n")