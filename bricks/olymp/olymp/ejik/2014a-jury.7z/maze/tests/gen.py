import random

n = 1000
m = 1000
lvl = 21
outp = open("pre" + str(lvl), "w")

outp.write(str(n) + " " + str(m))

wall = ["."] * n
for i in xrange(n):
    wall[i] = ["."] * m

num_bricks = 10000

for i in xrange(num_bricks):
    wall[random.randint(0, n - 1)][random.randint(0, m - 1)] = "#"

wall[random.randint(0, n - 1)][random.randint(0, m - 1)] = "P"

remember = wall