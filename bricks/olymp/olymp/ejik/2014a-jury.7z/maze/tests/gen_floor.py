import random

n = 1000
m = 1000
lvl = 40
outp = open(str(lvl), "w")

outp.write(str(n) + " " + str(m) + "\n")

wall = ["."] * n
for i in xrange(n):
    wall[i] = ["."] * m


for i in xrange(1, n, 2):
    for j in xrange(m):
        if (random.randint(0, 80) != 0):
            wall[i][j] = "#"

trash = 2000

for i in xrange(trash):
    wall[random.randint(0, n - 1)][random.randint(0, m - 1)] = "#"


wall[0][random.randint(0, m - 1)] = "P"
wall[n - 1][random.randint(0, m - 1)] = "F"

for i in xrange(n):
    for j in xrange(m):
        outp.write(wall[i][j])
    outp.write("\n")