#include <cstdio>
#include <iostream>
#include <ctime>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#define puba push_back
#define mapa make_pair
#define ff first
#define ss second
#define all(_x) _x.begin(), _x.end()
#define szof(_x) (int) _x.size()

using namespace std;
typedef long long LL;
                     
LL n;
pair <LL, LL> ans = mapa(1e18, -1);
vector <pair <pair <int, int>, int> > inp;

int main() {    
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);
    srand(time(NULL));

    cin >> n;
    
    for (int i = 0; i < n; ++i) {
        int c, p;
        cin >> c >> p;
        inp.puba(mapa(mapa(c, p), i));
    }
    random_shuffle(all(inp));

    for (int i = 0; i < n; ++i) {
        LL c = inp[i].ff.ff, p = inp[i].ff.ss;        
        LL price = c * (100 + p);
        ans = min(ans, mapa(price, (LL) inp[i].ss));
    }
    //cout << ans.ff << endl;
    cout << ans.ss + 1 << endl;

    return 0;
}