// Print latest

#include <stdio.h>

int main()
{
    int n, p, c;
    scanf("%d", &n);

    int bi = -1, bs;
    for (int i = 0; i < n; ++i) {
        scanf("%d%d", &p, &c);
        if (bi == -1 || bs >= p * (100 + c)) {
            bi = i;
            bs = p * (100 + c);
        }
    }
    printf("%d\n", bi + 1);

    return 0;
}