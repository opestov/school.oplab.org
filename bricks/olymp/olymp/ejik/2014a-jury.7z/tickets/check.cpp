#include "testlib.h"
#include <string>
#include <vector>
#include <sstream>
#include <iostream>

using namespace std;
const int MAXN = 50;

string ending(int x)
{
    x %= 100;
    if (x / 10 == 1)
        return "th";
    if (x % 10 == 1)
        return "st";
    if (x % 10 == 2)
        return "nd";
    if (x % 10 == 3)
        return "rd";
    return "th";
}

int presents[MAXN];

int main(int argc, char * argv[])
{
    setName("compare files as number of site with the cheapest ticket");
    registerTestlibCmd(argc, argv);

    

    int a = ouf.readInt();    
    int b = ans.readInt();
    int n = inf.readInt();
    if (a < 1 || n < a) {
        quitf(_pe, "Number of site must belong to [1..%d]", n);
    }
    int pr1 = 0;
    int pr2 = 0;
    for (int i = 0; i < n; ++i) {
        int c = inf.readInt();
        int p = inf.readInt();
        if (i == a - 1) {
            pr1 = (100 + p) * c;
        }
        if (i == b - 1) {
            pr2 = (100 + p) * c;
        }
    }
    //cout << pr1 << " " << pr2 << " " << a << " " << b << " ";            
    if (pr1 == pr2) {
        quitf(_ok, "Prices of tickets is equal");
    }

    quitf(_wa, "Prices of tickets isn't equal");
}
