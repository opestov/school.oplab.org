import random

for i in xrange(3, 21):
    outp = open("0" * (2 - len(str(i))) + str(i), "w")
    n = 1000 / 20 * i
    outp.write(str(n) + "\n")
    minc = 1
    maxc = 10000
    if (16 <= i <= 18):
        minc = random.randint(1, 10000)
        maxc = minc
    for j in xrange(n):
        outp.write(str(random.randint(minc, maxc)) + " " + str(random.randint(0, 100)) + "\n")