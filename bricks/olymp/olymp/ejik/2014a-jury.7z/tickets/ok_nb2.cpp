#include <cstdio>
#include <iostream>
#include <ctime>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#define puba push_back
#define mapa make_pair
#define ff first
#define ss second
#define all(_x) _x.begin(), _x.end()
#define szof(_x) (int) _x.size()

using namespace std;
typedef long long LL;
                     
LL n;
pair <double, LL> ans = mapa(1e18, -1);

int main() {    
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);

    cin >> n;
    for (int i = 0; i < n; ++i) {
        LL c, p;
        cin >> c >> p;
        double price = c * (100 + p) / 100.0;
        ans = min(ans, mapa(price, (LL) i));
    }
    cout << ans.ss + 1 << endl;

    return 0;
}