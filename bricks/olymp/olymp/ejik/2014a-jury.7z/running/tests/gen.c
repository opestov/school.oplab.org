#include <stdio.h>

#define MAXN 10

int d[MAXN];

// http://school.anhb.uwa.edu.au/personalpages/kwessen/shared/Marsaglia03.html
// replace defaults with five random seed values in calling program
unsigned long next()
{
    static unsigned long x = 123458769, y = 362604369, z = 528926128, w = 12375886, v = 367564885;
    unsigned long t = (x ^ (x >> 7));
    x = y; y = z; z = w; w = v;
    v = (v ^ (v << 6)) ^ (t ^ (t << 13));
    return (y + y + 1) * v;
}

void print_test(int a, int b, int c)
{
    static int test = 1;
    static char path[10];

    sprintf(path, "%02d", test++);
    FILE *file = fopen(path, "wt");

    fprintf(file, "%d %d %d %d %d %d\n", a / 60, a % 60, b / 60, b % 60, c / 60, c % 60);
    fclose(file);
}

int randInt(int a, int b)
{
    return ((next() % (b - a + 1)) + a);
}

int gcd(int a, int b)
{
    return b == 0 ? a : gcd(b, a % b);
}

void genRandom(int rA, int rX, int rB, int rY, int scale)
{
    int a, b, c, x, y;
    while (1) {
        a = randInt(60, rA);
        x = randInt(1, rX);
        b = randInt(60, rB);
        y = randInt(1, rY);
        c = a * x + b * y;

        if (c <= 6000059) {
            int d = scale ? 6000059 / c : 1;
            print_test(c * d, a * d, b * d);
            return;
        }
    }
}

void genStupid()
{
    int a, b, c;
    while (1) {
        a = randInt(60, 6000059);
        b = randInt(60, 6000059);
        if (10 * (a + b) < 6000059) {
            c = randInt(10 * (a + b), 6000059);
            print_test(c, a, b);
            break;
        }
    }
}

void scale(int c, int a, int b)
{
    int d = 6000059 / c;
    print_test(c * d, a * d, b * d);
}

int main()
{
    print_test(60, 60, 60);
    print_test(5999940, 60, 60);

    for (int i = 0; i < 3; ++i)
        genStupid();

    for (int i = 0; i < 2; ++i)
        genRandom(600, 20, 600, 20, 0);
    for (int i = 0; i < 2; ++i)
        genRandom(600, 20, 600, 20, 1);
    for (int i = 0; i < 2; ++i)
        genRandom(600, 200000, 600, 200000, 0);
    for (int i = 0; i < 2; ++i)
        genRandom(10000, 10000, 10000, 10000, 1);

    scale(512 * 2 + 256 * 4, 512, 256);
    scale(256 * 4 + 512 * 2, 256, 512);
    print_test(900000, 300000, 100000);
    scale(1542, 120, 246);
    scale(1912, 341, 170);

    scale(198765, 3, 2);
    scale(920000, 23, 10);

    return 0;
}
