#include <cstdio>
#include <iostream>
#include <ctime>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#define puba push_back
#define mapa make_pair
#define ff first
#define ss second
#define all(_x) _x.begin(), _x.end()
#define szof(_x) (int) _x.size()

using namespace std;
typedef long long LL;

LL m, s, mt, st, mh, sh;
LL dur, durt, durh;

int main() {    
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);

    cin >> m >> s >> mt >> st >> mh >> sh;

    dur = m * 60 + s;
    durt = mt * 60 + st;
    durh = mh * 60 + sh;

    for (int i = 1; i * durh + durt <= dur; ++i) {
        if ((dur - i * durh) % durt == 0) {
            cout << (dur - i * durh) / durt << " " << i << endl;
            return 0;
        }
    }
    
    cout << -1 << endl;

    return 0;
}