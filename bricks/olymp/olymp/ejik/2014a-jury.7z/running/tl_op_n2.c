#include <stdio.h>

int read_duration()
{
    int m, s;
    scanf("%d%d", &m, &s);
    return m * 60 + s;
}

int main()
{
    int total = read_duration();
    int tiger = read_duration();
    int hero = read_duration();

    int ai = -1, aj = -1;
    for (int i = 1; i * tiger <= total; ++i)
        for (int j = 1; i * tiger + j * hero <= total; ++j)
            if (i * tiger + j * hero == total) {
                ai = i;
                aj = j;
            }

    if (ai == -1)
        printf("-1\n");
    else
        printf("%d %d\n", ai, aj);

    return 0;
}