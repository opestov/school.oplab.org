#include <stdio.h>
#include <inttypes.h>

int64_t read_duration()
{
    int64_t m, s;
    scanf("%" SCNd64 "%" SCNd64, &m, &s);
    return m * 60 + s;
}

int64_t egcd(int64_t a, int64_t b, int64_t *x, int64_t *y)
{
    if (b == 0) {
        *x = 1;
        *y = 0;
        return a;
    }
    int64_t g, x1, y1;
    g = egcd(b, a % b, &x1, &y1);
    *x = y1;
    *y = x1 - (a / b) * y1;
    return g;
}

int main()
{
    int64_t total = read_duration();
    int64_t tiger = read_duration();
    int64_t hero = read_duration();

    int64_t i, j, g;
    g = egcd(tiger, hero, &i, &j);
    if (total % g != 0) {
        printf("-1\n");
        return 0;
    }

    total /= g;
    tiger /= g;
    hero /= g;

    if (j <= 0) { 
        int64_t k = (total - total * j + tiger - 1) / tiger;
        i = i * total - k * hero;
        j = j * total - k * tiger;
    }
    else {
        int64_t k = (j * total - 1) / tiger;
        i = i * total + k * hero;
        j = j * total - k * tiger;
    }

    if (i <= 0)
        printf("-1\n");
    else
        printf("%" PRId64 " %" PRId64 "\n", i, j);

    return 0;
}
