#include "testlib.h"

using namespace std;

int main() {
    registerValidation();

    inf.readInt(1, 100000); inf.readSpace();
    inf.readInt(0, 59); inf.readSpace();
    inf.readInt(1, 100000); inf.readSpace();
    inf.readInt(0, 59); inf.readSpace();
    inf.readInt(1, 100000); inf.readSpace();
    inf.readInt(0, 59); inf.readEoln();

    return 0;
}
