#include "testlib.h"
#include <sstream>

#define TESTS 10
#define MAXF 10
#define FUN_SIZE_LIMIT 50
#define INSTR_LIMIT 1000000

using namespace std;

// L, U, R, D
static int DR[] = {0, -1, 0, 1};
static int DC[] = {-1, 0, 1, 0};

struct level_info {
    int width, row, col, dir, stars;
    char *color;
    char *flag;

    int fnum;
    int *flen;
};

struct level_info  *read_level()
{
    struct level_info *l = (struct level_info *)malloc(sizeof(struct level_info));
    int h = inf.readInt();
    int w = inf.readInt();
    inf.nextLine();

    l->width = w + 2;

    l->color = (char *)calloc((h + 2) * (w + 2), sizeof(char));
    for (int r = 0; r < h; ++r) {
        for (int c = 0; c < w; ++c) {
            char x = tolower(inf.readChar());
            l->color[(r + 1) * (w + 2) + c + 1] = x;
        }
        inf.nextLine();
    }

    l->stars = 0;
    l->flag = (char *)calloc((h + 2) * (w + 2), sizeof(char));
    for (int r = 0; r < h; ++r) {
        for (int c = 0; c < w; ++c) {
            char x = tolower(inf.readChar());
            if (x == '*') {
                l->flag[(r + 1) * (w + 2) + c + 1] = 1;
                l->stars++;
            }
            else if (x != '.') {
                l->row = r + 1;
                l->col = c + 1;
                if (x == 'l')
                    l->dir = 0;
                else if (x == 'u')
                    l->dir = 1;
                else if (x == 'r')
                    l->dir = 2;
                else if (x == 'd')
                    l->dir = 3;
                else
                    quit(_fail, "Illegal robot direction in input file.");
            }
        }
        inf.nextLine();
    }

    l->fnum = inf.readInt();
    if (l->fnum > MAXF)
        quit(_fail, "Number of functions is too large.");

    inf.nextLine();
    l->flen = (int *)malloc(l->fnum  * sizeof(int));
    for (int i = 0; i < l->fnum; ++i) {
        l->flen[i] = inf.readInt();
        if (l->flen[i] > FUN_SIZE_LIMIT)
            quit(_fail, "Size of function exceeds preconfigured limit.");
    }
    return l;
}

char color(struct level_info *l)
{
    return l->color[l->row * l->width + l->col];
}
void left(struct level_info *l)
{
    l->dir = (l->dir + 3) % 4;
}
void right(struct level_info *l)
{
    l->dir = (l->dir + 1) % 4;
}
int try_step(struct level_info *l)
{
    l->row += DR[l->dir];
    l->col += DC[l->dir];

    if (0 == l->color[l->row * l->width + l->col])
        return 0;
    l->stars -= l->flag[l->row * l->width + l->col];
    l->flag[l->row * l->width + l->col] = 0;
    return 1;
}

struct level_info *(idata[TESTS]);
int oflag[TESTS];

char fun[MAXF][FUN_SIZE_LIMIT], cond[MAXF][FUN_SIZE_LIMIT];
int sf[INSTR_LIMIT * 2], pc[INSTR_LIMIT * 2];

bool oneTest(int id)
{
    int n = idata[id]->fnum;
    for (int i = 0; i < n; ++i) {
        ouf.readChar(':');
        for (int j = 0; j < idata[id]->flen[i]; ++j) {
            char x = ouf.readChar();
            if (!(x == 'r' || x == 'g' || x == 'b' || x == '#'))
                quit(_pe, "Wrong color in function.");
            cond[i][j] = x;
        }
        ouf.readChar(',');
        for (int j = 0; j < idata[id]->flen[i]; ++j) {
            char x = ouf.readChar();
            if (x != 'l' && x != 'r' && x != 's' && x != 'n')
                if (!(x >= '0' && ((x - '0') < n)))
                    quit(_pe, "Wrong function reference");
            fun[i][j] = x;
        }
    }

    int p = 0, k = 0;
    sf[0] = 0;
    pc[0] = -1;
    while (p >= 0 && idata[id]->stars > 0 && k <= INSTR_LIMIT)  {
        ++k;
        ++pc[p];
        if (pc[p] >= idata[id]->flen[sf[p]]) {
            --p;
            continue;
        }
        if (cond[sf[p]][pc[p]] == '#' || color(idata[id]) == cond[sf[p]][pc[p]]) {
            char f = fun[sf[p]][pc[p]];
            if (f == 'l')
                left(idata[id]);
            else if (f == 'r')
                right(idata[id]);
            else if (f == 's') {
                if (!try_step(idata[id]))
                    break;
            }
            else if (f == 'n') {
                // NOP
            }
            else {
                ++p;
                sf[p] = (f - '0') ;
                pc[p] = -1;
            }
        }
    }

    return idata[id]->stars == 0;
}

int main(int argc, char * argv[])
{
    registerTestlibCmd(argc, argv);

    for (int i = 0; i < TESTS; ++i) {
        idata[i] = read_level();
        oflag[i] = 0;
    }

    int scorePerTest = (100 / TESTS);
    int score = 0;

    ostringstream passed;
    passed << "Partial solution. The following tests were passed:";

    while (!ouf.seekEof()) {
        int t = ouf.readInt() - 1;
        ouf.readSpace();

        ensure(t >= 0 && t < TESTS);
        ensure(!oflag[t]);
        oflag[t] = 1;

        if (oneTest(t)) {
            score += scorePerTest;
            passed << " ";
            passed << (t + 1);
        }
        ouf.nextLine();
    }

    if (score == 100)
        quit(_ok, "");
    else {
        fprintf(stderr, "%s\n", passed.str().c_str());
        printf("%d\n", score);
        return _wa;
    }
}
