﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IoSHik
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            if (n % 2 == 0) Console.WriteLine("Yes");
            else Console.WriteLine("No");
        }
    }
}
