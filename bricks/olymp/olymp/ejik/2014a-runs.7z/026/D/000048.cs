﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IoSHik
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[,] a=new int[n,2];
            string[] s=new string[2];
            for (int i = 0; i < n; i++)
            {
                s = Console.ReadLine().Split();
                a[i, 0] = int.Parse(s[0]);
                a[i, 1] = int.Parse(s[1]);
            }

            int c = 99999999;
            int r = 0;
            int o = 0;
            for (int i = 0; i < n; i++)
            {
                r = a[i,0] + a[i, 0] * a[i, 1] / 100;
                if (r < c) 
                { 
                    c = r;
                    o = i+1;
                }
            }
            Console.WriteLine(o);
        }
    }
}
