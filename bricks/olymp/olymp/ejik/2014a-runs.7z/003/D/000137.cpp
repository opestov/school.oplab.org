#include <iostream>

using namespace std;

int main()
{
int n;
cin >> n;
int ci[n-1];
int pi[n-1];
double VICHI1[n-1];
double VICHI2[n-1];
double VICHI3[n-1];
 for(int i=0;i <= n-1; i++)
 {
 cin >> ci[i];
 cin >> pi[i];

 VICHI1[i] = pi[i]/100;
 VICHI2[i] = ci[i]*VICHI1[i];
 VICHI3[i] = ci[i] + VICHI2[i];

 }

 for(int h = 0; h <= n-1; h++)
 {

     cout << endl << endl << VICHI3[h] << endl;
 }


    return 0;
}
