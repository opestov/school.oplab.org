﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace половик_1
{
    class Program
    {
        public void run1()
        {
            int[] a = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            int mb = a[0], sb = a[1], mt = a[2], st = a[3], md = a[4], sd = a[5],tb,tt,td;
            tb = mb * 60 + sb;
            tt = mt * 60 + st;
            td = md * 60 + sd;
            int i = 0,maxi=0,j;
            for (i = 1; i*tt < tb; i++)
            {
                if ((tb - i * tt) % td == 0)
                {
                    maxi = i;
                }
            }
            if (maxi == 0)
            {
                Console.WriteLine("-1");
                return;
            }
            j =(int)(tb - maxi * tt) / td;
            Console.WriteLine(maxi+" "+j);
        }
        bool[] bol = new bool[25];
        bool[] mbol = new bool[25];
        int r = -1;
        int maxsum=-1;
        int k = -1;
        int[] b = new int[25];
        int n = -1;

        public void rabb(int sum,int ch,int kol)
        {
            if (sum > r) return;
            if (ch==n && sum>maxsum && kol == k)
            {
                for (int i = 0; i < n; i++)
			    {
                    mbol[i] = bol[i];
            //        Console.WriteLine(mbol[i]);
			    }
                maxsum=sum;
                return;
            }
            if (ch >= n) return;
            bol[ch] = false;
            rabb(sum, ch + 1,kol);
            bol[ch] = true;
            rabb(sum + b[ch], ch + 1,kol+1);
        }

        public void run2()
        {
            var sr = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            r = sr[0];
            k = sr[1];
            sr = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            n = sr[0];
            b=Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            rabb(0,0,0);
            for (int i = 0; i < 25; i++)
			{
                if (mbol[i]) Console.Write((i+1)+" ");
			}
        }
        public void run3()
        {

        }
        public static void Main(string[] args)
        {
            var ab = new Program();
            ab.run2();
        }
    }
}
