#include <iostream>

using namespace std;

int main()
{
    int n = 0;
    cin >> n;
    if (n % 2 == 0) {
        cout << "YES" << endl;
    }
    else {
        cout << "NO" << endl;
    }
    return 0;
}
