﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace половик_1
{
    class Program
    {
        public void run1()
        {
            int[] a = Console.ReadLine().Split().Select(x => int.Parse(x)).ToArray();
            int mb = a[0], sb = a[1], mt = a[2], st = a[3], md = a[4], sd = a[5],tb,tt,td;
            tb = mb * 60 + sb;
            tt = mt * 60 + st;
            td = md * 60 + sd;
            int i = 0,maxi=0,j;
            for (i = 1; i*tt < tb; i++)
            {
                if ((tb - i * tt) % td == 0)
                {
                    maxi = i;
                }
            }
            if (maxi == 0)
            {
                Console.WriteLine("-1");
                return;
            }
            j =(int)(tb - maxi * tt) / td;
            Console.WriteLine(maxi+" "+j);
        }
        public void run2()
        {

        }
        public void run3()
        {

        }
        public static void Main(string[] args)
        {
            var ab = new Program();
            ab.run1();
        }
    }
}
