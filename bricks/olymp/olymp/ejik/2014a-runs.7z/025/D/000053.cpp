#include <iostream>

using namespace std;

int main()
{
    int n = 0;
    double a, b;
    double mas[1000];
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> a >> b;
        mas[i] = a + (a / 100 * b);
    }
    int minimal = 10000000;
    int numer = -1;
    for (int i = 0; i < n; i++) {
        //cout << mas[i] << " ";
        if (mas[i] < minimal) {
            minimal = mas[i];
            numer = i + 1;
        }
    }
    cout << numer << endl;
    return 0;
}
