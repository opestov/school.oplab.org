n = int(input())
pr = []
s = []
prs = []
for x in range(n):
    t1, t2 = input().split(' ')
    t1 = int(t1)
    t2 = int(t2)
    pr.append(t1)
    s.append(t2/100)
for x in range(n):
    prs.append(pr[x] + pr[x]*s[x])
print(prs.index(min(prs))+1)
