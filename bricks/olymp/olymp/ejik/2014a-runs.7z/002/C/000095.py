num = [int(x) for x in input().split(' ')]
numSec = []
c = num[0]*60 + num[1]
a = num[2]*60 + num[3]
b = num[4]*60 + num[5]
isRes = False
for m in range(1,100000):
    for n in range(1,100000):
        if n*a + m*b < c:
            continue
        elif n*a + m*b == c:
            isRes = True
            break
        else:
            break
print(n,m) if isRes == True else print('-1')
