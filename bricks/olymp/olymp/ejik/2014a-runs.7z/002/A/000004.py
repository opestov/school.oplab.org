age = bin(int(input()))
if str(age).endswith('0'):
    print('YES')
else:
    print('NO')
