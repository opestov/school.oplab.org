#include <iostream>

int main(){
    unsigned int age;;
    std::cin >> age;
    if(age%2==0)
             std::cout << "YES" << std::endl;
    else
         std::cout << "NO";
    std::cin >> age;
    return 0;
}
