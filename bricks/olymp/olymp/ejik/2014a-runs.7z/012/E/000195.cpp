#include <iostream>
#include <vector>

unsigned int budget, countgifts;
unsigned int countbuygifts;
std::vector<unsigned int> Prices;

class ListBuy{
 public:
        ListBuy(){
                  allprice = 0;
                  }
        unsigned int allprice ;
        std::vector<unsigned int> NumberGifts;      
};

ListBuy recursia(unsigned short int _i, ListBuy List){
   ListBuy BestBuy = List;
   for(unsigned int i=_i; i<countbuygifts;i++){
       ListBuy listgifts = List;
       if(Prices[i]+listgifts.allprice <= budget){
       listgifts.allprice += Prices[i];
       listgifts.NumberGifts.push_back(i);
       listgifts = recursia(i+1, listgifts);  
       if(listgifts.allprice > BestBuy.allprice & listgifts.allprice <= budget)
          if(listgifts.NumberGifts.size() == countgifts){
                BestBuy = listgifts;
                }
                }            
   }
   return BestBuy;        
} 

int main(){
    std::cin >> budget >> countgifts;
    std::cin >> countbuygifts;
    for(unsigned int i=0; i < countbuygifts; i++){
        unsigned int price;
        std::cin >> price;
        Prices.push_back(price);
    }
    ListBuy BestBuy;
    for(unsigned int i=0; i < countbuygifts-1;i++){
        ListBuy listgifts;
        listgifts.allprice = Prices[i];
        listgifts.NumberGifts.push_back(i);
        listgifts = recursia(i+1, listgifts); 
        if(i!=0)
          if(listgifts.allprice > BestBuy.allprice && listgifts.allprice <= budget)
             if(listgifts.NumberGifts.size() == countgifts){
                BestBuy = listgifts;  
          }
        else
          if(listgifts.allprice <= budget)
             if(listgifts.NumberGifts.size() == countgifts){
                BestBuy = listgifts;  
            }
    }
    for(unsigned int i=0; i < BestBuy.NumberGifts.size();i++){
        std::cout << BestBuy.NumberGifts[i]+1 << " ";
    }
    std::cin >> budget;
    return 0;
}
