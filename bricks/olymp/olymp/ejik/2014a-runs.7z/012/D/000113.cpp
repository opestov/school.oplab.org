#include <iostream>
#include <vector>

int main(){
    unsigned int count = 0;
    std::vector<double> Prices;
    std::cin >> count;
    for(unsigned int i=1; i<=count;i++){
        double price;
        double procent;
        std::cin >> price >> procent;
        procent = 1 + procent/100;
        price = price*procent;    
        Prices.push_back(price);         
    }
    
    unsigned short int BestPrice = 0;
    for(unsigned short i =1; i < count; i++){
       if(Prices[BestPrice] > Prices[i])
           BestPrice = i;
    }
    
    std::cout << BestPrice+1;
    std::cin >> count;
    
    return 0;
}
