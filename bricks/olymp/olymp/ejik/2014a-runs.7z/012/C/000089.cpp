#include <iostream>
#include <math.h>

int main(){
    unsigned long int TrainMin, TrainSeconds;
    unsigned long int Sing1Min, Sing1Seconds;
    unsigned long int Sing2Min, Sing2Seconds;
    std::cin >> TrainMin >> TrainSeconds >> Sing1Min >> Sing1Seconds >> Sing2Min >> Sing2Seconds;
    unsigned long int TimeTrain = TrainMin*60 + TrainSeconds;
    unsigned long int TimeSing1 = Sing1Min*60 + Sing1Seconds;
    unsigned long int TimeSing2 = Sing2Min*60 + Sing2Seconds;
    unsigned long int TimeForSing = 0;
    unsigned long int Sing1 = 0;  
    unsigned long int Sing2 = 0;
    for(unsigned long int i=1; i<floor(TimeTrain/TimeSing1);i++){
        TimeForSing += TimeSing1*i;
        unsigned long int i2 = int(floor((TimeTrain-i*TimeSing1)/TimeSing2));
        TimeForSing += TimeSing2*i2;   
        if(TimeForSing == TimeTrain & i>Sing1 & i2>0){
                       Sing1 = i;
                       Sing2 = i2;               
        }
        TimeForSing = 0;            
    }
    if(Sing1 == 0)
             std::cout << -1;
    else
        std::cout << Sing1 << " " << Sing2;
    std::cin >> Sing1;
    return 0;
}
