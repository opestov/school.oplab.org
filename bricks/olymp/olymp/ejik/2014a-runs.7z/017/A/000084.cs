﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace A
{
    class Program
    {
        static void Main(string[] args)
        {
            int value = Convert.ToInt32(Console.ReadLine());
            string binary = Convert.ToString(value, 2);
            if ((Convert.ToInt32(binary) % 10) == 0)
            {
                Console.WriteLine("YES");
            }
            else 
            {
                Console.WriteLine("NO");
            }
            Console.ReadLine();
        }
    }
}
