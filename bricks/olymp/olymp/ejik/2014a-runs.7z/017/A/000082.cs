﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] MyInput = Console.ReadLine().Split(' ');
            Int32 TrenLen = Convert.ToInt32(MyInput[0]) * 60 + Convert.ToInt32(MyInput[1]);
            Int32 TigerLen = Convert.ToInt32(MyInput[2]) * 60 + Convert.ToInt32(MyInput[3]);
            Int32 HeroLen = Convert.ToInt32(MyInput[4]) * 60 + Convert.ToInt32(MyInput[5]);
            Int32 OvLen= 0;
            Int32 Counter = 0;
            Int32 Counter2 = 0;
            while (OvLen <= TrenLen)
            {
                OvLen = OvLen + TigerLen;
                Counter = Counter + 1;
            }
            if (OvLen == TrenLen)
            {
                Counter2 = Counter2 + 1;
                OvLen = OvLen - TigerLen + HeroLen;
            }
            while (OvLen != TrenLen)
            {
                Counter2 = Counter2 + 1;
                OvLen = OvLen - TigerLen + HeroLen;
                if (OvLen < 0)
                {
                    Console.WriteLine("-1");
                    OvLen = TrenLen;
                }
            }
            Console.WriteLine("{0} {1}", Counter, Counter2);
            Console.ReadLine();
        }
    }
}
