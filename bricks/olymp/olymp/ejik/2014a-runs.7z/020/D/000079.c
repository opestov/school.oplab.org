/*
 * main.c
 *
 *  Created on: 05.10.2014
 *      Author: penki
 */

#include<stdio.h>

int main() {
    int num = 1001;
    float array[num];
    float array2[num];

    scanf("%d\n", &num);

    int i;
    float c;
    float min = 200001;
    int index;

    for (i = 0; i < num; i++) {
        scanf("%f %f\n", &array[i], &array2[i]);
        c = array[i] + array[i] * array2[i] / 100;
        if (c < min) {
            min = c;
            index = i;
        }
    }

    printf("%d\n", index+1);
}
