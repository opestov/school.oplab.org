#include<stdio.h>
main()
{
    int M, S, Mt, St, Mh, Sh, sec1, sec2, sec3, i=0, k=0,g;

    scanf("%d%d%d%d%d%d", &M, &S, &Mt, &St, &Mh, &Sh);
    sec1 = M*60 + S;
    sec2 = Mt*60 + St;
    sec3 = Mh*60 + Sh;
    while (sec1>0)
    {
        if (sec1<sec2 && sec1<sec3)
        {
            g=-1;
            break;
        }
        if (sec1>=sec2)
            {
            sec1=sec1 - sec2;
            ++i;
            }
        if (sec1>=sec3)
            {
            sec1=sec1 - sec3;
            ++k;
            }

    }

    if (g!=-1)
        printf ("%d %d", i, k);
    else printf ("-1");

    return 0;
}


