#include<stdio.h>
#
main()
{int age,doub;
scanf("%d", &age);
doub=age % 2;
if (!(age>=1 && age <=100))
    doub=1;
if(doub==0)
printf("YES");
else printf("NO");
}
