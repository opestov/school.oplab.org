#include<stdio.h>
main()
{
printf ("3");
return 0;

}
