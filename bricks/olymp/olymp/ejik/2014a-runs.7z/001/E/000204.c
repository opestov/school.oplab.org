#include<stdio.h>
main()
{
printf ("2");
printf ("4");
return 0;

}
